import { useState, useRef, useEffect } from 'react'
import { type PayProvider } from './api'
import heroBanner from './imports/qvs0_FDwtnc.jpg'
import homeExclusive from './imports/e9eda78d-9745-421d-b6a0-43e98c0b4542.webp'
import homeFigures from './imports/57abcf5c-de2e-4e3b-9f43-aab0a622cf21.webp'
import homeMasks from './imports/9939b7ac-4ccb-4f66-b6bb-d9fecde67999.webp'
import homeKatana from './imports/a90a0173-24fd-4754-8975-f24a81fdd713.webp'
import homeClothing from './imports/76db635d-7022-4dd9-9e3c-6feee323ffa1.webp'
import brandLogo from './imports/_clean.png'

export async function compressImage(file: File, maxDim = 1024, quality = 0.82): Promise<File> {
  if (!file.type.startsWith('image/')) return file
  try {
    const dataUrl: string = await new Promise((resolve, reject) => {
      const r = new FileReader()
      r.onload = () => resolve(String(r.result))
      r.onerror = () => reject(new Error('read'))
      r.readAsDataURL(file)
    })
    const img: HTMLImageElement = await new Promise((resolve, reject) => {
      const im = new Image()
      im.onload = () => resolve(im)
      im.onerror = () => reject(new Error('decode'))
      im.src = dataUrl
    })
    const scale = Math.min(1, maxDim / Math.max(img.width, img.height))
    const w = Math.max(1, Math.round(img.width * scale))
    const h = Math.max(1, Math.round(img.height * scale))
    const canvas = document.createElement('canvas')
    canvas.width = w; canvas.height = h
    const ctx = canvas.getContext('2d')
    if (!ctx) return file
    ctx.drawImage(img, 0, 0, w, h)
    // WebP при том же качестве весит в 2–3 раза меньше JPEG — на мобильной сети это
    // и есть разница между «фото появилось сразу» и «фото грузится пару секунд».
    // Если браузер webp не кодирует, canvas вернёт png/jpeg — тогда падаем на JPEG.
    const encode = (type: string) => new Promise<Blob | null>(r => canvas.toBlob(r, type, quality))
    let blob = await encode('image/webp')
    let ext = 'webp'
    if (!blob || blob.type !== 'image/webp') { blob = await encode('image/jpeg'); ext = 'jpg' }
    if (!blob) return file
    return new File([blob], (file.name.replace(/\.[^.]+$/, '') || 'image') + '.' + ext, { type: blob.type })
  } catch {
    return file
  }
}

export type Role = 'admin' | 'moderator' | 'editor' | 'user'
export type OrderStatus = 'new' | 'printing' | 'painting' | 'ready' | 'delivered'
export type DeliveryService = '' | 'pochta' | 'sdek' | 'yandex' | '5post'
export interface PaymentCard { last4: string; name: string; expiry: string }
/** bgUrl — своя обложка профиля за аватаркой (null/пусто = стандартный арт).
 *  points — баланс бонусов (в рублях). refBy — логин пригласившего (ставится один
 *  раз). refReward — рефереру уже начислен бонус за этого клиента. useBonus —
 *  автосписание бонусов при оформлении заказа. */
export interface UserProfile { email: string; avatarUrl: string | null; nickname: string; city: string; address: string; deliveryService: DeliveryService; promoCode?: string; card?: PaymentCard; bgUrl?: string | null; points?: number; refBy?: string; refReward?: boolean; useBonus?: boolean }

// ── Программа лояльности ──────────────────────────────────────────
// cashback — процент возврата бонусами от суммы доставленного заказа.
// referral — фикс. бонус пригласившему за первый заказ приглашённого (и приветственный
// бонус самому приглашённому). maxRedeemPct — какую долю заказа можно оплатить бонусами.
/** Уровни Sigma Club — по сумме доставленных заказов (₽ за всё время). */
export interface ClubTier { key: string; name: string; from: number; discount: number; color: string; perks: string[] }
export const CLUB_TIERS: ClubTier[] = [
  { key: 'cosmo', name: 'Космонавт', from: 0, discount: 0, color: '#8b93a7', perks: ['Бонусная программа Sigma Space', 'Доступ к базовому каталогу', 'Отслеживание заказов в реальном времени'] },
  { key: 'pilot', name: 'Пилот', from: 15000, discount: 5, color: '#5b9cf0', perks: ['Скидка 5% на все заказы', 'Ранний доступ к новым дропам', 'Повышенный кешбэк бонусами'] },
  { key: 'commander', name: 'Командир', from: 50000, discount: 10, color: '#a855f7', perks: ['Скидка 10% на все заказы', 'Закрытые лимитированные дропы', 'Приоритетная сборка и поддержка'] },
  { key: 'legend', name: 'Легенда', from: 150000, discount: 15, color: '#f0b64b', perks: ['Скидка 15% на все заказы', 'Персональный менеджер', 'Бесплатная доставка по России', 'Эксклюзивные подарки к заказам'] },
]

export interface LoyaltyConfig { enabled: boolean; cashback: number; referral: number; maxRedeemPct: number; clubEnabled: boolean; clubTitle: string; clubIntro: string; clubTiers: ClubTier[] }
export const INIT_LOYALTY: LoyaltyConfig = { enabled: true, cashback: 5, referral: 200, maxRedeemPct: 30, clubEnabled: false, clubTitle: 'Sigma Club', clubIntro: 'Копите сумму заказов и открывайте новые уровни привилегий.', clubTiers: CLUB_TIERS }

/** Уровни клуба с гарантией: непустой список, отсортирован по порогу. */
export const clubTiersOf = (cfg?: Partial<LoyaltyConfig>): ClubTier[] => {
  const t = cfg?.clubTiers && cfg.clubTiers.length ? cfg.clubTiers : CLUB_TIERS
  return [...t].sort((a, b) => a.from - b.from)
}
export const clubTierFor = (spent: number, tiers: ClubTier[] = CLUB_TIERS): { tier: ClubTier; next: ClubTier | null; idx: number } => {
  const list = tiers.length ? tiers : CLUB_TIERS
  let idx = 0
  for (let i = 0; i < list.length; i++) if (spent >= list[i].from) idx = i
  return { tier: list[idx], next: list[idx + 1] ?? null, idx }
}
export const genTierKey = () => `t${Date.now().toString(36)}${Math.floor(Math.random() * 1e4).toString(36)}`
export const loyaltyCfg = (c?: Partial<LoyaltyConfig>): LoyaltyConfig => ({ ...INIT_LOYALTY, ...(c ?? {}), clubTiers: clubTiersOf(c) })
/** Сколько бонусов можно списать с конкретного заказа при данном балансе. */
export const redeemable = (cfg: LoyaltyConfig, price: number, balance: number): number =>
  Math.max(0, Math.min(Math.floor((balance ?? 0)), Math.floor(price * cfg.maxRedeemPct / 100)))

// Один и тот же человек может быть записан по-разному: Telegram отдаёт «doken62»,
// а в ролях и в старых профилях тот же логин сохранён как «@doken62» или «Doken62».
// Всё сравнение логинов идёт через эту нормализацию.
export const normLogin = (l?: string | null) => (l ? (l.startsWith('@') ? l : `@${l}`).toLowerCase() : '')
// Все ключи профилей, относящиеся к одному логину (варианты с «@» и регистром).
export const profileKeys = (profiles: Record<string, UserProfile>, login: string) => {
  const n = normLogin(login)
  return Object.keys(profiles).filter(k => normLogin(k) === n)
}
// Склейка вариантов: приоритет у a, но пустые поля добираются из b —
// иначе аватарка, сохранённая под другим написанием логина, «терялась».
export const mergeProfile = (a?: UserProfile, b?: UserProfile): UserProfile | undefined => {
  if (!a) return b
  if (!b) return a
  const out: UserProfile = { ...b, ...a }
  for (const k of Object.keys(out) as (keyof UserProfile)[]) {
    const av = a[k]
    if (av === undefined || av === null || av === '') (out[k] as unknown) = b[k] ?? av
  }
  return out
}
export const readProfile = (profiles: Record<string, UserProfile>, login: string): UserProfile | undefined => {
  let acc: UserProfile | undefined = profiles[login]
  for (const k of profileKeys(profiles, login)) {
    if (k === login) continue
    acc = mergeProfile(acc, profiles[k])
  }
  return acc
}

export interface RegisteredUser { login: string; name: string; role: Role; joinedAt: string }
/**
 * Режим обложки профиля.
 *  owner — обложку ставит только владелец, и она одна для всех пользователей;
 *  all   — каждый пользователь ставит себе свою.
 */
export type CoverMode = 'owner' | 'all'
export const INIT_COVER_MODE: CoverMode = 'owner'
export const COVER_MODE_OPTIONS: Array<{ key: CoverMode; label: string; sub: string; icon: IconName }> = [
  { key: 'owner', label: 'Только я',        sub: 'Моя обложка видна всем пользователям', icon: 'star-fill' },
  { key: 'all',   label: 'Все пользователи', sub: 'Каждый ставит себе свою обложку',      icon: 'person' },
]
export type PayStatus = 'awaiting' | 'confirmed' | 'rejected'
export interface Order { id: string; name: string; figure: string; price: number; priceUnpainted: number; date: string; status: OrderStatus; thumb: string; userId: string; painted: boolean; variantName?: string; promoCode?: string; discount?: number; paid?: boolean; payProvider?: PayProvider; payStatus?: PayStatus; track?: string; carrier?: DeliveryService; createdAt?: number; bonusPaid?: number; bonusSpent?: number }
export interface ProductVariant { id: string; name: string; price: number; images: string[]; cover?: string }
/** hidden — товар скрыт от клиентов (не показывается в каталоге и коллекциях),
 *  но остаётся виден и редактируется в CRM. */
export interface Product { id: number; name: string; series: string; price: number; priceUnpainted: number; rating: number; sold: number; img: string; images: string[]; imagesPainted?: string[]; imagesUnpainted?: string[]; variants?: ProductVariant[]; inStock: boolean; baseSize: number; description: string; hidden?: boolean; isNew?: boolean; tags?: string[] }
/** Нормализуем хештег: без «#», без лишних пробелов. */
export const normTag = (t: string): string => t.trim().replace(/^#+/, '').replace(/\s+/g, ' ').trim()
/** Все уникальные хештеги каталога — по частоте использования (сначала популярные). */
export const allProductTags = (products: Product[]): string[] => {
  const freq = new Map<string, number>()
  for (const p of products) for (const t of p.tags ?? []) { const k = normTag(t); if (k) freq.set(k, (freq.get(k) ?? 0) + 1) }
  return [...freq.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).map(e => e[0])
}
export interface CatalogSection { id: number; name: string; emoji: string }
/** Кнопка-фильтр каталога — настраивается в CRM (порядок, включение, текст). */
export type CatalogFilterKind = 'inStock' | 'new' | 'popular' | 'toprated' | 'variants'
export interface CatalogFilterButton { id: string; label: string; hint: string; kind: CatalogFilterKind; enabled: boolean }
export const CATALOG_FILTER_KINDS: { kind: CatalogFilterKind; label: string; hint: string }[] = [
  { kind: 'inStock', label: 'В наличии', hint: 'Скрыть фигурки под заказ' },
  { kind: 'new', label: 'Новинки', hint: 'Свежие дропы Sigma Space' },
  { kind: 'popular', label: 'Хиты продаж', hint: 'Более 50 продаж' },
  { kind: 'toprated', label: 'Высокий рейтинг', hint: 'Рейтинг 4.5 и выше' },
  { kind: 'variants', label: 'С вариантами', hint: 'Несколько версий фигурки' },
]
export const catalogFilterPass = (kind: CatalogFilterKind, p: Product): boolean => {
  switch (kind) {
    case 'inStock': return p.inStock
    case 'new': return !!p.isNew
    case 'popular': return (p.sold ?? 0) >= 50
    case 'toprated': return (p.rating ?? 0) >= 4.5
    case 'variants': return (p.variants?.length ?? 0) > 1
    default: return true
  }
}
export const genFilterId = () => `cf${Date.now().toString(36)}${Math.floor(Math.random() * 1e4).toString(36)}`
// Стартовый набор кнопок-фильтров каталога.
export const INIT_CATALOG_FILTERS: CatalogFilterButton[] = [
  { id: 'cf_stock', label: 'В наличии', hint: 'Скрыть фигурки под заказ', kind: 'inStock', enabled: true },
  { id: 'cf_new', label: 'Новинки', hint: 'Свежие дропы Sigma Space', kind: 'new', enabled: true },
]
export interface FaqSection { id: string; title: string; emoji: string; content: string }
export interface Material { id: string; name: string; available: boolean; priceMultiplier: number }
export interface Review { id: string; userId: string; userName: string; productId: number; rating: number; text: string; date: string; photos?: string[] }
export interface NoticeItem { id: string; icon: IconName; text: string; sub?: string }
export interface NoticeContent { title: string; subtitle: string; buttonText: string; items: NoticeItem[] }

export const OWNER_TG = '@doken62'
export const ROLE_LABELS: Record<Role, string> = { admin: 'Администратор', moderator: 'Модератор', editor: 'Редактор', user: 'Клиент' }
export function relativeTime(ts: number): string {
  const min = Math.floor((Date.now() - ts) / 60000)
  if (min < 1)   return 'только что'
  if (min < 60)  return `${min} мин назад`
  const h = Math.floor(min / 60)
  if (h < 24)    return `${h} ч назад`
  return `${Math.floor(h / 24)} дн назад`
}

export interface BannerConfig { url: string; height: number; scale: number; posX: number; posY: number }
export const INIT_BANNER: BannerConfig = { url: heroBanner, height: 172, scale: 1, posX: 50, posY: 50 }
export interface CustomOrderConfig { text: string; link: string; buttonText: string; title?: string; subtitle?: string; chips?: string[] }
export const resolveBannerUrl = (u?: string) => (u && /^https?:\/\//i.test(u) ? u : heroBanner)

// ── Главная страница ──────────────────────────────────────────
// Всё содержимое главной редактируется в CRM: карусель баннеров (фото + текст),
// карточки коллекций (фото + текст + список товаров), карточки «Sigma Club» и
// «Быстрая доставка». Фото коллекций/баннеров могут быть локальными импортами
// (по умолчанию) либо http-ссылками из Storage после загрузки в CRM.
/**
 * Горизонтальные ленты-пилюли: в браузере колесо мыши крутит страницу, а не
 * ленту, поэтому переводим вертикальную прокрутку в горизонтальную.
 */
export const hScroll = (el: HTMLDivElement | null) => {
  if (!el) return
  el.onwheel = e => {
    if (el.scrollWidth <= el.clientWidth) return
    e.preventDefault()
    el.scrollLeft += e.deltaY + e.deltaX
  }
}

export const resolveHomeImage = (u?: string) => (u ?? '')
/**
 * Оформление борда (баннер карусели или карточка коллекции). На фотографиях
 * часто уже есть свой текст, поэтому подпись, затемнение и кнопку можно
 * скрывать и двигать независимо друг от друга.
 */
export interface BoardStyle {
  showText: boolean
  textX: 'left' | 'center' | 'right'
  textY: 'top' | 'middle' | 'bottom'
  showCta: boolean
  ctaX: 'left' | 'center' | 'right'
  scrim: 'none' | 'left' | 'right' | 'bottom' | 'full'
  scrimStrength: number        // 0–100, сила затемнения
  glow: '' | 'brand' | 'blue' | 'white'
}
export const INIT_BOARD_STYLE: BoardStyle = {
  showText: true, textX: 'left', textY: 'middle',
  showCta: true, ctaX: 'left',
  scrim: 'left', scrimStrength: 80, glow: 'brand',
}
export const boardStyle = (s?: Partial<BoardStyle>): BoardStyle => ({ ...INIT_BOARD_STYLE, ...(s ?? {}) })
/** CSS-градиент затемнения по выбранной схеме и силе. */
export function scrimGradient({ scrim, scrimStrength }: BoardStyle): string | undefined {
  const a = Math.max(0, Math.min(100, scrimStrength)) / 100
  if (scrim === 'none' || a === 0) return undefined
  const c = (k: number) => `rgba(5,6,10,${(a * k).toFixed(3)})`
  switch (scrim) {
    case 'left':   return `linear-gradient(90deg, ${c(0.94)} 0%, ${c(0.72)} 42%, ${c(0.12)} 100%)`
    case 'right':  return `linear-gradient(270deg, ${c(0.94)} 0%, ${c(0.72)} 42%, ${c(0.12)} 100%)`
    case 'bottom': return `linear-gradient(0deg, ${c(0.94)} 0%, ${c(0.55)} 46%, transparent 100%)`
    case 'full':   return `linear-gradient(180deg, ${c(0.7)} 0%, ${c(0.7)} 100%)`
  }
}
/** Цвет свечения/обводки борда. */
export const boardGlow = (g: BoardStyle['glow']): { border: string; shadow: string } =>
  g === 'brand' ? { border: 'var(--ss-brand-edge, rgba(168,85,247,0.45))', shadow: '0 0 26px -8px var(--ss-brand-glow, rgba(168,85,247,0.7)), var(--ss-e3)' }
  : g === 'blue' ? { border: 'rgba(96,132,255,0.45)', shadow: '0 0 26px -8px rgba(96,132,255,0.7), var(--ss-e3)' }
  : g === 'white' ? { border: 'rgba(255,255,255,0.35)', shadow: '0 0 22px -10px rgba(255,255,255,0.5), var(--ss-e3)' }
  : { border: 'var(--ss-hairline-lo)', shadow: 'var(--ss-e3)' }

export interface HomeBanner { id: string; image: string; title: string; subtitle: string; eyebrow?: string; cta: string; collectionId: string; style?: Partial<BoardStyle> }
export interface HomeCollection { id: string; title: string; subtitle: string; eyebrow?: string; image: string; cta: string; productIds: number[]; style?: Partial<BoardStyle> }
export interface HomePerk { title: string; text: string }
/** Логотип и подпись в верхней панели — тоже редактируются из CRM. */
export interface HomeBrand { logo: string; title: string; subtitle: string; logoSize?: number }
/** Как наполняется ряд товаров на главной. */
export type RowMode = 'popular' | 'orders' | 'novelty' | 'manual'
export interface HomeRow { id: string; title: string; mode: RowMode; ids: number[] }
export const ROW_MODE_LABEL: Record<RowMode, string> = {
  popular: 'По популярности',
  orders: 'По кол-ву заказов',
  novelty: 'По новизне',
  manual: 'Вручную',
}
export interface HomeConfig {
  banners: HomeBanner[]; collections: HomeCollection[]; club: HomePerk; delivery: HomePerk
  /** Ряды товаров: пустой список — подбор автоматический (устаревшее, см. rows). */
  popular: number[]; novelty: number[]
  /** Настраиваемые ряды товаров на главной. */
  rows?: HomeRow[]
  brand: HomeBrand
  /** Высота верхних коллекций-бордов на главной (px). */
  collectionHeight?: number
}
export const genHomeId = (p = 'h') => `${p}${Date.now().toString(36)}${Math.floor(Math.random() * 1e4).toString(36)}`
export const INIT_HOME: HomeConfig = {
  banners: [
    { id: 'hb1', image: homeExclusive, eyebrow: 'Следующая коллекция', title: 'Скоро\nв продаже', subtitle: 'Новая коллекция уже\nв процессе создания', cta: 'Следить за новостями', collectionId: 'hc-figures' },
    { id: 'hb2', image: homeFigures,   eyebrow: 'Новинка', title: 'Cyber\nCollection', subtitle: 'Коллекционные фигурки в стиле киберпанк', cta: 'Смотреть коллекцию', collectionId: 'hc-figures' },
  ],
  collections: [
    { id: 'hc-masks',    eyebrow: 'Sigma Space', title: 'Cyber\nMasks',   subtitle: 'Футуристические маски: киберпанк и традиции Востока', image: homeMasks,    cta: 'Смотреть коллекцию', productIds: [] },
    { id: 'hc-figures',  eyebrow: 'Sigma Space', title: 'Cyber\nFigures', subtitle: 'Эксклюзивные фигурки ограниченного тиража', image: homeFigures,  cta: 'Смотреть коллекцию', productIds: [] },
    { id: 'hc-clothing', eyebrow: 'Sigma Space', title: 'Cyber\nWear',    subtitle: 'Куртки и мерч Sigma Space', image: homeClothing, cta: 'Смотреть коллекцию', productIds: [] },
  ],
  club: { title: 'Sigma Club', text: 'Скидка 5% на все заказы и эксклюзивные дропы' },
  delivery: { title: 'Быстрая доставка', text: 'Доставляем по всей России, от 1 до 5 дней' },
  popular: [],
  novelty: [],
  rows: [
    { id: 'r-pop', title: 'Популярное', mode: 'popular', ids: [] },
    { id: 'r-new', title: 'Новинки', mode: 'novelty', ids: [] },
  ],
  brand: { logo: '', title: 'SigmaSpace', subtitle: 'авторские фигурки', logoSize: 48 },
  collectionHeight: 300,
}
/**
 * Картинки баннеров и коллекций главной.
 *
 * В облаке лежит конфиг главной вместе со строками картинок. Встроенные картинки —
 * это собранные Vite ссылки вида /assets/xxx-<хеш>.png, и в опубликованной версии
 * хеш другой, чем был при сохранении конфига: старые ссылки отдают 404, и блок
 * оставался пустым. Поэтому берём только загруженные из CRM http-ссылки, а всё
 * остальное сопоставляем со встроенным файлом — по имени или по id блока.
 */
const HOME_BUILTIN_IMGS = [homeExclusive, homeFigures, homeMasks, homeKatana, homeClothing]
const HOME_IMG_BY_ID: Record<string, string> = {
  hb1: homeExclusive, hb2: homeFigures,
  'hc-masks': homeMasks, 'hc-katana': homeKatana, 'hc-figures': homeFigures, 'hc-clothing': homeClothing,
}
/** Ключ файла без хеша и расширения: /assets/9939b7ac-...-D3f1.png → 9939b7ac */
const imgKey = (u: string) => (u.split('/').pop() ?? '').split('.')[0].split('-')[0].toLowerCase()
export function resolveHomeImg(id: string, u?: string): string {
  if (u && /^(https?:|data:|blob:)/i.test(u)) return u
  if (u) {
    const k = imgKey(u)
    const hit = k && HOME_BUILTIN_IMGS.find(b => imgKey(b) === k)
    if (hit) return hit
  }
  return HOME_IMG_BY_ID[id] ?? u ?? ''
}

/** Логотип бренда: загруженный из CRM или встроенный по умолчанию. */
export const resolveBrandLogo = (u?: string) => (u && u.trim() ? u : brandLogo)
/** Товары коллекции: по явному списку id, а если он пуст — по совпадению серии с названием. */
export function collectionProducts(c: HomeCollection, products: Product[]): Product[] {
  if (c.productIds.length) {
    const order = new Map(c.productIds.map((id, i) => [id, i]))
    return products.filter(p => order.has(p.id)).sort((a, b) => (order.get(a.id)! - order.get(b.id)!))
  }
  const t = c.title.trim().toLowerCase()
  return products.filter(p => p.series.trim().toLowerCase() === t)
}

export interface PromoCode {
  id: string
  code: string
  discount: number   // % скидки
  maxUses: number    // всего использований (шт)
  uses: number       // сколько уже использовано
  expiresAt: number  // 0 = бессрочно
  targetUser: string // '' = для всех
  createdAt: number
  deleted?: boolean  // мягкое удаление (чтобы синхронизировалось между устройствами)
  featured?: boolean // публичный анонс: показываем баннер-борд с таймером всем клиентам
}

// Активный публичный промокод-анонс для баннера: не удалён, для всех, есть таймер
// и он ещё не истёк. Если их несколько — берём самый «горящий» (ближайший к концу).
export function pickFeaturedPromo(list: PromoCode[]): PromoCode | undefined {
  const now = Date.now()
  return list
    .filter(p => p.featured && !p.deleted && p.expiresAt > now && p.uses < p.maxUses)
    .sort((a, b) => a.expiresAt - b.expiresAt)[0]
}
// Обратный отсчёт до конца акции/промокода. expiresAt === 0 (бессрочно) → ничего не рендерит.
export function PromoCountdown({ expiresAt, discount, code, compact = false }: { expiresAt: number; discount: number; code?: string; compact?: boolean }) {
  const [now, setNow] = useState(Date.now())
  useEffect(() => {
    if (!expiresAt) return
    const t = setInterval(() => setNow(Date.now()), 1000)
    return () => clearInterval(t)
  }, [expiresAt])
  if (!expiresAt) return null
  const left = expiresAt - now
  if (left <= 0) return null
  const d = Math.floor(left / 86400000)
  const h = Math.floor((left % 86400000) / 3600000)
  const m = Math.floor((left % 3600000) / 60000)
  const s = Math.floor((left % 60000) / 1000)
  const pad = (n: number) => String(n).padStart(2, '0')
  const urgent = left < 3600000 // меньше часа — красный пульс
  const cell = (v: string, label: string) => (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '2px', minWidth: compact ? '26px' : '34px' }}>
      <span style={{ fontVariantNumeric: 'tabular-nums', fontSize: compact ? '14px' : '18px', fontWeight: 800, lineHeight: 1, color: '#fff', textShadow: '0 0 12px var(--ss-brand-glow)' }}>{v}</span>
      <span style={{ fontSize: compact ? '7px' : '8px', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--ss-ink-3, var(--text-muted))' }}>{label}</span>
    </div>
  )
  const sep = <span style={{ fontSize: compact ? '13px' : '16px', fontWeight: 700, color: 'var(--ss-ink-4, var(--text-muted))', alignSelf: 'flex-start', marginTop: compact ? '0' : '1px', opacity: 0.6 }}>:</span>
  return (
    <div className={urgent ? 'promo-urgent' : ''} style={{
      display: 'flex', alignItems: 'center', gap: compact ? '8px' : '12px',
      padding: compact ? '8px 12px' : '11px 14px', borderRadius: '14px',
      background: urgent
        ? 'linear-gradient(135deg, rgba(220,38,38,0.14), rgba(10,8,16,0.7))'
        : 'linear-gradient(135deg, var(--ss-brand-glow), rgba(10,8,16,0.7))',
      border: `1px solid ${urgent ? 'rgba(220,38,38,0.5)' : 'var(--ss-brand-edge)'}`,
      boxShadow: urgent ? '0 0 26px -12px rgba(220,38,38,0.7)' : '0 0 26px -14px var(--ss-brand-glow)',
    }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', minWidth: 0, flex: 1 }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: '5px', fontSize: compact ? '10px' : '11px', fontWeight: 800, letterSpacing: '0.08em', textTransform: 'uppercase', color: urgent ? '#ff6b6b' : 'var(--ss-brand-hi, var(--accent))' }}>
          <Icon name="star" size={compact ? 11 : 13} color={urgent ? '#ff6b6b' : 'var(--ss-brand-hi, var(--accent))'} />
          −{discount}% {code ? `· ${code}` : ''}
        </span>
        <span style={{ fontSize: compact ? '8.5px' : '9.5px', color: 'var(--ss-ink-3, var(--text-muted))', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {urgent ? 'Скидка вот-вот сгорит!' : 'До конца акции'}
        </span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: compact ? '4px' : '6px', flexShrink: 0 }}>
        {d > 0 && <>{cell(pad(d), 'дн')}{sep}</>}
        {cell(pad(h), 'ч')}{sep}
        {cell(pad(m), 'мин')}{sep}
        {cell(pad(s), 'сек')}
      </div>
    </div>
  )
}

/**
 * Публичный борд-анонс акции для всех клиентов. Показывается на главной и в
 * каталоге: крупная скидка, копируемый код, обратный отсчёт и кнопка активации
 * в один тап. Таймер задаёт админ. `applied` — промокод уже стоит в профиле.
 */
export function PromoAnnounceBoard({ promo, applied, onActivate }: { promo: PromoCode; applied: boolean; onActivate: () => void }) {
  const [now, setNow] = useState(Date.now())
  const [copied, setCopied] = useState(false)
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000)
    return () => clearInterval(t)
  }, [])
  const left = promo.expiresAt - now
  if (left <= 0) return null
  const d = Math.floor(left / 86400000)
  const h = Math.floor((left % 86400000) / 3600000)
  const m = Math.floor((left % 3600000) / 60000)
  const s = Math.floor((left % 60000) / 1000)
  const pad = (n: number) => String(n).padStart(2, '0')
  const urgent = left < 3600000
  const copy = () => {
    try { navigator.clipboard?.writeText(promo.code) } catch {}
    setCopied(true)
    setTimeout(() => setCopied(false), 1600)
  }
  const cell = (v: string, label: string) => (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '3px', minWidth: '38px' }}>
      <span style={{ fontVariantNumeric: 'tabular-nums', fontSize: '20px', fontWeight: 800, lineHeight: 1, color: '#fff', textShadow: '0 0 14px var(--ss-brand-glow)' }}>{v}</span>
      <span style={{ fontSize: '8px', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--ss-ink-3, var(--text-muted))' }}>{label}</span>
    </div>
  )
  const sep = <span style={{ fontSize: '17px', fontWeight: 700, color: 'var(--ss-ink-4, var(--text-muted))', alignSelf: 'flex-start', marginTop: '1px', opacity: 0.5 }}>:</span>
  return (
    <div style={{
      position: 'relative', overflow: 'hidden', borderRadius: '18px', padding: '16px 16px 15px',
      border: `1px solid ${urgent ? 'rgba(220,38,38,0.5)' : 'var(--ss-brand-edge)'}`,
      background: 'linear-gradient(152deg, #1a1030 0%, #120c22 48%, #08060f 100%)',
      boxShadow: urgent ? '0 12px 30px -14px rgba(220,38,38,0.6), var(--ss-e2)' : '0 12px 30px -14px var(--ss-brand-glow), var(--ss-e2)',
    }}>
      {/* портальное свечение в углу */}
      <div aria-hidden style={{ position: 'absolute', right: '-12%', top: '-46%', width: 180, height: 180, borderRadius: '50%', background: `radial-gradient(circle, ${urgent ? 'rgba(220,38,38,0.28)' : 'var(--ss-brand-glow)'} 0%, transparent 66%)`, filter: 'blur(8px)', pointerEvents: 'none' }} />
      <div aria-hidden style={{ position: 'absolute', top: 0, left: '14%', right: '14%', height: '1px', background: 'linear-gradient(90deg, transparent, var(--ss-brand-hi), transparent)', opacity: 0.6, pointerEvents: 'none' }} />

      <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: '11px' }}>
        <div style={{ width: '42px', height: '42px', borderRadius: '50%', flexShrink: 0, display: 'grid', placeItems: 'center', background: 'rgba(0,0,0,0.35)', border: '1px solid var(--ss-brand-edge)', boxShadow: '0 0 20px -6px var(--ss-brand-glow)' }}>
          <Icon name="gift" size={20} color="var(--ss-brand-hi, #a855f7)" />
        </div>
        <div style={{ minWidth: 0, flex: 1 }}>
          <p style={{ margin: '0 0 2px', fontSize: '9.5px', fontWeight: 800, letterSpacing: '0.16em', textTransform: 'uppercase', color: urgent ? '#ff6b6b' : 'var(--ss-brand-hi, var(--accent))' }}>
            {urgent ? 'Скидка вот-вот сгорит' : 'Акция для всех'}
          </p>
          <p style={{ margin: 0, fontSize: '22px', fontWeight: 800, color: '#fff', lineHeight: 1, textShadow: '0 0 16px var(--ss-brand-glow)' }}>−{promo.discount}% на заказ</p>
        </div>
      </div>

      {/* таймер */}
      <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: '7px', justifyContent: 'center', margin: '14px 0 13px' }}>
        {d > 0 && <>{cell(pad(d), 'дней')}{sep}</>}
        {cell(pad(h), 'часов')}{sep}
        {cell(pad(m), 'минут')}{sep}
        {cell(pad(s), 'секунд')}
      </div>

      {/* код + активация */}
      <div style={{ position: 'relative', display: 'flex', gap: '8px', alignItems: 'stretch' }}>
        <button onClick={copy} title="Скопировать код" style={{
          flexShrink: 0, display: 'flex', alignItems: 'center', gap: '6px', padding: '0 13px', height: '44px', cursor: 'pointer',
          borderRadius: '12px', border: '1px dashed var(--ss-brand-edge)', background: 'rgba(168,85,247,0.08)',
          color: '#fff', fontFamily: 'monospace', fontSize: '14px', fontWeight: 700, letterSpacing: '1.5px',
        }}>
          {promo.code}
          <Icon name={copied ? 'check' : 'save'} size={13} color={copied ? 'var(--status-ready-color)' : 'var(--ss-ink-3, var(--text-muted))'} />
        </button>
        <button onClick={applied ? undefined : onActivate} disabled={applied} className={applied ? '' : 'ss-press'} style={{
          flex: 1, height: '44px', borderRadius: '12px', cursor: applied ? 'default' : 'pointer', fontFamily: 'inherit',
          fontSize: '13.5px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px',
          border: `1px solid ${applied ? 'var(--status-ready-color)' : 'var(--ss-brand-edge)'}`,
          color: applied ? 'var(--status-ready-color)' : '#fff',
          background: applied ? 'transparent' : 'linear-gradient(180deg, var(--ss-brand-hi, #a855f7), var(--ss-brand, #7c3aed))',
          boxShadow: applied ? 'none' : '0 8px 22px -8px var(--ss-brand-glow), inset 0 1px 0 rgba(255,255,255,0.18)',
        }}>
          {applied ? <><Icon name="check" size={14} color="var(--status-ready-color)" /> Применён</> : 'Активировать'}
        </button>
      </div>
      {copied && <p style={{ position: 'relative', margin: '8px 0 0', fontSize: '10px', textAlign: 'center', color: 'var(--status-ready-color)' }}>Код скопирован</p>}
    </div>
  )
}

export type PayMethodKey = PayProvider | 'crypto'
export interface PayMethodDef { key: PayMethodKey; label: string; short: string; sub: string; icon: IconName; brands?: string[]; comingSoon?: boolean }
export const PAY_METHOD_DEFS: PayMethodDef[] = [
  { key: 'card', label: 'Банковская карта', short: 'Картой', sub: 'Visa · Mastercard · МИР', icon: 'card', brands: ['VISA', 'Mastercard', 'МИР'] },
  { key: 'sbp',  label: 'Оплата по СБП', short: 'СБП', sub: 'Перевод по номеру карты или телефона', icon: 'send', brands: ['СБП'] },
  { key: 'skins',    label: 'Оплата скинами', short: 'Скинами', sub: 'CS2 · Dota 2 · Rust', icon: 'gamepad' },
  { key: 'crypto',   label: 'Криптовалюта', short: 'Криптой', sub: 'USDT · BTC · TON', icon: 'planet', brands: ['USDT', 'BTC', 'TON'] },
]
export interface SbpInfo { fio: string; card: string; phone: string; bank: string; note: string; contact?: string; support?: string }
export const genPromoCode = (len = 8) => {
  const abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  return Array.from({ length: len }, () => abc[Math.floor(Math.random() * abc.length)]).join('')
}
export const STATUS_META: Record<OrderStatus, { label: string; style: React.CSSProperties; dot: string }> = {
  new:       { label: 'Оплачен',    dot: 'var(--status-new-color)',      style: { color: 'var(--status-new-color)',      background: 'var(--status-new-bg)' } },
  printing:  { label: 'На печати',  dot: 'var(--status-printing-color)', style: { color: 'var(--status-printing-color)', background: 'var(--status-printing-bg)' } },
  painting:  { label: 'Красим',     dot: 'var(--status-painting-color)', style: { color: 'var(--status-painting-color)', background: 'var(--status-painting-bg)' } },
  ready:     { label: 'Готов',      dot: 'var(--status-ready-color)',    style: { color: 'var(--status-ready-color)',    background: 'var(--status-ready-bg)' } },
  delivered: { label: 'Получен',    dot: 'var(--status-delivered-color)',style: { color: 'var(--status-delivered-color)',background: 'var(--status-delivered-bg)' } },
}
// Акцент статуса для карточек/бейджей: сине-фиолетовая гамма 50/50, а «Готов»
// — всегда зелёный (это единственный статус с фиксированным цветом).
export const statusAccent = (status: OrderStatus): string =>
  status === 'ready' ? 'var(--status-ready-color, #34c97d)'
  : status === 'new' || status === 'painting' ? 'var(--ss-blue-hi, #4f8dff)'
  : 'var(--ss-brand-hi, #a855f7)'

export const DELIVERY_OPTIONS: Array<{ key: DeliveryService; label: string; icon: IconName; sub: string }> = [
  { key: 'sdek',   label: 'СДЭК',            icon: 'package', sub: '2–5 дней'  },
  { key: 'pochta', label: 'Почта России',     icon: 'mail',    sub: '5–14 дней' },
  { key: 'yandex', label: 'Яндекс Доставка', icon: 'truck',   sub: '1–3 дней'  },
  { key: '5post',  label: '5Post',           icon: 'package', sub: '3–7 дней'  },
]
export const DELIVERY_LABELS: Record<DeliveryService, string> = { '': 'Не выбран', pochta: 'Почта России', sdek: 'СДЭК', yandex: 'Яндекс Доставка', '5post': '5Post' }

export type IconName = 'grid'|'person'|'document'|'chat'|'layers'|'gear'|'search'|'arrow-left'|'send'|'star'|'chevron-right'|'chevron-down'|'chevron-up'|'plus'|'pencil'|'trash'|'sun'|'moon'|'bell'|'heart'|'pin'|'card'|'sign-out'|'check'|'close'|'package'|'image'|'question'|'truck'|'info'|'cart'|'camera'|'save'|'users'|'calculator'|'star-fill'|'arrow-right'|'edit-3'|'mail'|'gamepad'|'film'|'anime'|'adult'|'planet'|'gift'|'sort'|'eye'
export const PATHS: Record<IconName, string[]> = {
  grid:          ['M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z'],
  person:        ['M12 11a4 4 0 100-8 4 4 0 000 8z','M4 20c0-4 3.58-7 8-7s8 3 8 7'],
  document:      ['M5 3h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2z','M8 8h8M8 12h6M8 16h4'],
  chat:          ['M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z'],
  layers:        ['M12 2l10 5-10 5L2 7z','M2 12l10 5 10-5','M2 17l10 5 10-5'],
  gear:          ['M12 15a3 3 0 100-6 3 3 0 000 6z','M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z'],
  search:        ['M21 21l-4.35-4.35M17 11A6 6 0 115 11a6 6 0 0112 0z'],
  'arrow-left':  ['M19 12H5M5 12l7-7M5 12l7 7'],
  'arrow-right': ['M5 12h14M12 5l7 7-7 7'],
  send:          ['M22 2L11 13M22 2l-7 20-4-9-9-4z'],
  star:          ['M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01z'],
  'star-fill':   ['M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01z'],
  'chevron-right': ['M9 18l6-6-6-6'],
  'chevron-down':  ['M6 9l6 6 6-6'],
  'chevron-up':    ['M6 15l6-6 6 6'],
  plus:          ['M12 5v14M5 12h14'],
  pencil:        ['M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7','M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z'],
  'edit-3':      ['M12 20h9','M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4z'],
  trash:         ['M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6'],
  sun:           ['M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42','M12 17a5 5 0 100-10 5 5 0 000 10z'],
  moon:          ['M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z'],
  bell:          ['M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9','M13.73 21a2 2 0 01-3.46 0'],
  heart:         ['M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z'],
  pin:           ['M12 22s-8-4.5-8-11.8A8 8 0 0112 2a8 8 0 018 8.2c0 7.3-8 11.8-8 11.8z','M12 13a3 3 0 100-6 3 3 0 000 6z'],
  card:          ['M1 4h22v16H1z','M1 10h22'],
  'sign-out':    ['M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4','M16 17l5-5-5-5','M21 12H9'],
  check:         ['M20 6L9 17l-5-5'],
  close:         ['M18 6L6 18M6 6l12 12'],
  package:       ['M12 2l10 5v10L12 22 2 17V7z','M12 22V12','M22 7l-10 5L2 7'],
  eye:           ['M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z','M12 15a3 3 0 100-6 3 3 0 000 6z'],
  // Две стрелки рядом: левая вниз, правая вверх — переключатель приоритета сортировки
  sort:          ['M8 4v16','M8 20l-3.5-3.5','M8 20l3.5-3.5','M16 20V4','M16 4l-3.5 3.5','M16 4l3.5 3.5'],
  image:         ['M19 3H5a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2V5a2 2 0 00-2-2z','M8.5 10a1.5 1.5 0 100-3 1.5 1.5 0 000 3z','M21 15l-5-5L5 21'],
  question:      ['M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3','M12 17h.01'],
  truck:         ['M5 17H3a2 2 0 01-2-2V5a2 2 0 012-2h11a2 2 0 012 2v3','M9 17h6','M13 17V9h8l3 3v5h-3','M5 17a2 2 0 100 4 2 2 0 000-4z','M19 17a2 2 0 100 4 2 2 0 000-4z'],
  info:          ['M12 22a10 10 0 100-20 10 10 0 000 20z','M12 8h.01','M12 12v4'],
  cart:          ['M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z','M3 6h18','M16 10a4 4 0 01-8 0'],
  camera:        ['M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z','M12 17a4 4 0 100-8 4 4 0 000 8z'],
  save:          ['M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z','M17 21v-8H7v8','M7 3v5h8'],
  users:         ['M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2','M9 11a4 4 0 100-8 4 4 0 000 8z','M23 21v-2a4 4 0 00-3-3.87','M16 3.13a4 4 0 010 7.75'],
  calculator:    ['M5 3h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2z','M8 7h8M8 12h2M12 12h2M16 12h0M8 16h2M12 16h2M16 16h2'],
  mail:          ['M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z','M22 6l-10 7L2 6'],
  gamepad:       ['M17 8H7a5 5 0 00-5 5v1a5 5 0 005 5h10a5 5 0 005-5v-1a5 5 0 00-5-5z','M9 14H7M8 13v2M15 14h2'],
  film:          ['M2 6h20v14H2z','M7 6V2M12 6V2M17 6V2','M2 10h20M2 14h20'],
  anime:         ['M12 2a9 9 0 100 18A9 9 0 0012 2z','M9 10a1 1 0 102 0 1 1 0 00-2 0M13 10a1 1 0 102 0 1 1 0 00-2 0','M9 15s1 2 3 2 3-2 3-2','M5 4l2 4M19 4l-2 4'],
  adult:         ['M12 2a10 10 0 100 20A10 10 0 0012 2z','M8 12h3V8M14 8v8M17 8h-3v3.5h3'],
  planet:        ['M12 8.5a3.5 3.5 0 100 7 3.5 3.5 0 000-7z','M3.5 12c0-2.5 3.8-4.5 8.5-4.5s8.5 2 8.5 4.5-3.8 4.5-8.5 4.5S3.5 14.5 3.5 12z'],
  gift:          ['M20 12v8a1 1 0 01-1 1H5a1 1 0 01-1-1v-8','M2 8.5h20V11a1 1 0 01-1 1H3a1 1 0 01-1-1V8.5z','M12 8.5V21','M12 8.5S10.5 3.5 7.5 4.5C5 5.3 6.5 8.5 9 8.5h3z','M12 8.5s1.5-5 4.5-4c2.5.8 1 4-1.5 4h-3z'],
}
export function Icon({ name, size = 20, color = 'currentColor', strokeWidth = 1.75, fill = false }: {
  name: IconName; size?: number; color?: string; strokeWidth?: number; fill?: boolean
}) {
  const paths = PATHS[name] ?? []
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0, display: 'block' }}>
      {paths.map((d, i) => <path key={i} d={d} stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" fill={fill ? color : 'none'} />)}
    </svg>
  )
}

export function FormField({ label, value, onChange, type = 'text', placeholder = '' }: {
  label: string; value: string | number; onChange: (v: string) => void; type?: string; placeholder?: string
}) {
  // Для числовых полей 0 показываем пустым — иначе ноль нельзя стереть на телефоне.
  const display = type === 'number' && (value === 0 || value === '0') ? '' : value
  return (
    <div style={{ marginBottom: '10px' }}>
      <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 4px', fontWeight: 500 }}>{label}</p>
      <input type={type} inputMode={type === 'number' ? 'numeric' : undefined} value={display} placeholder={placeholder} onChange={e => onChange(e.target.value)}
        style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '9px 12px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
    </div>
  )
}
export function Toggle({ on, onToggle }: { on: boolean; onToggle: () => void }) {
  return (
    <div onClick={onToggle} style={{ width: '44px', height: '24px', borderRadius: '12px', cursor: 'pointer', background: on ? 'var(--accent-2-grad)' : 'var(--border)', position: 'relative', transition: 'background 0.2s', flexShrink: 0 }}>
      <div style={{ position: 'absolute', top: '3px', left: on ? '23px' : '3px', width: '18px', height: '18px', borderRadius: '50%', background: '#fff', transition: 'left 0.2s', boxShadow: '0 1px 3px rgba(0,0,0,0.3)' }} />
    </div>
  )
}
export function StatusBadge({ status }: { status: OrderStatus }) {
  const m = STATUS_META[status]
  const c = statusAccent(status)
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', fontSize: '11px', fontWeight: 600, padding: '3px 8px', borderRadius: '20px', color: c, background: `color-mix(in srgb, ${c} 13%, transparent)`, border: `1px solid color-mix(in srgb, ${c} 34%, transparent)` }}>
      <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: c, flexShrink: 0 }} />{m.label}
    </span>
  )
}
export function StarRating({ value, onChange, size = 20 }: { value: number; onChange?: (v: number) => void; size?: number }) {
  return (
    <div style={{ display: 'flex', gap: '2px' }}>
      {[1,2,3,4,5].map(i => (
        <button key={i} onClick={() => onChange?.(i)} style={{ background: 'none', border: 'none', cursor: onChange ? 'pointer' : 'default', padding: '1px' }}>
          <Icon name="star-fill" size={size} color={i <= value ? '#f5c842' : 'var(--border)'} fill={i <= value} strokeWidth={i <= value ? 0 : 1.5} />
        </button>
      ))}
    </div>
  )
}

export function MaskedId({ value, reveal, size = 12 }: { value: string; reveal?: boolean; size?: number }) {
  const raw = value.startsWith('@') ? value.slice(1) : value
  if (reveal) return <span style={{ color: 'var(--text-primary)', fontSize: `${size}px`, fontWeight: 600 }}>@{raw}</span>
  const head = raw.slice(0, 3)
  const tail = raw.slice(3) || '•••'
  return (
    <span style={{ display: 'inline-flex', alignItems: 'baseline', color: 'var(--text-primary)', fontSize: `${size}px`, fontWeight: 600 }}>
      @{head}
      <span aria-hidden title="Скрыто" style={{ filter: 'blur(3.5px)', opacity: 0.75, userSelect: 'none', pointerEvents: 'none', letterSpacing: '0.5px' }}>{tail}</span>
    </span>
  )
}

export function ReviewPhotos({ photos, onRemove }: { photos?: string[]; onRemove?: (url: string) => void }) {
  const [full, setFull] = useState<string | null>(null)
  if (!photos || photos.length === 0) return null
  return (
    <>
      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginTop: '8px' }}>
        {photos.map(url => (
          <div key={url} onClick={() => setFull(url)} style={{ position: 'relative', cursor: 'zoom-in' }}>
            <img src={url} alt="Фото отзыва"
              style={{ width: '62px', height: '62px', objectFit: 'cover', borderRadius: '10px', border: '1px solid var(--border)', display: 'block' }} />
            {onRemove && (
              <button onClick={e => { e.stopPropagation(); onRemove(url) }} style={{ position: 'absolute', top: '-5px', right: '-5px', width: '18px', height: '18px', borderRadius: '50%', background: 'var(--bg-card)', border: '1px solid var(--danger)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', padding: 0 }}>
                <Icon name="close" size={9} color="var(--danger)" />
              </button>
            )}
          </div>
        ))}
      </div>
      {full && (
        <div className="overlay-fade" onClick={() => setFull(null)}
          style={{ position: 'fixed', inset: 0, zIndex: 400, background: 'rgba(0,0,0,0.92)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '16px', cursor: 'zoom-out' }}>
          <img src={full} alt="Фото отзыва" style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', borderRadius: '12px' }} />
          <button onClick={() => setFull(null)} style={{ position: 'absolute', top: '14px', right: '14px', width: '34px', height: '34px', borderRadius: '50%', background: 'rgba(255,255,255,0.12)', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <Icon name="close" size={17} color="#fff" />
          </button>
        </div>
      )}
    </>
  )
}

export function OnlineDot({ isAdmin = false, size = 10 }: { isAdmin?: boolean; size?: number }) {
  return (
    <div style={{ width: size, height: size, borderRadius: '50%', background: isAdmin ? '#ef4444' : '#34c97d', border: `2px solid var(--bg-base)`, position: 'absolute', bottom: 0, right: 0, boxShadow: isAdmin ? '0 0 5px rgba(239,68,68,0.7)' : '0 0 5px rgba(52,201,125,0.7)' }} />
  )
}

export let __vidCounter = 0
export const genVariantId = () => `v${Date.now().toString(36)}${(__vidCounter++).toString(36)}`

export function getVariants(p: Product): ProductVariant[] {
  if (p.variants && p.variants.length) return p.variants
  const painted = (p.imagesPainted && p.imagesPainted.length) ? p.imagesPainted : (p.images ?? [])
  const unpainted = (p.imagesUnpainted && p.imagesUnpainted.length) ? p.imagesUnpainted : []
  const fallback = painted.length ? painted : [p.img]
  const vs: ProductVariant[] = []
  if (p.priceUnpainted) vs.push({ id: 'unpainted', name: 'Без покраски', price: p.priceUnpainted, images: unpainted.length ? unpainted : fallback, cover: (unpainted[0] ?? fallback[0]) })
  vs.push({ id: 'painted', name: 'С покраской', price: p.price, images: fallback, cover: p.img })
  return vs.length ? vs : [{ id: 'default', name: 'Стандарт', price: p.price, images: fallback, cover: p.img }]
}
export const variantCover = (v: ProductVariant): string => (v.cover && v.images.includes(v.cover)) ? v.cover : (v.images[0] ?? '')
export const priceRange = (p: Product): { min: number; max: number } => {
  const ps = getVariants(p).map(v => v.price).filter(n => n > 0)
  if (!ps.length) return { min: p.price, max: p.price }
  return { min: Math.min(...ps), max: Math.max(...ps) }
}

export function OrderTrackEditor({ order, onSave }: { order: Order; onSave: (id: string, track: string, carrier: DeliveryService) => void }) {
  const [track, setTrack] = useState(order.track ?? '')
  const [carrier, setCarrier] = useState<DeliveryService>(order.carrier ?? 'sdek')
  useEffect(() => { setTrack(order.track ?? ''); setCarrier(order.carrier ?? 'sdek') }, [order.track, order.carrier])
  const dirty = track.trim() !== (order.track ?? '') || (track.trim() ? carrier !== (order.carrier ?? 'sdek') : false)
  return (
    <div style={{ marginTop: '8px', paddingTop: '8px', borderTop: '1px solid var(--border)', display: 'flex', gap: '6px', alignItems: 'center', flexWrap: 'wrap' }}>
      <select value={carrier} onChange={e => setCarrier(e.target.value as DeliveryService)}
        style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '8px', padding: '7px 8px', color: 'var(--text-primary)', fontSize: '11px', outline: 'none', appearance: 'none', flexShrink: 0 }}>
        {DELIVERY_OPTIONS.map(o => <option key={o.key} value={o.key}>{o.label}</option>)}
      </select>
      <input value={track} onChange={e => setTrack(e.target.value)} placeholder="Трек-номер"
        style={{ flex: 1, minWidth: '110px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '8px', padding: '7px 10px', color: 'var(--text-primary)', fontSize: '12px', outline: 'none', fontFamily: 'monospace', boxSizing: 'border-box' }} />
      <button onClick={() => onSave(order.id, track, carrier)} disabled={!dirty}
        style={{ padding: '7px 12px', borderRadius: '8px', border: 'none', background: dirty ? 'var(--accent-grad)' : 'var(--bg-elevated)', color: dirty ? '#fff' : 'var(--text-muted)', fontSize: '11px', fontWeight: 600, cursor: dirty ? 'pointer' : 'default', flexShrink: 0 }}>
        Сохранить
      </button>
    </div>
  )
}

export const ICON_PACK: IconName[] = [
  'document','layers','grid','package','image','camera','save',
  'search','info','question','bell','chat','send','mail',
  'person','users','heart','star','pin','card',
  'gear','pencil','edit-3','trash','plus','check',
  'truck','cart','sign-out','calculator',
  'sun','moon',
  'gamepad','film','anime','adult',
]
export function EmojiPicker({ value, onChange }: { value: string; onChange: (e: string) => void }) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!open) return
    const handler = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false) }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [open])
  const iconValue = (value as IconName) in PATHS ? (value as IconName) : 'document'
  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button type="button" onClick={() => setOpen(o => !o)}
        style={{ width: '100%', height: '44px', background: 'var(--bg-input)', border: `1px solid ${open ? 'var(--accent-2)' : 'var(--border)'}`, borderRadius: '10px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'border-color 0.15s' }}>
        <Icon name={iconValue} size={20} color="var(--accent-2-hi)" />
      </button>
      {open && (
        <div style={{ position: 'absolute', top: 'calc(100% + 6px)', left: 0, zIndex: 400, background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '14px', padding: '10px', boxShadow: '0 8px 32px rgba(0,0,0,0.35)', width: '244px', maxHeight: '220px', overflowY: 'auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '4px' }}>
            {ICON_PACK.map(ic => (
              <button key={ic} type="button" onClick={() => { onChange(ic); setOpen(false) }}
                style={{ background: ic === value ? 'var(--accent-2-wash)' : 'none', border: ic === value ? '1px solid var(--accent-2)' : '1px solid transparent', borderRadius: '8px', cursor: 'pointer', padding: '7px', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'background 0.1s' }}>
                <Icon name={ic} size={18} color={ic === value ? 'var(--accent-2-hi)' : 'var(--text-secondary)'} />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

