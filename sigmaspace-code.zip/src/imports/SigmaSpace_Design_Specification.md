# SigmaSpace Design Specification

## Visual Identity & Creative Direction

This document defines the visual language of SigmaSpace.

Use this document as the main reference for all UI redesign decisions.

------------------------------------------------------------------------

# 1. Brand Vision

SigmaSpace is a premium futuristic 3D creation studio.

It is not a regular marketplace.

The product combines:

-   technology;
-   craftsmanship;
-   personalization;
-   collectible design.

The user should feel:

"I am creating something unique."

The experience should feel like entering a premium digital workshop.

------------------------------------------------------------------------

# 2. Overall Design Style

Main direction:

Premium futuristic minimalism.

Reference feeling:

-   Apple product presentation;
-   Tesla interface simplicity;
-   luxury collectible brands;
-   high-end 3D studios.

Style characteristics:

-   dark premium atmosphere;
-   cinematic lighting;
-   glass surfaces;
-   deep shadows;
-   realistic depth;
-   smooth transitions;
-   elegant animations.

------------------------------------------------------------------------

# 3. Color Direction

Primary environment:

-   deep black;
-   graphite;
-   dark metallic tones.

Accent usage:

-   subtle glow;
-   premium highlights;
-   futuristic details.

Avoid:

-   bright childish colors;
-   excessive neon;
-   aggressive gradients.

The interface should feel expensive and timeless.

------------------------------------------------------------------------

# 4. Sigma Figurine Identity

The Sigma figurine is the main visual element.

The figurine represents:

-   the brand;
-   the product;
-   the creation process.

Rules:

Always use the Sigma figurine.

Never replace it with: - generic characters; - random avatars; -
unrelated 3D models.

The figurine must feel physical.

Use:

-   realistic materials;
-   detailed surfaces;
-   cinematic shadows;
-   depth;
-   reflections.

------------------------------------------------------------------------

# 5. Depth & Parallax System

The interface should have physical depth.

Use multiple layers:

Background: - atmosphere; - lighting; - environment.

Middle: - cards; - panels; - information.

Foreground: - Sigma figurine; - interactive elements; - controls.

Special effect:

The figurine may extend outside containers.

Examples:

-   hair;
-   horns;
-   accessories.

Purpose:

Create a feeling that the object exists inside the interface.

------------------------------------------------------------------------

# 6. Card Design Language

Cards should not look like normal web blocks.

They should feel like physical objects.

Use:

-   rounded premium shapes;
-   depth;
-   shadows;
-   glass materials;
-   smooth movement.

Interactions:

Tap: - object moves forward; - lighting changes; - details appear.

------------------------------------------------------------------------

# 7. Navigation Design

Bottom navigation is a permanent brand element.

Rules:

-   identical across all screens;
-   premium glass style;
-   subtle lighting.

Central Sigma button:

Must contain:

-   Sigma symbol.

Must NOT contain:

-   figurine head;
-   character face.

The button represents the main portal.

------------------------------------------------------------------------

# 8. Screen Experience

Every screen should feel like part of the same universe.

Rules:

-   consistent spacing;
-   consistent components;
-   consistent animation language.

Avoid disconnected pages.

------------------------------------------------------------------------

# 9. Splash Screen Style

The first impression:

A cinematic entrance.

Elements:

-   SigmaSpace logo;
-   dark environment;
-   rotating energy ring;
-   Sigma appearance;
-   smooth loading messages.

Feeling:

Entering the SigmaSpace universe.

------------------------------------------------------------------------

# 10. Product Presentation

Products should be presented like luxury collectibles.

Focus:

-   large visual object;
-   premium gallery;
-   materials;
-   customization.

The user should want to own the object.

------------------------------------------------------------------------

# 11. Custom Order Experience

Custom order is a personal creative process.

It should feel like:

A private studio consultation.

Include:

-   idea;
-   references;
-   files;
-   communication;
-   approval.

------------------------------------------------------------------------

# 12. CRM Visual Direction

CRM is a professional creation workspace.

Not a generic admin panel.

Style:

-   clean;
-   efficient;
-   premium;
-   professional.

Use:

-   sidebar navigation;
-   clear information hierarchy;
-   production visualization.

------------------------------------------------------------------------

# 13. Animation Rules

Animations must be:

-   smooth;
-   cinematic;
-   meaningful.

Use:

-   fade;
-   depth transitions;
-   object movement;
-   subtle interactions.

Avoid:

-   fast effects;
-   distracting animations.

------------------------------------------------------------------------

# 14. Forbidden Design Patterns

Do not create:

-   generic ecommerce templates;
-   boring dashboards;
-   flat interfaces;
-   random AI-generated characters;
-   overloaded screens;
-   childish visuals.

------------------------------------------------------------------------

# Final Creative Goal

SigmaSpace should feel like:

A futuristic premium 3D creation universe where technology meets
craftsmanship.

Every interaction should communicate:

"Your creation is unique."
