SIGMASPACE DESIGN SPECIFICATION
(Visual Rules & Detailed Requirements)

This document defines the exact visual direction for the redesign.

Follow these rules strictly.

====================================

1. BRAND IDENTITY

SigmaSpace is not just an application.

It is a premium digital studio where users create personal collectible 3D figurines.

The interface must communicate:

- uniqueness;
- craftsmanship;
- technology;
- premium quality;
- personal creation.

The user should feel:
"I am creating a unique collectible object."

====================================

2. SIGMA FIGURINE VISUAL SYSTEM

The Sigma figurine is the central identity element.

IMPORTANT:

Never use:
- generic characters;
- random avatars;
- unrelated 3D models.

Always design around the Sigma character.

Visual behavior:

The figurine should have:

- realistic depth;
- layered composition;
- physical presence;
- soft shadows;
- cinematic lighting.

Use effects:

- parallax movement;
- floating elements;
- depth separation;
- object emerging from the interface.

Special rule:

Some parts of the figurine can go outside the container:

Example:
- hair;
- horns;
- accessories.

This creates a 3D illusion.

====================================

3. GLOBAL UI STYLE

The whole application should look like:

A futuristic premium 3D showroom.

Colors:

Primary:
- deep black;
- graphite;
- dark metallic tones.

Accent:
- premium glowing elements;
- subtle futuristic highlights.

Avoid:

- bright childish colors;
- gaming UI;
- excessive neon;
- clutter.

====================================

4. CARD DESIGN SYSTEM

All cards must feel physical.

Product cards:

Include:

- large visual focus;
- 3D object presentation;
- price;
- minimal information;
- smooth interaction.

Card behavior:

Hover/tap:

- slight movement;
- depth increase;
- lighting change;
- smooth animation.

Cards should not look like normal web blocks.

They should feel like objects.

====================================

5. MAIN SCREEN

The home screen is the showroom.

Structure:

Top:
- Sigma identity;
- premium greeting;
- featured object.

Middle:
- collections;
- recommendations;
- popular creations.

Bottom:
- permanent navigation.

The first impression must be:
"I entered a premium 3D workshop."

====================================

6. BOTTOM NAVIGATION RULE

The bottom navigation is a fixed brand element.

Rules:

- Must remain identical on every screen.
- Must feel premium.
- Must not change depending on page.

Central button:

- Sigma symbol only.
- No figurine head.
- Clean minimal shape.
- Main home action.

The button should feel like:
a physical control element.

====================================

7. SPLASH SCREEN

The first experience must be cinematic.

Elements:

- SigmaSpace logo;
- dark background;
- slowly appearing figurine;
- rotating energy ring;
- loading messages.

Animation feeling:

Technology + craftsmanship.

Example messages:

"Preparing catalogs..."
"Building recommendations..."
"Loading your universe..."

====================================

8. PRODUCT PAGE

The product page should feel like opening a premium product box.

Structure:

Large:
- figurine showcase.

Below:

- variations;
- clothing options;
- materials;
- price;
- customization.

Images:

Use cinematic gallery style.

The user should want to own the object.

====================================

9. CUSTOM ORDER EXPERIENCE

Custom orders are not normal products.

They require a different experience.

The user provides:

- idea;
- description;
- references;
- files;
- expectations.

The interface should feel like:

"I am working directly with an artist."

Include:

- conversation;
- feedback;
- calculation;
- approval.

====================================

10. CALCULATOR

The calculator must be simple.

Do not overload.

Focus:

User selects:
- size;
- complexity;
- materials;
- extras.

The result should appear clearly.

====================================

11. ORDER TRACKING

Production must feel alive.

Use timeline:

Request
↓
Concept
↓
3D Modeling
↓
Printing
↓
Processing
↓
Painting
↓
Quality Check
↓
Shipping

Visual style:

Premium progress system.

====================================

12. CRM MASTER DESIGN

CRM is a professional workspace.

Not a normal admin panel.

Design:

Desktop/tablet optimized.

Structure:

Left sidebar.

Sections:

Dashboard
Orders
Customers
Custom Requests
Files
Messages
Production
Materials
Pricing
Settings

Order card:

Contains:

- customer;
- figurine;
- files;
- references;
- messages;
- payment;
- production stage.

The master should manage everything from one place.

====================================

13. ANIMATION LANGUAGE

Animations must be:

- smooth;
- premium;
- meaningful.

Use:

- fade;
- slide;
- depth transitions;
- object movement.

Avoid:

- fast effects;
- distracting motion;
- unnecessary animation.

====================================

14. UX PRINCIPLES

Every screen must answer:

"What should the user do next?"

Rules:

- one main action per screen;
- clear hierarchy;
- minimal cognitive load;
- premium simplicity.

====================================

15. DO NOT DO

Never create:

- generic dashboards;
- standard ecommerce templates;
- boring cards;
- random gradients;
- overcrowded layouts;
- cheap 3D effects.

The result must NOT look like:
a regular online store.

It must look like:
a premium 3D creation platform.

====================================

FINAL CREATIVE GOAL

SigmaSpace should feel like:

A futuristic studio where technology meets craftsmanship.

Every interaction should make the user feel:
"This is my unique creation."