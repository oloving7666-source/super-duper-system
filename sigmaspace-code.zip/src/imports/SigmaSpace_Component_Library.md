# SigmaSpace Component Library

Reusable UI system.

## Buttons

Types: - Primary - Secondary - Ghost - Action

States: - Default - Hover - Active - Disabled - Loading

------------------------------------------------------------------------

## Cards

Product Card: - image - title - price - action

Custom Order Card: - description - files - status

Order Card: - progress - stage - details

CRM Card: - customer - order - production status

------------------------------------------------------------------------

## Navigation

Bottom Navigation: - fixed - glass style - central Sigma button

Sidebar Navigation: - CRM only

------------------------------------------------------------------------

## Feedback Components

Create: - loading states - empty states - error states - success states

------------------------------------------------------------------------

## Rules

Every component: - reusable - consistent - scalable
