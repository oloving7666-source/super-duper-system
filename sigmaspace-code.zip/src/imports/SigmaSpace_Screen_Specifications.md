# SigmaSpace Screen Specifications

## Purpose

Detailed screen-by-screen product specification for the SigmaSpace
Telegram Mini App redesign.

------------------------------------------------------------------------

# Screen 0 --- Splash Screen

Goal: Create the first emotional connection.

Elements: - SigmaSpace logo - dark cinematic background - Sigma figurine
appearance - rotating energy ring - loading messages

Animation: - logo reveal - ring rotation - figurine depth appearance -
smooth transition to app

Avoid: - generic loading spinners

------------------------------------------------------------------------

# Screen 1 --- Important Welcome Message

Purpose: Show important information.

Style: Premium notification card.

Elements: - headline - important message - action button

------------------------------------------------------------------------

# Screen 2 --- Home / Catalog

Purpose: Premium showroom.

Elements: - featured creations - collections - recommendations -
categories

Feeling: Digital exhibition, not ecommerce.

------------------------------------------------------------------------

# Screen 3 --- Product Card

Elements: - figurine preview - name - version - price - short
description

Interaction: Card expands into premium product view.

------------------------------------------------------------------------

# Screen 4 --- Photo Viewer

Elements: - fullscreen images - swipe navigation - smooth zoom

Feeling: Luxury product gallery.

------------------------------------------------------------------------

# Screen 5 --- Price Calculator

Elements: - size - complexity - materials - additional options - final
price

Rule: Simple and clear.

------------------------------------------------------------------------

# Screen 6 --- Calculation Result

Show: - configuration - price - next action

------------------------------------------------------------------------

# Screen 7 --- Custom Order

Different from normal products.

Elements: - idea description - references - files - communication -
approval

Feeling: Private studio consultation.

------------------------------------------------------------------------

# Screen 8 --- Cart

Elements: - selected items - custom orders - totals - edit actions

------------------------------------------------------------------------

# Screen 9 --- Checkout

Elements: - customer information - delivery - payment choice -
confirmation

------------------------------------------------------------------------

# Screen 10 --- Payment

Elements: - payment methods - payment status - confirmation

------------------------------------------------------------------------

# Screen 11 --- Success

Elements: - thank you message - order number - tracking button

------------------------------------------------------------------------

# Screen 12 --- My Orders

Elements: - active orders - completed orders - history

------------------------------------------------------------------------

# Screen 13 --- Order Details

Elements: - figurine - files - price - production stages - communication

------------------------------------------------------------------------

# Screen 14 --- Production Tracking

Stages:

Request received Concept 3D Modeling Printing Processing Painting
Quality Check Shipping

------------------------------------------------------------------------

# Screen 15 --- Favorites

Elements: - saved creations - quick actions

------------------------------------------------------------------------

# Screen 16 --- Profile

Elements: - user data - settings - addresses - payments

------------------------------------------------------------------------

# Screen 17 --- Edit Profile

Elements: - personal information - updates

------------------------------------------------------------------------

# Screen 18 --- Delivery and Payment Settings

Elements: - addresses - payment methods

------------------------------------------------------------------------

# Screen 19 --- CRM Master Panel

Professional workspace.

Sections: - Dashboard - Orders - Customers - Files - Messages -
Production - Materials - Pricing - Settings
