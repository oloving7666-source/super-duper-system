# SigmaSpace User Flow Map

## Main Purchase Flow

Open App

↓

Splash Screen

↓

Home / Catalog

↓

Product

↓

Customization

↓

Calculator

↓

Checkout

↓

Payment

↓

Order Tracking

↓

Delivery

------------------------------------------------------------------------

## Custom Order Flow

Start Custom Order

↓

Idea Description

↓

Reference Upload

↓

File Upload

↓

Master Discussion

↓

Price Calculation

↓

Approval

↓

Production

↓

Delivery

------------------------------------------------------------------------

## User Experience Rules

Every step must: - be clear - have one main action - reduce confusion -
maintain premium feeling
