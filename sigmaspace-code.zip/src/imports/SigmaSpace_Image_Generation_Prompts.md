# SigmaSpace Image Generation Prompts

## Sigma Figurine

Create a premium collectible 3D Sigma figurine.

Style: - realistic materials - cinematic lighting - luxury product
photography - detailed surfaces - dark premium background

------------------------------------------------------------------------

## Product Render

Premium collectible figurine product render.

Include: - studio lighting - realistic shadows - high-end presentation

------------------------------------------------------------------------

## Splash Screen

Futuristic SigmaSpace loading scene.

Include: - dark environment - glowing energy ring - Sigma figurine
reveal - cinematic atmosphere

------------------------------------------------------------------------

## Backgrounds

Create: - futuristic studio environments - premium dark surfaces -
subtle technology atmosphere

------------------------------------------------------------------------

## Rules

Never generate: - random characters - cartoon style - cheap gaming
visuals
