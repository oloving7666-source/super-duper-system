/**
 * Защита изображений от скачивания.
 *
 * Гасим на всём сайте контекстное меню и перетаскивание для картинок, видео и
 * блоков с фоновым изображением: правой кнопкой или долгим нажатием на телефоне
 * больше не открыть «Сохранить изображение как…» и «Копировать ссылку».
 * Поля ввода и текст не трогаем — там меню (вставить/копировать) нужно.
 */

/** Есть ли у элемента или его родителей картинка, которую можно сохранить. */
function isMedia(target: EventTarget | null): boolean {
  let el = target instanceof Element ? target : null
  for (let depth = 0; el && depth < 6; depth++, el = el.parentElement) {
    const tag = el.tagName
    if (tag === 'IMG' || tag === 'VIDEO' || tag === 'PICTURE' || tag === 'SOURCE' || tag === 'CANVAS') return true
    if (tag === 'INPUT' || tag === 'TEXTAREA' || el.getAttribute('contenteditable') === 'true') return false
    const bg = getComputedStyle(el).backgroundImage
    if (bg && bg !== 'none' && bg.includes('url(')) return true
  }
  return false
}

/** Вешает глобальные обработчики один раз при старте приложения. */
export function protectMedia() {
  document.addEventListener('contextmenu', e => { if (isMedia(e.target)) e.preventDefault() }, { capture: true })
  document.addEventListener('dragstart', e => { if (isMedia(e.target)) e.preventDefault() }, { capture: true })
}
