// Обрезка изображения по выбранной области (react-easy-crop) в квадратный файл.
export interface PixelCrop { x: number; y: number; width: number; height: number }

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.crossOrigin = 'anonymous' // нужно, чтобы canvas не «испортился» для внешних URL
    img.onload = () => resolve(img)
    img.onerror = () => reject(new Error('Не удалось загрузить изображение для обрезки'))
    img.src = src
  })
}

// Возвращает готовый к загрузке File с обрезанным квадратом.
export async function getCroppedFile(src: string, area: PixelCrop, size = 800): Promise<File> {
  const img = await loadImage(src)
  const canvas = document.createElement('canvas')
  canvas.width = size
  canvas.height = size
  const ctx = canvas.getContext('2d')
  if (!ctx) throw new Error('Canvas недоступен')
  ctx.imageSmoothingQuality = 'high'
  ctx.drawImage(img, area.x, area.y, area.width, area.height, 0, 0, size, size)
  const blob: Blob = await new Promise((resolve, reject) =>
    canvas.toBlob(b => (b ? resolve(b) : reject(new Error('Не удалось создать изображение'))), 'image/jpeg', 0.9),
  )
  return new File([blob], `crop-${Date.now()}.jpg`, { type: 'image/jpeg' })
}

// Обрезка с сохранением пропорций выбранной области (не только квадрат) —
// нужна для постов в канал, где кадр может быть 1:1, 4:5 или 16:9.
export async function getCroppedRectFile(src: string, area: PixelCrop, maxDim = 1280): Promise<File> {
  const img = await loadImage(src)
  const scale = Math.min(1, maxDim / Math.max(area.width, area.height))
  const canvas = document.createElement('canvas')
  canvas.width = Math.max(2, Math.round(area.width * scale))
  canvas.height = Math.max(2, Math.round(area.height * scale))
  const ctx = canvas.getContext('2d')
  if (!ctx) throw new Error('Canvas недоступен')
  ctx.imageSmoothingQuality = 'high'
  ctx.drawImage(img, area.x, area.y, area.width, area.height, 0, 0, canvas.width, canvas.height)
  const blob: Blob = await new Promise((resolve, reject) =>
    canvas.toBlob(b => (b ? resolve(b) : reject(new Error('Не удалось создать изображение'))), 'image/jpeg', 0.9),
  )
  return new File([blob], `crop-${Date.now()}.jpg`, { type: 'image/jpeg' })
}

// ── Видео ───────────────────────────────────────────────────────────────────
// Кадрирование видео возможно только пересборкой через MediaRecorder. Telegram
// корректно показывает лишь mp4, поэтому без поддержки mp4 в браузере обрезку
// не предлагаем — видео уйдёт как есть.
const MP4_MIME = 'video/mp4;codecs=avc1.42E01E,mp4a.40.2'
const MP4_MIME_VIDEO_ONLY = 'video/mp4;codecs=avc1.42E01E'

export function canCropVideo(): boolean {
  return typeof MediaRecorder !== 'undefined' &&
    (MediaRecorder.isTypeSupported(MP4_MIME) || MediaRecorder.isTypeSupported(MP4_MIME_VIDEO_ONLY))
}

export interface VideoMeta { width: number; height: number; duration: number }

export function readVideoMeta(src: string): Promise<VideoMeta> {
  return new Promise((resolve, reject) => {
    const v = document.createElement('video')
    v.preload = 'metadata'
    v.onloadedmetadata = () => resolve({ width: v.videoWidth, height: v.videoHeight, duration: v.duration })
    v.onerror = () => reject(new Error('Не удалось прочитать видео'))
    v.src = src
  })
}

export interface CroppedVideo { file: File; width: number; height: number }

// Пересобирает видео по выбранной области. Работает в реальном времени: ролик
// проигрывается целиком, кадры перерисовываются в canvas и пишутся рекордером.
export async function getCroppedVideoFile(
  src: string,
  area: PixelCrop,
  maxDim = 1280,
  onProgress?: (percent: number) => void,
): Promise<CroppedVideo> {
  const video = document.createElement('video')
  video.src = src
  video.crossOrigin = 'anonymous'
  video.playsInline = true
  await new Promise<void>((resolve, reject) => {
    video.onloadedmetadata = () => resolve()
    video.onerror = () => reject(new Error('Не удалось загрузить видео для обрезки'))
  })

  const scale = Math.min(1, maxDim / Math.max(area.width, area.height))
  // Кодеку нужны чётные стороны.
  const even = (n: number) => Math.max(2, Math.round(n * scale / 2) * 2)
  const canvas = document.createElement('canvas')
  canvas.width = even(area.width)
  canvas.height = even(area.height)
  const ctx = canvas.getContext('2d')
  if (!ctx) throw new Error('Canvas недоступен')

  const stream = canvas.captureStream(30)
  // Звук берём из самого ролика, чтобы обрезка его не съела.
  try {
    const withAudio = (video as HTMLVideoElement & { captureStream?: () => MediaStream }).captureStream?.()
    for (const track of withAudio?.getAudioTracks() ?? []) stream.addTrack(track)
  } catch { /* без звука */ }

  const mime = MediaRecorder.isTypeSupported(MP4_MIME) ? MP4_MIME : MP4_MIME_VIDEO_ONLY
  const recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 4_000_000 })
  const chunks: Blob[] = []
  recorder.ondataavailable = e => { if (e.data.size) chunks.push(e.data) }

  const done = new Promise<void>(resolve => { recorder.onstop = () => resolve() })
  recorder.start(200)

  let raf = 0
  const draw = () => {
    ctx.drawImage(video, area.x, area.y, area.width, area.height, 0, 0, canvas.width, canvas.height)
    if (video.duration) onProgress?.(Math.min(99, Math.round((video.currentTime / video.duration) * 100)))
    raf = requestAnimationFrame(draw)
  }

  try {
    await video.play()
  } catch {
    // Автовоспроизведение со звуком заблокировано — пишем без звука.
    video.muted = true
    await video.play()
  }
  draw()

  await new Promise<void>(resolve => { video.onended = () => resolve() })
  cancelAnimationFrame(raf)
  recorder.stop()
  await done
  onProgress?.(100)

  const blob = new Blob(chunks, { type: 'video/mp4' })
  return {
    file: new File([blob], `crop-${Date.now()}.mp4`, { type: 'video/mp4' }),
    width: canvas.width,
    height: canvas.height,
  }
}
