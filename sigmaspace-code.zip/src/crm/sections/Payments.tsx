import { Icon, PAY_METHOD_DEFS } from '../../shared'
import type { CrmCtx } from '../state'

export default function PaymentsSection(ctx: CrmCtx) {
  const { payEnabled, setPayEnabled } = ctx
  return (<>
      {(
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div>
              <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: '0 0 4px' }}>Способы оплаты</p>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Включайте и выключайте приём оплаты. Выключенный способ сразу пропадает из выбора у покупателей.</p>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {PAY_METHOD_DEFS.map(m => {
                const on = !m.comingSoon && payEnabled[m.key]
                return (
                  <div key={m.key} className="glass-card" style={{ padding: '14px', display: 'flex', alignItems: 'center', gap: '12px', opacity: m.comingSoon ? 0.7 : 1 }}>
                    <div style={{ width: '40px', height: '40px', borderRadius: '11px', background: on ? 'var(--accent-2-wash)' : 'var(--bg-elevated)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <Icon name={m.icon} size={18} color={on ? 'var(--accent-2-hi)' : 'var(--text-muted)'} />
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: '0 0 2px' }}>{m.label}</p>
                      <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0 }}>{m.comingSoon ? 'В разработке — скоро добавим' : m.sub}</p>
                    </div>
                    {m.comingSoon ? (
                      <span style={{ fontSize: '9px', fontWeight: 700, color: 'var(--accent-2-hi)', background: 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', borderRadius: '6px', padding: '3px 7px', flexShrink: 0 }}>Скоро</span>
                    ) : (
                      <button onClick={() => setPayEnabled(prev => ({ ...prev, [m.key]: !prev[m.key] }))}
                        aria-label={on ? 'Выключить' : 'Включить'}
                        style={{ width: '46px', height: '26px', borderRadius: '13px', border: 'none', cursor: 'pointer', flexShrink: 0, background: on ? 'var(--accent-2)' : 'var(--border)', position: 'relative', transition: 'background 0.2s' }}>
                        <span style={{ position: 'absolute', top: '3px', left: on ? '23px' : '3px', width: '20px', height: '20px', borderRadius: '50%', background: '#fff', transition: 'left 0.2s', boxShadow: '0 1px 3px rgba(0,0,0,0.3)' }} />
                      </button>
                    )}
                  </div>
                )
              })}
            </div>

            <div className="glass-card" style={{ padding: '12px 14px' }}>
              <p style={{ color: 'var(--text-secondary)', fontSize: '11px', margin: 0, lineHeight: 1.6 }}>
                🔑 Чтобы способ реально принимал деньги, в <b>Make → Settings → Secrets</b> должны быть заданы ключи провайдера, а edge-функция — задеплоена. Без ключей включённый способ выдаст ошибку при оплате.
              </p>
            </div>
          </div>
        )
      }
  </>)
}
