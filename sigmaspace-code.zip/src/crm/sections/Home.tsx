import { useRef, useState } from 'react'
import { storage } from '../../api'
import { boardStyle, compressImage, genHomeId, hScroll, INIT_HOME, Icon, resolveHomeImg, resolveBrandLogo, ROW_MODE_LABEL, type BoardStyle, type HomeRow } from '../../shared'
import type { CrmCtx } from '../state'

/**
 * Редактор главной страницы. Разбит на подразделы, чтобы длинная простыня
 * настроек не мешала: борды карусели, ряды товаров («Популярное», «Новинки»),
 * коллекции и оформление (логотип + карточки-преимущества).
 * Всё синхронизируется через ctx.setHome → облако.
 */

type Sub = 'boards' | 'rows' | 'colls' | 'brand'
const SUBS: Array<{ key: Sub; label: string }> = [
  { key: 'boards', label: 'Борды' },
  { key: 'rows', label: 'Ряды' },
  { key: 'colls', label: 'Коллекции' },
  { key: 'brand', label: 'Оформление' },
]

const input = { width: '100%', boxSizing: 'border-box' as const, background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '9px', padding: '8px 10px', color: 'var(--text-primary)', fontSize: '12px', outline: 'none', fontFamily: 'inherit' }
const lbl = { color: 'var(--text-muted)', fontSize: '10.5px', fontWeight: 600, margin: '0 0 4px' } as const
const card = { background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '14px', padding: '12px', display: 'flex', flexDirection: 'column' as const, gap: '9px' }
const addBtn = { width: '100%', marginTop: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '10px', background: 'var(--accent-2-wash)', border: '1px dashed var(--accent-2)', borderRadius: '10px', color: 'var(--accent-2-hi)', fontSize: '12px', fontWeight: 700, cursor: 'pointer' } as const

/** Ряд переключателей-пилюль для одного поля оформления борда. */
function Choice<T extends string>({ label, value, options, onChange }: {
  label: string; value: T; options: Array<{ v: T; t: string }>; onChange: (v: T) => void
}) {
  return (
    <div>
      <p style={lbl}>{label}</p>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px' }}>
        {options.map(o => {
          const on = o.v === value
          return (
            <button key={o.v} onClick={() => onChange(o.v)}
              style={{ padding: '6px 10px', borderRadius: '8px', cursor: 'pointer', fontSize: '11px', fontWeight: 600, fontFamily: 'inherit',
                background: on ? 'var(--accent-2-wash)' : 'var(--bg-elevated)', border: `1px solid ${on ? 'var(--accent-2)' : 'var(--border)'}`,
                color: on ? 'var(--accent-2-hi)' : 'var(--text-secondary)' }}>{o.t}</button>
          )
        })}
      </div>
    </div>
  )
}

/** Оформление борда: текст, затемнение, кнопка и свечение. */
function BoardStyleEditor({ value, onChange }: { value?: Partial<BoardStyle>; onChange: (patch: Partial<BoardStyle>) => void }) {
  const [open, setOpen] = useState(false)
  const st = boardStyle(value)
  return (
    <div>
      <button onClick={() => setOpen(v => !v)}
        style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '9px', padding: '9px 11px', cursor: 'pointer' }}>
        <span style={{ color: 'var(--text-secondary)', fontSize: '12px', fontWeight: 600 }}>Оформление борда</span>
        <Icon name={open ? 'chevron-down' : 'chevron-right'} size={14} color="var(--text-muted)" />
      </button>
      {open && (
        <div style={{ marginTop: '9px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0, lineHeight: 1.45 }}>
            Если текст уже есть на самой картинке — выключите подпись и затемнение.
          </p>
          <Choice label="Подпись" value={st.showText ? 'on' : 'off'} onChange={v => onChange({ showText: v === 'on' })}
            options={[{ v: 'on', t: 'Показывать' }, { v: 'off', t: 'Скрыть' }]} />
          {st.showText && <>
            <Choice label="Текст по горизонтали" value={st.textX} onChange={textX => onChange({ textX })}
              options={[{ v: 'left', t: 'Слева' }, { v: 'center', t: 'По центру' }, { v: 'right', t: 'Справа' }]} />
            <Choice label="Текст по вертикали" value={st.textY} onChange={textY => onChange({ textY })}
              options={[{ v: 'top', t: 'Сверху' }, { v: 'middle', t: 'По центру' }, { v: 'bottom', t: 'Снизу' }]} />
          </>}
          <Choice label="Кнопка" value={st.showCta ? 'on' : 'off'} onChange={v => onChange({ showCta: v === 'on' })}
            options={[{ v: 'on', t: 'Показывать' }, { v: 'off', t: 'Скрыть' }]} />
          {st.showCta && (
            <Choice label="Положение кнопки" value={st.ctaX} onChange={ctaX => onChange({ ctaX })}
              options={[{ v: 'left', t: 'Слева' }, { v: 'center', t: 'По центру' }, { v: 'right', t: 'Справа' }]} />
          )}
          <Choice label="Затемнение" value={st.scrim} onChange={scrim => onChange({ scrim })}
            options={[{ v: 'none', t: 'Нет' }, { v: 'left', t: 'Слева' }, { v: 'right', t: 'Справа' }, { v: 'bottom', t: 'Снизу' }, { v: 'full', t: 'Всё' }]} />
          {st.scrim !== 'none' && (
            <div>
              <p style={lbl}>Сила затемнения · {st.scrimStrength}%</p>
              <input type="range" min={0} max={100} step={5} value={st.scrimStrength}
                onChange={e => onChange({ scrimStrength: Number(e.target.value) })}
                style={{ width: '100%', accentColor: 'var(--accent-2)' }} />
            </div>
          )}
          <Choice label="Свечение и обводка" value={st.glow} onChange={glow => onChange({ glow })}
            options={[{ v: '', t: 'Без' }, { v: 'brand', t: 'Фиолетовое' }, { v: 'blue', t: 'Синее' }, { v: 'white', t: 'Белое' }]} />
        </div>
      )}
    </div>
  )
}

export default function HomeSection(ctx: CrmCtx) {
  const { products, setHome } = ctx
  const home = { ...INIT_HOME, ...ctx.home }
  const [sub, setSub] = useState<Sub>('boards')

  const fileRef = useRef<HTMLInputElement>(null)
  const applyRef = useRef<(url: string) => void>(() => {})
  const [uploading, setUploading] = useState<string | null>(null)
  const [expanded, setExpanded] = useState<string | null>(null)

  const keyRef = useRef<string>('')
  const pickImage = (key: string, apply: (url: string) => void) => {
    applyRef.current = (url) => { apply(url); setUploading(null) }
    keyRef.current = key
    fileRef.current?.click()
  }
  const onFile = async (file: File | undefined) => {
    if (!file || !file.type.startsWith('image/')) return
    const key = keyRef.current
    setUploading(key)
    try { const url = await storage.upload(await compressImage(file, 1280, 0.85)); applyRef.current(url) }
    catch (err) { alert(`Не удалось загрузить фото: ${(err as Error)?.message ?? 'ошибка'}`); setUploading(null) }
  }

  const patch = (p: Partial<typeof home>) => setHome(h => ({ ...INIT_HOME, ...h, ...p }))
  const patchBanner = (id: string, p: Partial<typeof home.banners[number]>) =>
    setHome(h => ({ ...INIT_HOME, ...h, banners: (h.banners ?? INIT_HOME.banners).map(b => b.id === id ? { ...b, ...p } : b) }))
  const patchColl = (id: string, p: Partial<typeof home.collections[number]>) =>
    setHome(h => ({ ...INIT_HOME, ...h, collections: (h.collections ?? INIT_HOME.collections).map(c => c.id === id ? { ...c, ...p } : c) }))
  const styleBanner = (id: string, p: Partial<BoardStyle>) =>
    setHome(h => ({ ...INIT_HOME, ...h, banners: (h.banners ?? INIT_HOME.banners).map(b => b.id === id ? { ...b, style: { ...boardStyle(b.style), ...p } } : b) }))
  const styleColl = (id: string, p: Partial<BoardStyle>) =>
    setHome(h => ({ ...INIT_HOME, ...h, collections: (h.collections ?? INIT_HOME.collections).map(c => c.id === id ? { ...c, style: { ...boardStyle(c.style), ...p } } : c) }))
  const toggleProduct = (cid: string, pid: number) =>
    setHome(h => ({ ...INIT_HOME, ...h, collections: (h.collections ?? INIT_HOME.collections).map(c => c.id === cid
      ? { ...c, productIds: c.productIds.includes(pid) ? c.productIds.filter(x => x !== pid) : [...c.productIds, pid] } : c) }))

  const UploadBtn = ({ k, apply, url }: { k: string; apply: (u: string) => void; url?: string }) => (
    <div style={{ display: 'flex', gap: '8px', alignItems: 'stretch' }}>
      <div style={{ width: '72px', height: '54px', borderRadius: '9px', overflow: 'hidden', background: 'var(--bg-input)', border: '1px solid var(--border)', flexShrink: 0 }}>
        {url ? <img src={url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : null}
      </div>
      <button onClick={() => pickImage(k, apply)} disabled={uploading === k}
        style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '9px', background: 'var(--bg-elevated)', border: '1px dashed var(--accent-2)', borderRadius: '9px', color: 'var(--accent-2-hi)', fontSize: '12px', fontWeight: 600, cursor: uploading === k ? 'default' : 'pointer', opacity: uploading === k ? 0.6 : 1 }}>
        <Icon name="camera" size={14} color="var(--accent-2-hi)" /> {uploading === k ? 'Загрузка…' : url ? 'Заменить фото' : 'Загрузить фото'}
      </button>
    </div>
  )

  // ── Настраиваемые ряды товаров ──
  const rows: HomeRow[] = home.rows ?? [
    { id: 'r-pop', title: 'Популярное', mode: (home.popular?.length ? 'manual' : 'popular'), ids: home.popular ?? [] },
    { id: 'r-new', title: 'Новинки', mode: (home.novelty?.length ? 'manual' : 'novelty'), ids: home.novelty ?? [] },
  ]
  const setRows = (fn: (rs: HomeRow[]) => HomeRow[]) => patch({ rows: fn(rows) })
  const patchRow = (id: string, p: Partial<HomeRow>) => setRows(rs => rs.map(r => r.id === id ? { ...r, ...p } : r))
  const moveRow = (i: number, d: number) => setRows(rs => { const n = [...rs]; const j = i + d; if (j < 0 || j >= n.length) return rs; [n[i], n[j]] = [n[j], n[i]]; return n })

  /** Карточка одного ряда: название, способ фильтрации и (для «вручную») состав. */
  const RowCard = ({ r, i }: { r: HomeRow; i: number }) => {
    const onIds = (ids: number[]) => patchRow(r.id, { ids })
    return (
      <div style={card}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <input value={r.title} onChange={e => patchRow(r.id, { title: e.target.value })} placeholder="Название ряда" style={{ ...input, flex: 1, fontWeight: 700 }} />
          <button onClick={() => moveRow(i, -1)} disabled={i === 0} title="Выше" style={{ background: 'none', border: 'none', cursor: i === 0 ? 'default' : 'pointer', padding: '2px', opacity: i === 0 ? 0.3 : 1 }}><span style={{ display: 'flex', transform: 'rotate(180deg)' }}><Icon name="chevron-down" size={14} color="var(--text-muted)" /></span></button>
          <button onClick={() => moveRow(i, 1)} disabled={i === rows.length - 1} title="Ниже" style={{ background: 'none', border: 'none', cursor: i === rows.length - 1 ? 'default' : 'pointer', padding: '2px', opacity: i === rows.length - 1 ? 0.3 : 1 }}><Icon name="chevron-down" size={14} color="var(--text-muted)" /></button>
          <button onClick={() => setRows(rs => rs.filter(x => x.id !== r.id))} title="Удалить ряд" style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px' }}><Icon name="trash" size={14} color="var(--danger)" /></button>
        </div>
        <Choice label="Как фильтровать" value={r.mode}
          onChange={(mode: HomeRow['mode']) => patchRow(r.id, { mode })}
          options={[
            { v: 'popular', t: 'Популярность' },
            { v: 'orders', t: 'Кол-во заказов' },
            { v: 'novelty', t: 'Новизна' },
            { v: 'manual', t: 'Вручную' },
          ]} />
        {r.mode === 'manual' ? (
          <>
            <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', margin: 0, lineHeight: 1.45 }}>Выберите товары и порядок вручную.</p>
            {r.ids.length > 0 && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                {r.ids.map((id, k) => {
                  const p = products.find(x => x.id === id)
                  const move = (d: number) => { const n = [...r.ids]; const j = k + d; if (j < 0 || j >= n.length) return; [n[k], n[j]] = [n[j], n[k]]; onIds(n) }
                  return (
                    <div key={id} style={{ display: 'flex', alignItems: 'center', gap: '8px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '9px', padding: '6px 8px' }}>
                      <span style={{ flex: 1, minWidth: 0, color: 'var(--text-primary)', fontSize: '12px', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p?.name ?? `Товар #${id}`}</span>
                      <button onClick={() => move(-1)} title="Выше" style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px' }}><span style={{ display: 'flex', transform: 'rotate(180deg)' }}><Icon name="chevron-down" size={13} color="var(--text-muted)" /></span></button>
                      <button onClick={() => move(1)} title="Ниже" style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px' }}><Icon name="chevron-down" size={13} color="var(--text-muted)" /></button>
                      <button onClick={() => onIds(r.ids.filter(x => x !== id))} title="Убрать" style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px' }}><Icon name="trash" size={13} color="var(--danger)" /></button>
                    </div>
                  )
                })}
              </div>
            )}
            <div style={{ maxHeight: '240px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '5px' }}>
              {products.length === 0 && <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '4px 2px' }}>Нет товаров. Добавьте их в разделе «Товары».</p>}
              {products.filter(p => !r.ids.includes(p.id)).map(p => (
                <button key={p.id} onClick={() => onIds([...r.ids, p.id])}
                  style={{ display: 'flex', alignItems: 'center', gap: '9px', padding: '6px 8px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '9px', cursor: 'pointer', textAlign: 'left' }}>
                  <img src={p.img} alt="" style={{ width: '30px', height: '30px', borderRadius: '6px', objectFit: 'cover', flexShrink: 0 }} onError={e => (e.currentTarget.style.visibility = 'hidden')} />
                  <span style={{ flex: 1, minWidth: 0, color: 'var(--text-primary)', fontSize: '12px', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</span>
                  <Icon name="plus" size={14} color="var(--accent-2-hi)" />
                </button>
              ))}
            </div>
          </>
        ) : (
          <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', margin: 0, lineHeight: 1.45 }}>Показываются до 10 товаров, {ROW_MODE_LABEL[r.mode].toLowerCase()}.</p>
        )}
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <input ref={fileRef} type="file" accept="image/*" onChange={e => { onFile(e.target.files?.[0]); e.target.value = '' }} style={{ display: 'none' }} />

      <div>
        <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: '0 0 4px' }}>Главная страница</p>
        <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Борды, ряды товаров и коллекции. Открывается тапом по центральной кнопке Σ.</p>
      </div>

      {/* Подразделы */}
      <div ref={hScroll} style={{ display: 'flex', gap: '5px', overflowX: 'auto', scrollbarWidth: 'none' }}>
        {SUBS.map(s => {
          const on = s.key === sub
          return (
            <button key={s.key} onClick={() => setSub(s.key)}
              style={{ flexShrink: 0, padding: '8px 13px', borderRadius: '10px', cursor: 'pointer', fontFamily: 'inherit', fontSize: '12px', fontWeight: on ? 700 : 600,
                background: on ? 'var(--accent-2-wash)' : 'var(--bg-elevated)', border: `1px solid ${on ? 'var(--accent-2)' : 'var(--border)'}`,
                color: on ? 'var(--accent-2-hi)' : 'var(--text-secondary)' }}>{s.label}</button>
          )
        })}
      </div>

      {/* ── Борды карусели ── */}
      {sub === 'boards' && (
        <div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {home.banners.map((b, i) => (
              <div key={b.id} style={card}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--accent)', fontSize: '11px', fontWeight: 700 }}>Слайд {i + 1}</span>
                  <button onClick={() => setHome(h => ({ ...INIT_HOME, ...h, banners: h.banners.filter(x => x.id !== b.id) }))}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '3px' }} title="Удалить слайд"><Icon name="trash" size={14} color="var(--danger)" /></button>
                </div>
                <UploadBtn k={`b-${b.id}`} url={resolveHomeImg(b.id, b.image)} apply={url => patchBanner(b.id, { image: url })} />
                <div><p style={lbl}>Метка сверху</p><input value={b.eyebrow ?? ''} onChange={e => patchBanner(b.id, { eyebrow: e.target.value })} placeholder="Например: Следующая коллекция" style={input} /></div>
                <div><p style={lbl}>Заголовок</p><textarea value={b.title} onChange={e => patchBanner(b.id, { title: e.target.value })} rows={2} style={{ ...input, resize: 'vertical' }} /></div>
                <div><p style={lbl}>Подзаголовок</p><textarea value={b.subtitle} onChange={e => patchBanner(b.id, { subtitle: e.target.value })} rows={2} style={{ ...input, resize: 'vertical' }} /></div>
                <div><p style={lbl}>Текст кнопки</p><input value={b.cta} onChange={e => patchBanner(b.id, { cta: e.target.value })} style={input} /></div>
                <div><p style={lbl}>Ведёт в коллекцию</p>
                  <select value={b.collectionId} onChange={e => patchBanner(b.id, { collectionId: e.target.value })} style={{ ...input, appearance: 'none' }}>
                    <option value="">— не задано —</option>
                    {home.collections.map(c => <option key={c.id} value={c.id}>{c.title}</option>)}
                  </select>
                </div>
                <BoardStyleEditor value={b.style} onChange={p => styleBanner(b.id, p)} />
              </div>
            ))}
          </div>
          <button onClick={() => setHome(h => ({ ...INIT_HOME, ...h, banners: [...h.banners, { id: genHomeId('hb'), image: '', title: 'Новый баннер', subtitle: '', cta: 'Смотреть коллекцию', collectionId: '' }] }))} style={addBtn}>
            <Icon name="plus" size={14} color="var(--accent-2-hi)" /> Добавить слайд
          </button>
        </div>
      )}

      {/* ── Ряды товаров ── */}
      {sub === 'rows' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0, lineHeight: 1.5 }}>Ряды товаров на главной. Задайте название и способ фильтрации — по популярности, количеству заказов, новизне или выберите товары вручную.</p>
          {rows.map((r, i) => <RowCard key={r.id} r={r} i={i} />)}
          <button onClick={() => setRows(rs => [...rs, { id: genHomeId('row'), title: 'Новый ряд', mode: 'popular', ids: [] }])} style={addBtn}>
            <Icon name="plus" size={15} color="var(--accent-2-hi)" /> Добавить ряд
          </button>
        </div>
      )}

      {/* ── Коллекции ── */}
      {sub === 'colls' && (
        <div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {home.collections.map(c => {
              const open = expanded === c.id
              return (
                <div key={c.id} style={card}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span style={{ color: 'var(--accent)', fontSize: '11px', fontWeight: 700 }}>{c.title || 'Коллекция'}</span>
                    <button onClick={() => setHome(h => ({ ...INIT_HOME, ...h, collections: h.collections.filter(x => x.id !== c.id) }))}
                      style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '3px' }} title="Удалить коллекцию"><Icon name="trash" size={14} color="var(--danger)" /></button>
                  </div>
                  <UploadBtn k={`c-${c.id}`} url={resolveHomeImg(c.id, c.image)} apply={url => patchColl(c.id, { image: url })} />
                  <div><p style={lbl}>Метка сверху</p><input value={c.eyebrow ?? ''} onChange={e => patchColl(c.id, { eyebrow: e.target.value })} placeholder="Например: Sigma Space" style={input} /></div>
                  <div><p style={lbl}>Название</p><textarea value={c.title} onChange={e => patchColl(c.id, { title: e.target.value })} rows={2} style={{ ...input, resize: 'vertical' }} /></div>
                  <div><p style={lbl}>Подзаголовок</p><textarea value={c.subtitle} onChange={e => patchColl(c.id, { subtitle: e.target.value })} rows={2} style={{ ...input, resize: 'vertical' }} /></div>
                  <div><p style={lbl}>Текст кнопки</p><input value={c.cta} onChange={e => patchColl(c.id, { cta: e.target.value })} style={input} /></div>
                  <BoardStyleEditor value={c.style} onChange={p => styleColl(c.id, p)} />

                  <div>
                    <button onClick={() => setExpanded(open ? null : c.id)}
                      style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '9px', padding: '9px 11px', cursor: 'pointer' }}>
                      <span style={{ color: 'var(--text-secondary)', fontSize: '12px', fontWeight: 600 }}>Товары коллекции · выбрано {c.productIds.length}</span>
                      <Icon name={open ? 'chevron-down' : 'chevron-right'} size={14} color="var(--text-muted)" />
                    </button>
                    {open && (
                      <div style={{ marginTop: '8px', maxHeight: '260px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                        {products.length === 0 && <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '4px 2px' }}>Нет товаров. Добавьте их в разделе «Товары».</p>}
                        {products.map(p => {
                          const on = c.productIds.includes(p.id)
                          return (
                            <button key={p.id} onClick={() => toggleProduct(c.id, p.id)}
                              style={{ display: 'flex', alignItems: 'center', gap: '9px', padding: '6px 8px', background: on ? 'var(--accent-2-wash)' : 'var(--bg-elevated)', border: `1px solid ${on ? 'var(--accent-2)' : 'var(--border)'}`, borderRadius: '9px', cursor: 'pointer', textAlign: 'left' }}>
                              <img src={p.img} alt="" style={{ width: '32px', height: '32px', borderRadius: '6px', objectFit: 'cover', flexShrink: 0 }} onError={e => (e.currentTarget.style.visibility = 'hidden')} />
                              <span style={{ flex: 1, minWidth: 0 }}>
                                <span style={{ display: 'block', color: 'var(--text-primary)', fontSize: '12px', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</span>
                                <span style={{ display: 'block', color: 'var(--text-muted)', fontSize: '10px' }}>{p.series}</span>
                              </span>
                              <span style={{ width: '18px', height: '18px', borderRadius: '5px', flexShrink: 0, display: 'grid', placeItems: 'center', background: on ? 'var(--accent-2)' : 'transparent', border: on ? 'none' : '1px solid var(--border)' }}>
                                {on && <Icon name="check" size={12} color="#fff" strokeWidth={2.6} />}
                              </span>
                            </button>
                          )
                        })}
                        <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '4px 2px 0', lineHeight: 1.45 }}>Если ничего не выбрано, в коллекцию автоматически попадут товары с серией «{c.title}».</p>
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
          <button onClick={() => setHome(h => ({ ...INIT_HOME, ...h, collections: [...h.collections, { id: genHomeId('hc'), title: 'Новая коллекция', subtitle: '', image: '', cta: 'Смотреть коллекцию', productIds: [] }] }))} style={addBtn}>
            <Icon name="plus" size={14} color="var(--accent-2-hi)" /> Добавить коллекцию
          </button>
        </div>
      )}

      {/* ── Оформление: логотип и карточки-преимущества ── */}
      {sub === 'brand' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <div style={card}>
            <span style={{ color: 'var(--accent)', fontSize: '11px', fontWeight: 700 }}>Логотип и название</span>
            <div style={{ display: 'flex', gap: '8px', alignItems: 'stretch' }}>
              <div style={{ width: '54px', height: '54px', borderRadius: '12px', overflow: 'hidden', background: 'var(--bg-input)', border: '1px solid var(--border)', flexShrink: 0, display: 'grid', placeItems: 'center' }}>
                <img src={resolveBrandLogo(home.brand?.logo)} alt="" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
              </div>
              <button onClick={() => pickImage('brand', url => patch({ brand: { ...INIT_HOME.brand, ...home.brand, logo: url } }))} disabled={uploading === 'brand'}
                style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '9px', background: 'var(--bg-elevated)', border: '1px dashed var(--accent-2)', borderRadius: '9px', color: 'var(--accent-2-hi)', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}>
                <Icon name="camera" size={14} color="var(--accent-2-hi)" /> {uploading === 'brand' ? 'Загрузка…' : 'Заменить логотип'}
              </button>
            </div>
            {home.brand?.logo && (
              <button onClick={() => patch({ brand: { ...INIT_HOME.brand, ...home.brand, logo: '' } })}
                style={{ alignSelf: 'flex-start', background: 'none', border: 'none', color: 'var(--danger)', fontSize: '11px', fontWeight: 600, cursor: 'pointer', padding: '2px 0' }}>Вернуть стандартный</button>
            )}
            <div><p style={lbl}>Название</p><input value={home.brand?.title ?? ''} onChange={e => patch({ brand: { ...INIT_HOME.brand, ...home.brand, title: e.target.value } })} style={input} /></div>
            <div><p style={lbl}>Подпись под названием</p><input value={home.brand?.subtitle ?? ''} onChange={e => patch({ brand: { ...INIT_HOME.brand, ...home.brand, subtitle: e.target.value } })} style={input} /></div>
            <div>
              <p style={lbl}>Размер логотипа — {home.brand?.logoSize ?? 48}px</p>
              <input type="range" min={32} max={72} step={1} value={home.brand?.logoSize ?? 48}
                onChange={e => patch({ brand: { ...INIT_HOME.brand, ...home.brand, logoSize: Number(e.target.value) } })}
                style={{ width: '100%', accentColor: 'var(--accent-2)' }} />
            </div>
          </div>
          <div style={card}>
            <span style={{ color: 'var(--accent)', fontSize: '11px', fontWeight: 700 }}>Верхние коллекции</span>
            <div>
              <p style={lbl}>Высота коллекций — {home.collectionHeight ?? 158}px</p>
              <input type="range" min={110} max={260} step={2} value={home.collectionHeight ?? 158}
                onChange={e => patch({ collectionHeight: Number(e.target.value) })}
                style={{ width: '100%', accentColor: 'var(--accent-2)' }} />
            </div>
          </div>
          <div style={card}>
            <span style={{ color: 'var(--accent)', fontSize: '11px', fontWeight: 700 }}>Sigma Club</span>
            <div><p style={lbl}>Заголовок</p><input value={home.club.title} onChange={e => setHome(h => ({ ...INIT_HOME, ...h, club: { ...h.club, title: e.target.value } }))} style={input} /></div>
            <div><p style={lbl}>Текст</p><input value={home.club.text} onChange={e => setHome(h => ({ ...INIT_HOME, ...h, club: { ...h.club, text: e.target.value } }))} style={input} /></div>
          </div>
          <div style={card}>
            <span style={{ color: 'var(--accent)', fontSize: '11px', fontWeight: 700 }}>Быстрая доставка</span>
            <div><p style={lbl}>Заголовок</p><input value={home.delivery.title} onChange={e => setHome(h => ({ ...INIT_HOME, ...h, delivery: { ...h.delivery, title: e.target.value } }))} style={input} /></div>
            <div><p style={lbl}>Текст</p><input value={home.delivery.text} onChange={e => setHome(h => ({ ...INIT_HOME, ...h, delivery: { ...h.delivery, text: e.target.value } }))} style={input} /></div>
          </div>
        </div>
      )}
    </div>
  )
}
