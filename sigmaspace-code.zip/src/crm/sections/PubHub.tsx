import PublicationsModule from '../../Publications'
import type { CrmCtx } from '../state'

export default function PubHubSection(ctx: CrmCtx) {
  void ctx
  return (<>
      {(
          <div style={{ margin: '-12px', height: 'calc(100% + 24px)' }}>
            <PublicationsModule />
          </div>
        )
      }
  </>)
}
