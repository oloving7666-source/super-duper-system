import { Icon, CATALOG_FILTER_KINDS, genFilterId, type CatalogFilterKind } from '../../shared'
import type { CrmCtx } from '../state'

export default function SectionsSection(ctx: CrmCtx) {
  const { addSec, editingSecId, editingSecName, newSec, products, secDragIdx, secDragOverIdx, sections, setAddSec, setEditingSecId, setEditingSecName, setNewSec, setSecDragOverIdx, setSectionsCloud, catalogFilters, setCatalogFilters } = ctx

  const patchFilter = (id: string, patch: Partial<{ label: string; hint: string; kind: CatalogFilterKind; enabled: boolean }>) =>
    setCatalogFilters(prev => prev.map(f => f.id === id ? { ...f, ...patch } : f))
  const moveFilter = (idx: number, dir: -1 | 1) => setCatalogFilters(prev => {
    const arr = [...prev]; const to = idx + dir
    if (to < 0 || to >= arr.length) return prev
    const [m] = arr.splice(idx, 1); arr.splice(to, 0, m); return arr
  })
  const addFilter = () => setCatalogFilters(prev => {
    const def = CATALOG_FILTER_KINDS[0]
    return [...prev, { id: genFilterId(), label: def.label, hint: def.hint, kind: def.kind, enabled: true }]
  })
  const removeFilter = (id: string) => setCatalogFilters(prev => prev.filter(f => f.id !== id))

  return (<>
      {(
          <div>
            <button className="btn-primary" style={{ marginBottom: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }} onClick={() => setAddSec(true)}>
              <Icon name="plus" size={14} color="#fff" /> Добавить раздел
            </button>
            {addSec && (
              <div className="glass-card" style={{ padding: '12px', marginBottom: '10px' }}>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 500, margin: '0 0 5px' }}>Название</p>
                <input value={newSec.name} onChange={e => setNewSec(p=>({...p,name:e.target.value}))} placeholder="Например: Anime"
                  style={{ width: '100%', padding: '9px 12px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box', marginBottom: '10px' }} />
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button className="btn-primary" style={{ flex: 1 }} onClick={() => { if(newSec.name){setSectionsCloud(prev=>[...prev,{id:Date.now(),name:newSec.name,emoji:''}]);setNewSec({name:'',emoji:''});setAddSec(false)} }}>Добавить</button>
                  <button className="btn-secondary" style={{ flex: 1 }} onClick={() => setAddSec(false)}>Отмена</button>
                </div>
              </div>
            )}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '7px' }}>
              {sections.map((s, idx) => {
                const isEditing = editingSecId === s.id
                return (
                <div key={s.id}
                  draggable={!isEditing}
                  onDragStart={() => { secDragIdx.current = idx }}
                  onDragOver={e => { e.preventDefault(); setSecDragOverIdx(idx) }}
                  onDrop={e => {
                    e.preventDefault()
                    const from = secDragIdx.current
                    if (from == null || from === idx) { setSecDragOverIdx(null); return }
                    setSectionsCloud(prev => {
                      const arr = [...prev]
                      const [moved] = arr.splice(from, 1)
                      arr.splice(idx, 0, moved)
                      return arr
                    })
                    secDragIdx.current = null; setSecDragOverIdx(null)
                  }}
                  onDragEnd={() => { secDragIdx.current = null; setSecDragOverIdx(null) }}
                  className="glass-card"
                  style={{ padding: '12px', display: 'flex', alignItems: 'center', gap: '10px', transition: 'opacity 0.15s, transform 0.15s', opacity: secDragOverIdx === idx ? 0.5 : 1, transform: secDragOverIdx === idx ? 'scale(0.98)' : 'scale(1)', cursor: isEditing ? 'default' : 'grab' }}>
                  {!isEditing && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '3px', flexShrink: 0, opacity: 0.4, paddingLeft: '1px' }}>
                      {[0,1,2].map(i => <div key={i} style={{ width: '14px', height: '2px', background: 'var(--text-secondary)', borderRadius: '2px' }} />)}
                    </div>
                  )}
                  {editingSecId === s.id ? (
                    <>
                      <input value={editingSecName} onChange={e => setEditingSecName(e.target.value)}
                        style={{ flex: 1, background: 'var(--bg-input)', border: '1px solid var(--accent-2)', borderRadius: '8px', padding: '6px 10px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none' }} />
                      <button onClick={() => { setSectionsCloud(prev => prev.map(x => x.id === s.id ? { ...x, name: editingSecName } : x)); setEditingSecId(null) }}
                        style={{ padding: '5px 10px', borderRadius: '8px', background: 'rgba(52,201,125,0.1)', border: '1px solid var(--status-ready-color)', color: 'var(--status-ready-color)', fontSize: '10px', fontWeight: 600, cursor: 'pointer' }}>Сохранить</button>
                      <button onClick={() => setEditingSecId(null)}
                        style={{ padding: '5px 10px', borderRadius: '8px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, cursor: 'pointer' }}>Отмена</button>
                    </>
                  ) : (
                    <>
                      <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: 0, flex: 1 }}>{s.name}</p>
                      <span style={{ color: 'var(--text-muted)', fontSize: '10px', marginRight: '6px' }}>{products.filter(p=>p.series===s.name).length} товаров</span>
                      <button onClick={() => { setEditingSecId(s.id); setEditingSecName(s.name) }} style={{ display: 'flex', alignItems: 'center', padding: '5px', borderRadius: '8px', background: 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', cursor: 'pointer', marginRight: '2px' }}><Icon name="pencil" size={13} color="var(--accent-2-hi)" /></button>
                      <button onClick={() => setSectionsCloud(prev=>prev.filter(x=>x.id!==s.id))} style={{ display: 'flex', alignItems: 'center', padding: '5px', borderRadius: '8px', background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.18)', cursor: 'pointer' }}><Icon name="trash" size={13} color="var(--danger)" /></button>
                    </>
                  )}
                </div>
                )
              })}
            </div>
          </div>
        )
      }

      {/* ─── Кнопки-фильтры каталога ─── */}
      <div style={{ marginTop: '22px' }}>
        <div style={{ marginBottom: '10px' }}>
          <h3 style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: '0 0 3px' }}>Фильтры каталога</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0, lineHeight: 1.45 }}>Кнопки в шторке фильтров. Можно добавлять, редактировать, включать и менять порядок. Максимум цены в фильтре всегда равен цене самого дорогого товара.</p>
        </div>
        <button className="btn-primary" style={{ marginBottom: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }} onClick={addFilter}>
          <Icon name="plus" size={14} color="#fff" /> Добавить фильтр
        </button>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {catalogFilters.map((f, idx) => (
            <div key={f.id} className="glass-card" style={{ padding: '12px', opacity: f.enabled ? 1 : 0.55 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '9px' }}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', flexShrink: 0 }}>
                  <button onClick={() => moveFilter(idx, -1)} disabled={idx === 0} style={{ display: 'grid', placeItems: 'center', width: '22px', height: '18px', borderRadius: '6px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', cursor: idx === 0 ? 'default' : 'pointer', opacity: idx === 0 ? 0.35 : 1 }}><Icon name="chevron-up" size={12} color="var(--text-secondary)" /></button>
                  <button onClick={() => moveFilter(idx, 1)} disabled={idx === catalogFilters.length - 1} style={{ display: 'grid', placeItems: 'center', width: '22px', height: '18px', borderRadius: '6px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', cursor: idx === catalogFilters.length - 1 ? 'default' : 'pointer', opacity: idx === catalogFilters.length - 1 ? 0.35 : 1 }}><Icon name="chevron-down" size={12} color="var(--text-secondary)" /></button>
                </div>
                <input value={f.label} onChange={e => patchFilter(f.id, { label: e.target.value })} placeholder="Название кнопки"
                  style={{ flex: 1, background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '8px', padding: '7px 10px', color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, outline: 'none', boxSizing: 'border-box' }} />
                <button onClick={() => patchFilter(f.id, { enabled: !f.enabled })}
                  style={{ flexShrink: 0, width: '42px', height: '25px', borderRadius: '999px', padding: '2px', border: 'none', cursor: 'pointer', background: f.enabled ? 'var(--status-ready-color)' : 'var(--border)', display: 'flex', justifyContent: f.enabled ? 'flex-end' : 'flex-start' }}>
                  <span style={{ width: '21px', height: '21px', borderRadius: '50%', background: '#fff', display: 'block' }} />
                </button>
                <button onClick={() => removeFilter(f.id)} style={{ flexShrink: 0, display: 'flex', alignItems: 'center', padding: '6px', borderRadius: '8px', background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.18)', cursor: 'pointer' }}><Icon name="trash" size={13} color="var(--danger)" /></button>
              </div>
              <input value={f.hint} onChange={e => patchFilter(f.id, { hint: e.target.value })} placeholder="Пояснение под названием"
                style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '8px', padding: '7px 10px', color: 'var(--text-secondary)', fontSize: '12px', outline: 'none', boxSizing: 'border-box', marginBottom: '8px' }} />
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ color: 'var(--text-muted)', fontSize: '11px', flexShrink: 0 }}>Условие</span>
                <select value={f.kind} onChange={e => patchFilter(f.id, { kind: e.target.value as CatalogFilterKind })}
                  style={{ flex: 1, background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '8px', padding: '7px 10px', color: 'var(--text-primary)', fontSize: '12px', outline: 'none' }}>
                  {CATALOG_FILTER_KINDS.map(k => <option key={k.kind} value={k.kind}>{k.label}</option>)}
                </select>
              </div>
            </div>
          ))}
          {catalogFilters.length === 0 && (
            <p style={{ color: 'var(--text-muted)', fontSize: '12px', textAlign: 'center', padding: '14px 0', margin: 0 }}>Фильтров пока нет. Добавьте первый.</p>
          )}
        </div>
      </div>
  </>)
}
