import { COVER_MODE_OPTIONS, Icon, OWNER_TG, ROLE_LABELS, Role } from '../../shared'
import type { CrmCtx } from '../state'

export default function RolesSection(ctx: CrmCtx) {
  const { coverMode, roleForm, roleMsg, roles, setCoverMode, setRoleForm, setRoleMsg, setRoles, tabAllowed } = ctx
  return (<>
      {tabAllowed('roles') && (
          <div>
            <div className="glass-card" style={{ padding: '12px', marginBottom: '10px' }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, margin: '0 0 4px' }}>Роли сотрудников</p>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', lineHeight: 1.5, margin: '0 0 10px' }}>
                Владелец <b style={{ color: 'var(--accent)' }}>{OWNER_TG}</b> — высший ранг, доступ ко всему, снять нельзя.<br />
                <b style={{ color: 'var(--text-secondary)' }}>Администратор</b> — полный доступ к CRM.<br />
                <b style={{ color: 'var(--text-secondary)' }}>Модератор</b> — заказы, оплаты, клиенты, отзывы.<br />
                <b style={{ color: 'var(--text-secondary)' }}>Редактор</b> — товары, разделы, FAQ, баннер, контент.
              </p>
              <div style={{ marginBottom: '10px' }}>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 4px', fontWeight: 500 }}>Telegram ID сотрудника</p>
                <div style={{ position: 'relative' }}>
                  <span style={{ position: 'absolute', left: '11px', top: '50%', transform: 'translateY(-50%)', color: 'var(--accent-2-hi)', fontSize: '14px', pointerEvents: 'none' }}>@</span>
                  <input value={roleForm.login} onChange={e => { setRoleForm(f => ({ ...f, login: e.target.value.replace(/^@/, '') })); setRoleMsg('') }} placeholder="username"
                    style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '9px 12px 9px 26px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
                </div>
              </div>
              <div style={{ display: 'flex', gap: '6px', marginBottom: '10px' }}>
                {(['admin', 'moderator', 'editor'] as Role[]).map(r => (
                  <button key={r} onClick={() => setRoleForm(f => ({ ...f, role: r }))}
                    style={{ flex: 1, padding: '8px 4px', borderRadius: '10px', background: roleForm.role === r ? 'var(--accent-2-wash)' : 'var(--bg-elevated)', border: `1px solid ${roleForm.role === r ? 'var(--accent-2)' : 'var(--border)'}`, color: roleForm.role === r ? 'var(--accent-2-hi)' : 'var(--text-secondary)', fontSize: '11px', fontWeight: 600, cursor: 'pointer' }}>
                    {ROLE_LABELS[r]}
                  </button>
                ))}
              </div>
              {roleMsg && <p style={{ color: roleMsg.startsWith('Роль') ? 'var(--accent-2-hi)' : 'var(--danger)', fontSize: '11.5px', fontWeight: 600, margin: '0 0 8px' }}>{roleMsg}</p>}
              <button className="btn-primary" onClick={() => {
                const l = '@' + roleForm.login.trim().replace(/^@/, '').toLowerCase()
                if (l.length < 2) { setRoleMsg('Укажите Telegram ID'); return }
                if (l === OWNER_TG.toLowerCase()) { setRoleMsg('Это владелец — роль изменить нельзя'); return }
                setRoles(prev => ({ ...prev, [l]: roleForm.role }))
                setRoleForm({ login: '', role: 'moderator' })
                setRoleMsg(`Роль назначена: ${l}`)
              }}>Назначить роль</button>
            </div>

            {/* Обложка профиля: либо общая от владельца, либо своя у каждого. */}
            <div className="glass-card" style={{ padding: '12px', marginBottom: '10px' }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, margin: '0 0 4px' }}>Обложка профиля</p>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', lineHeight: 1.5, margin: '0 0 10px' }}>
                Выберите, кто ставит обложку за аватаркой.
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                {COVER_MODE_OPTIONS.map(({ key, label, sub, icon }) => {
                  const on = coverMode === key
                  return (
                    <button key={key} onClick={() => setCoverMode(key)} className="ss-press"
                      style={{ display: 'flex', alignItems: 'center', gap: '10px', width: '100%', padding: '10px', borderRadius: '10px', textAlign: 'left', cursor: 'pointer', fontFamily: 'inherit', background: on ? 'var(--accent-2-wash)' : 'var(--bg-elevated)', border: `1px solid ${on ? 'var(--accent-2)' : 'var(--border)'}` }}>
                      <span style={{ width: '20px', height: '20px', borderRadius: '6px', display: 'grid', placeItems: 'center', flexShrink: 0, background: on ? 'var(--accent-2)' : 'transparent', border: `1px solid ${on ? 'var(--accent-2)' : 'var(--border)'}` }}>
                        {on && <Icon name="check" size={12} color="#fff" />}
                      </span>
                      <Icon name={icon} size={14} color={on ? 'var(--accent-2-hi)' : 'var(--text-muted)'} />
                      <span style={{ flex: 1, minWidth: 0 }}>
                        <span style={{ display: 'block', color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 600 }}>{label}</span>
                        <span style={{ display: 'block', color: 'var(--text-muted)', fontSize: '10.5px' }}>{sub}</span>
                      </span>
                    </button>
                  )
                })}
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '7px' }}>
              <div className="glass-card" style={{ padding: '11px 12px', display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{ width: '30px', height: '30px', borderRadius: '9px', background: 'linear-gradient(135deg,#f59e0b,#b45309)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Icon name="star-fill" size={14} color="#fff" />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, margin: 0 }}>{OWNER_TG}</p>
                  <p style={{ color: '#f59e0b', fontSize: '10.5px', fontWeight: 600, margin: 0 }}>Владелец · высший доступ</p>
                </div>
              </div>
              {Object.entries(roles).map(([login, r]) => (
                <div key={login} className="glass-card" style={{ padding: '11px 12px', display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <div style={{ width: '30px', height: '30px', borderRadius: '9px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Icon name={r === 'admin' ? 'gear' : r === 'moderator' ? 'users' : 'pencil'} size={14} color="var(--accent-2-hi)" />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: 0, overflow: 'hidden', textOverflow: 'ellipsis' }}>{login}</p>
                    <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', margin: 0 }}>{ROLE_LABELS[r]}</p>
                  </div>
                  <button onClick={() => setRoles(prev => { const n = { ...prev }; delete n[login]; return n })} title="Снять роль"
                    style={{ width: '28px', height: '28px', borderRadius: '8px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Icon name="trash" size={12} color="var(--danger)" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )
      }
  </>)
}
