import { FormField, Icon, OWNER_TG } from '../../shared'
import type { CrmCtx } from '../state'

export default function PayVerifySection(ctx: CrmCtx) {
  const { onPayVerify, orders, paySearch, sbpInfo, setPaySearch, setSbpInfo, tabAllowed } = ctx
  return (<>
      {tabAllowed('payverify') && (() => {
          const awaiting = orders.filter(o => o.payStatus === 'awaiting')
          const q = paySearch.trim().toLowerCase().replace(/^[@#]/, '')
          const found = q
            ? awaiting.filter(o => o.userId.toLowerCase().replace(/^@/, '').includes(q) || o.id.toLowerCase().replace(/^#/, '').includes(q))
            : awaiting
          return (
          <div>
            <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, margin: '0 0 8px' }}>Ожидают подтверждения</p>
            <div className="search-glow" style={{ position: 'relative', marginBottom: '10px', borderRadius: '12px' }}>
              <span style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', zIndex: 4 }}><Icon name="search" size={15} color="var(--text-muted)" /></span>
              <input value={paySearch} onChange={e => setPaySearch(e.target.value)} placeholder="ID клиента или номер заказа"
                style={{ width: '100%', padding: '10px 34px 10px 36px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '12px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
              {paySearch && (
                <button onClick={() => setPaySearch('')} style={{ position: 'absolute', right: '9px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', padding: '4px', display: 'flex', zIndex: 4 }}>
                  <Icon name="close" size={14} color="var(--text-muted)" />
                </button>
              )}
            </div>
            {awaiting.length === 0 && (
              <div className="glass-card" style={{ padding: '20px', textAlign: 'center' }}>
                <Icon name="check" size={22} color="var(--text-muted)" />
                <p style={{ color: 'var(--text-muted)', fontSize: '12px', margin: '8px 0 0' }}>Нет заказов, ожидающих проверки перевода</p>
              </div>
            )}
            {awaiting.length > 0 && found.length === 0 && (
              <div className="glass-card" style={{ padding: '20px', textAlign: 'center' }}>
                <Icon name="search" size={22} color="var(--text-muted)" />
                <p style={{ color: 'var(--text-muted)', fontSize: '12px', margin: '8px 0 0' }}>Ничего не найдено по «{paySearch}»</p>
              </div>
            )}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {found.map(o => (
                <div key={o.id} className="glass-card" style={{ padding: '12px' }}>
                  <div style={{ display: 'flex', gap: '10px', marginBottom: '10px' }}>
                    <img src={o.thumb} alt="" style={{ width: '48px', height: '48px', borderRadius: '10px', objectFit: 'cover', flexShrink: 0 }} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, margin: '0 0 2px' }}>{o.name}</p>
                      <p style={{ color: 'var(--accent-2-hi)', fontSize: '12px', fontWeight: 700, margin: '0 0 2px' }}>{o.userId}</p>
                      <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', margin: 0 }}>{o.id} · {o.date} · {o.variantName ?? ''}</p>
                    </div>
                    <div style={{ textAlign: 'right', flexShrink: 0 }}>
                      <p style={{ color: 'var(--text-primary)', fontSize: '16px', fontWeight: 800, margin: 0 }}>{(o.painted ? o.price : o.priceUnpainted).toLocaleString()} ₽</p>
                      <p style={{ color: 'var(--text-muted)', fontSize: '9.5px', margin: 0 }}>СБП</p>
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '8px' }}>
                    <button onClick={() => onPayVerify(o.id, true)} style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '10px', borderRadius: '11px', background: 'rgba(52,201,125,0.14)', border: '1px solid var(--success)', color: 'var(--success)', fontSize: '12.5px', fontWeight: 700, cursor: 'pointer' }}>
                      <Icon name="check" size={14} color="var(--success)" strokeWidth={2.4} /> Оплатил
                    </button>
                    <button onClick={() => onPayVerify(o.id, false)} style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '10px', borderRadius: '11px', background: 'rgba(239,68,68,0.12)', border: '1px solid var(--danger)', color: 'var(--danger)', fontSize: '12.5px', fontWeight: 700, cursor: 'pointer' }}>
                      <Icon name="close" size={14} color="var(--danger)" strokeWidth={2.4} /> Не оплатил
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <div className="glass-card" style={{ padding: '12px', margin: '14px 0 10px' }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, margin: '0 0 8px' }}>Реквизиты для СБП</p>
              <FormField label="Мой Telegram для связи с клиентами" value={sbpInfo.contact ?? OWNER_TG} onChange={v => setSbpInfo(i => ({ ...i, contact: v }))} />
              <FormField label="ФИО получателя" value={sbpInfo.fio} onChange={v => setSbpInfo(i => ({ ...i, fio: v }))} />
              <FormField label="Банк" value={sbpInfo.bank} onChange={v => setSbpInfo(i => ({ ...i, bank: v }))} />
              <FormField label="Номер карты" value={sbpInfo.card} onChange={v => setSbpInfo(i => ({ ...i, card: v }))} />
              <FormField label="Телефон для СБП (необязательно)" value={sbpInfo.phone} onChange={v => setSbpInfo(i => ({ ...i, phone: v }))} />
              <div>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 4px', fontWeight: 500 }}>Примечание клиенту</p>
                <textarea value={sbpInfo.note} onChange={e => setSbpInfo(i => ({ ...i, note: e.target.value }))} rows={2}
                  style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '9px 12px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box', resize: 'vertical', fontFamily: 'inherit' }} />
              </div>
            </div>

          </div>
          )
        })()
      }
  </>)
}
