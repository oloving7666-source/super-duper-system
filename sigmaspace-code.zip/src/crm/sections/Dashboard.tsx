import { Icon, STATUS_META, type IconName, type OrderStatus, type Order } from '../../shared'
import type { CrmCtx } from '../state'

const rub = (n: number) => n.toLocaleString('ru') + ' ₽'
const orderSum = (o: Order) => (o.painted ? o.price : o.priceUnpainted) || 0
const DAY = 86400000

export default function DashboardSection(ctx: CrmCtx) {
  const { orders, products, registeredUsers, reviews, promocodes } = ctx
  const now = Date.now()

  // Дата заказа: берём createdAt, иначе пытаемся разобрать поле date (запасной вариант).
  const orderTime = (o: Order) => o.createdAt ?? 0

  const revenue = orders.reduce((s, o) => s + orderSum(o), 0)
  const paidRevenue = orders.filter(o => o.paid).reduce((s, o) => s + orderSum(o), 0)
  const avgCheck = orders.length ? Math.round(revenue / orders.length) : 0

  const monthAgo = now - 30 * DAY
  const monthOrders = orders.filter(o => orderTime(o) >= monthAgo)
  const monthRevenue = monthOrders.reduce((s, o) => s + orderSum(o), 0)

  const awaiting = orders.filter(o => o.payStatus === 'awaiting').length
  const activeOrders = orders.filter(o => o.status !== 'delivered').length

  // Выручка по дням за 14 дней — компактный столбчатый график.
  const days = 14
  const buckets = Array.from({ length: days }, (_, i) => {
    const start = now - (days - 1 - i) * DAY
    const d0 = new Date(start); d0.setHours(0, 0, 0, 0)
    const from = d0.getTime(); const to = from + DAY
    const sum = orders.filter(o => { const t = orderTime(o); return t >= from && t < to }).reduce((s, o) => s + orderSum(o), 0)
    return { label: d0.toLocaleDateString('ru', { day: 'numeric' }), sum }
  })
  const maxBucket = Math.max(1, ...buckets.map(b => b.sum))

  // Разбивка по статусам заказов.
  const statusOrder: OrderStatus[] = ['new', 'printing', 'painting', 'ready', 'delivered']
  const byStatus = statusOrder.map(st => ({ st, count: orders.filter(o => o.status === st).length, meta: STATUS_META[st] }))
  const maxStatus = Math.max(1, ...byStatus.map(s => s.count))

  // Топ товаров по продажам.
  const topProducts = [...products].filter(p => (p.sold ?? 0) > 0).sort((a, b) => (b.sold ?? 0) - (a.sold ?? 0)).slice(0, 5)
  const maxSold = Math.max(1, ...topProducts.map(p => p.sold ?? 0))

  // Отзывы.
  const avgRating = reviews.length ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length) : 0
  const activePromos = promocodes.filter(p => !p.deleted && (!p.expiresAt || p.expiresAt > now) && p.uses < p.maxUses).length

  const kpis: Array<{ label: string; value: string; sub?: string; icon: IconName; color: string }> = [
    { label: 'Выручка всего', value: rub(revenue), sub: `оплачено ${rub(paidRevenue)}`, icon: 'card', color: '#5ba172' },
    { label: 'За 30 дней', value: rub(monthRevenue), sub: `${monthOrders.length} заказов`, icon: 'document', color: '#4d9bff' },
    { label: 'Средний чек', value: rub(avgCheck), sub: `${orders.length} заказов всего`, icon: 'calculator', color: '#a78bfa' },
    { label: 'Клиентов', value: String(registeredUsers.length), sub: `${activeOrders} активных заказов`, icon: 'users', color: '#cbb149' },
  ]

  const card: React.CSSProperties = { padding: '13px 14px', display: 'flex', flexDirection: 'column', gap: '10px' }
  const title = (t: string) => <p style={{ color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 700, margin: 0 }}>{t}</p>

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      <div>
        <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: '0 0 4px' }}>Аналитика магазина</p>
        <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Живая сводка по заказам, выручке и товарам.</p>
      </div>

      {/* KPI-плитки */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
        {kpis.map(k => (
          <div key={k.label} className="glass-card" style={{ padding: '12px', display: 'flex', flexDirection: 'column', gap: '7px' }}>
            <span style={{ width: '30px', height: '30px', borderRadius: '9px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: `${k.color}1f`, border: `1px solid ${k.color}44` }}>
              <Icon name={k.icon} size={15} color={k.color} />
            </span>
            <div>
              <p style={{ color: 'var(--text-primary)', fontSize: '17px', fontWeight: 800, margin: 0, lineHeight: 1.1, letterSpacing: '-0.01em' }}>{k.value}</p>
              <p style={{ color: 'var(--text-muted)', fontSize: '9.5px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', margin: '3px 0 0' }}>{k.label}</p>
              {k.sub && <p style={{ color: 'var(--text-secondary)', fontSize: '10px', margin: '2px 0 0' }}>{k.sub}</p>}
            </div>
          </div>
        ))}
      </div>

      {/* График выручки по дням */}
      <div className="glass-card" style={card}>
        {title('Выручка за 14 дней')}
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: '4px', height: '92px' }}>
          {buckets.map((b, i) => (
            <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px', height: '100%', justifyContent: 'flex-end' }} title={`${b.label}: ${rub(b.sum)}`}>
              <div style={{ width: '100%', height: `${Math.max(3, (b.sum / maxBucket) * 100)}%`, borderRadius: '4px 4px 2px 2px', background: b.sum ? 'linear-gradient(180deg, var(--accent-2-hi), var(--accent-2))' : 'var(--bg-elevated)', transition: 'height 0.3s' }} />
              <span style={{ color: 'var(--text-muted)', fontSize: '8px' }}>{b.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Статусы заказов */}
      <div className="glass-card" style={card}>
        {title('Заказы по стадиям')}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '7px' }}>
          {byStatus.map(s => (
            <div key={s.st} style={{ display: 'flex', alignItems: 'center', gap: '9px' }}>
              <span style={{ width: '76px', flexShrink: 0, color: 'var(--text-secondary)', fontSize: '11px' }}>{s.meta.label}</span>
              <div style={{ flex: 1, height: '8px', borderRadius: '4px', background: 'var(--bg-elevated)', overflow: 'hidden' }}>
                <div style={{ width: `${(s.count / maxStatus) * 100}%`, height: '100%', background: s.meta.dot, borderRadius: '4px', transition: 'width 0.3s' }} />
              </div>
              <span style={{ width: '24px', textAlign: 'right', flexShrink: 0, color: 'var(--text-primary)', fontSize: '12px', fontWeight: 700 }}>{s.count}</span>
            </div>
          ))}
        </div>
        {awaiting > 0 && (
          <p style={{ color: 'var(--danger)', fontSize: '11px', margin: 0, fontWeight: 600 }}>⏳ Ждут подтверждения оплаты: {awaiting}</p>
        )}
      </div>

      {/* Топ товаров */}
      <div className="glass-card" style={card}>
        {title('Топ товаров по продажам')}
        {topProducts.length === 0 ? (
          <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0, fontStyle: 'italic' }}>Пока нет продаж</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {topProducts.map((p, i) => (
              <div key={p.id} style={{ display: 'flex', alignItems: 'center', gap: '9px' }}>
                <span style={{ flexShrink: 0, width: '20px', height: '20px', borderRadius: '6px', background: 'var(--accent-glow)', color: 'var(--accent)', fontSize: '10px', fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{i + 1}</span>
                <img src={p.img} alt="" style={{ width: '30px', height: '30px', borderRadius: '7px', objectFit: 'cover', flexShrink: 0 }} onError={e => (e.currentTarget.style.visibility = 'hidden')} />
                <div style={{ minWidth: 0, flex: 1 }}>
                  <p style={{ color: 'var(--text-primary)', fontSize: '11.5px', fontWeight: 600, margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</p>
                  <div style={{ height: '5px', borderRadius: '3px', background: 'var(--bg-elevated)', overflow: 'hidden', marginTop: '3px' }}>
                    <div style={{ width: `${((p.sold ?? 0) / maxSold) * 100}%`, height: '100%', background: 'var(--accent)', borderRadius: '3px' }} />
                  </div>
                </div>
                <span style={{ flexShrink: 0, color: 'var(--accent-2-hi)', fontSize: '12px', fontWeight: 700 }}>{p.sold}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Мелкие метрики */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
        <div className="glass-card" style={{ padding: '12px', display: 'flex', alignItems: 'center', gap: '9px' }}>
          <Icon name="star-fill" size={17} color="#f0a742" />
          <div>
            <p style={{ color: 'var(--text-primary)', fontSize: '15px', fontWeight: 800, margin: 0, lineHeight: 1 }}>{avgRating ? avgRating.toFixed(1) : '—'}</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '2px 0 0' }}>{reviews.length} отзывов</p>
          </div>
        </div>
        <div className="glass-card" style={{ padding: '12px', display: 'flex', alignItems: 'center', gap: '9px' }}>
          <Icon name="gift" size={17} color="#cbb149" />
          <div>
            <p style={{ color: 'var(--text-primary)', fontSize: '15px', fontWeight: 800, margin: 0, lineHeight: 1 }}>{activePromos}</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '2px 0 0' }}>активных промокодов</p>
          </div>
        </div>
      </div>
    </div>
  )
}
