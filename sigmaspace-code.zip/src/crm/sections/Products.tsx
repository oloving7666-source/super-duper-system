import { Fragment, useRef, useState } from 'react'
import { Icon, getVariants, priceRange, genVariantId, type Product } from '../../shared'
import type { CrmCtx } from '../state'

export default function ProductsSection(ctx: CrmCtx) {
  const { EMPTY_PROD, addProd, dragIdx, dragOverIdx, editProd, importMsg, isOwner, photoImportRef, photoImporting, photoImportProgress, photoImportSection, setPhotoImportSection, prodForm, prodFilter, prodSort, products, sections, setAddProd, setDragOverIdx, setEditProd, setNewProd, setProdFilter, setProdSort, setProductsCloud, runPhotoImport, unhideAll } = ctx

  // Резервная копия каталога: выгрузка/загрузка всех товаров в JSON. Работает
  // полностью локально (без обращения к серверу), поэтому доступна даже когда
  // облако на паузе из-за квоты — можно сохранить каталог себе на устройство.
  const backupRef = useRef<HTMLInputElement>(null)
  const exportProducts = () => {
    try {
      const json = JSON.stringify(products, null, 2)
      const blob = new Blob([json], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')
      a.href = url
      a.download = `sigmaspace-products-${products.length}-${stamp}.json`
      document.body.appendChild(a)
      a.click()
      a.remove()
      setTimeout(() => URL.revokeObjectURL(url), 2000)
    } catch (e) {
      alert('Не удалось сохранить файл: ' + (e instanceof Error ? e.message : String(e)))
    }
  }
  const importProducts = async (files: FileList | null) => {
    const file = files?.[0]
    if (!file) return
    try {
      const text = await file.text()
      const data = JSON.parse(text)
      if (!Array.isArray(data)) throw new Error('Файл не содержит список товаров')
      const valid = data.filter((p: any) => p && typeof p === 'object' && 'id' in p)
      if (valid.length === 0) throw new Error('В файле не найдено ни одного товара')
      const mode = window.confirm(
        `В файле ${valid.length} товаров.\n\n` +
        `ОК — объединить с текущими (${products.length}): новые добавятся, совпадающие по ID обновятся.\n` +
        `Отмена — заменить весь каталог на товары из файла.`
      )
      if (mode) {
        // Объединение по id: товары из файла перезаписывают одноимённые, остальные сохраняются
        const byId = new Map<number, any>()
        for (const p of products) byId.set(p.id, p)
        for (const p of valid) byId.set(p.id, p)
        setProductsCloud(Array.from(byId.values()))
        alert(`Готово. В каталоге ${byId.size} товаров.`)
      } else {
        if (!window.confirm(`Заменить весь каталог на ${valid.length} товаров из файла? Текущие ${products.length} будут удалены.`)) return
        setProductsCloud(valid)
        alert(`Готово. Каталог заменён: ${valid.length} товаров.`)
      }
    } catch (e) {
      alert('Не удалось прочитать файл: ' + (e instanceof Error ? e.message : String(e)))
    }
  }

  // Скачать все фото товаров одним архивом. Настоящий бэкап картинок (в отличие от
  // JSON, где лежат только ссылки). Складываем ссылки в текстовый список, если zip
  // недоступен, но по возможности тянем сами файлы. Работает, только когда облако
  // отдаёт файлы (не под блокировкой квоты).
  const [photoDownloading, setPhotoDownloading] = useState<{ done: number; total: number } | null>(null)
  const downloadAllPhotos = async () => {
    const urls = Array.from(new Set(products.flatMap(p => p.images?.length ? p.images : [p.img]).filter(Boolean)))
    if (!urls.length) { alert('Нет фото для скачивания'); return }
    // Пробуем собрать zip через динамически подгружаемый JSZip; если библиотеки нет —
    // выгружаем список ссылок текстовым файлом, чтобы бэкап всё равно был.
    let JSZip: any = null
    try { JSZip = (await import('jszip')).default } catch { /* нет библиотеки */ }
    if (!JSZip) {
      const blob = new Blob([urls.join('\n')], { type: 'text/plain' })
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob)
      a.download = `sigmaspace-photo-links-${urls.length}.txt`; a.click()
      setTimeout(() => URL.revokeObjectURL(a.href), 2000)
      alert('Библиотека архивации недоступна — сохранил список ссылок на фото.')
      return
    }
    setPhotoDownloading({ done: 0, total: urls.length })
    const zip = new JSZip()
    let ok = 0
    for (let i = 0; i < urls.length; i++) {
      try {
        const res = await fetch(urls[i])
        if (res.ok) {
          const buf = await res.arrayBuffer()
          const ext = (urls[i].split('.').pop() || 'jpg').split('?')[0].slice(0, 5)
          zip.file(`${String(i + 1).padStart(4, '0')}.${ext}`, buf)
          ok++
        }
      } catch { /* пропускаем недоступное фото */ }
      setPhotoDownloading({ done: i + 1, total: urls.length })
    }
    if (ok === 0) { setPhotoDownloading(null); alert('Не удалось скачать ни одного фото (возможно, облако на паузе по квоте).'); return }
    const out = await zip.generateAsync({ type: 'blob' })
    const a = document.createElement('a'); a.href = URL.createObjectURL(out)
    a.download = `sigmaspace-photos-${ok}.zip`; a.click()
    setTimeout(() => URL.revokeObjectURL(a.href), 2000)
    setPhotoDownloading(null)
    alert(`Готово. В архиве ${ok} из ${urls.length} фото.`)
  }

  // Управление видимостью по разделу: выбираешь раздел и скрываешь/показываешь
  // все его товары разом. Совпадение раздела — по полю series (как в витрине).
  const [bulkSection, setBulkSection] = useState('')
  const bulkMatch = (p: Product) => p.series.trim().toLowerCase() === bulkSection.trim().toLowerCase()
  const bulkTotal = bulkSection ? products.filter(bulkMatch).length : 0
  const bulkHidden = bulkSection ? products.filter(p => bulkMatch(p) && p.hidden).length : 0

  // Поиск и фильтр по разделу в списке.
  const [search, setSearch] = useState('')
  const [secFilter, setSecFilter] = useState('')

  // Массовое выделение и действия над выбранными товарами.
  const [selectMode, setSelectMode] = useState(false)
  const [selected, setSelected] = useState<Set<number>>(new Set())
  const [moveTo, setMoveTo] = useState('')
  const toggleSel = (id: number) => setSelected(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n })
  const clearSel = () => setSelected(new Set())

  // Пересчёт цен товара: применяет функцию к ценам вариантов (или к legacy-ценам,
  // если вариантов нет) и обновляет диапазон price/priceUnpainted.
  const bumpProduct = (p: Product, fn: (price: number) => number): Product => {
    const vs = getVariants(p)
    if (vs.length) {
      const variants = vs.map(v => ({ ...v, price: Math.max(0, Math.round(fn(v.price))) }))
      const prices = variants.map(v => v.price).filter(n => n > 0)
      return { ...p, variants, price: prices.length ? Math.max(...prices) : 0, priceUnpainted: prices.length ? Math.min(...prices) : 0 }
    }
    return { ...p, price: Math.max(0, Math.round(fn(p.price))), priceUnpainted: Math.max(0, Math.round(fn(p.priceUnpainted))) }
  }
  const priceChange = (ids: Set<number>) => {
    if (!ids.size) return
    const raw = window.prompt(
      `Изменить цену выбранных товаров (${ids.size}).\n\n` +
      `Примеры:\n  +10%  — поднять на 10%\n  -15%  — снизить на 15%\n  +500  — прибавить 500 ₽\n  -300  — вычесть 300 ₽\n  =2500 — задать ровно 2500 ₽`
    )
    if (!raw) return
    const m = raw.trim().replace(',', '.').match(/^([=+\-]?)(\d+(?:\.\d+)?)(%?)$/)
    if (!m) { alert('Не понял формат. Примеры: +10%  -15%  +500  =2500'); return }
    const [, sign, numStr, pct] = m
    const num = parseFloat(numStr)
    const fn = (price: number) => {
      if (sign === '=') return num
      if (pct) { const d = price * num / 100; return sign === '-' ? price - d : price + d }
      return sign === '-' ? price - num : price + num
    }
    setProductsCloud(prev => prev.map(x => ids.has(x.id) ? bumpProduct(x, fn) : x))
  }

  // Дубликат товара: копия сразу под оригиналом, скрыта, с новыми id вариантов.
  const duplicateProduct = (p: Product) => {
    const copy: Product = { ...p, id: Date.now() + Math.floor(Math.random() * 1000), name: `${p.name} (копия)`, hidden: true, variants: getVariants(p).map(v => ({ ...v, id: genVariantId() })) }
    setProductsCloud(prev => { const i = prev.findIndex(x => x.id === p.id); const next = [...prev]; next.splice(i < 0 ? next.length : i + 1, 0, copy); return next })
  }

  const hiddenCount = products.filter(p => p.hidden).length
  const activeCount = products.length - hiddenCount
  const q = search.trim().toLowerCase()
  const listFilterActive = !!q || !!secFilter
  const filtered = products.filter(p =>
    (prodFilter === 'all' ? true : prodFilter === 'hidden' ? p.hidden : !p.hidden) &&
    (secFilter ? p.series.trim().toLowerCase() === secFilter.trim().toLowerCase() : true) &&
    (q ? (p.name.toLowerCase().includes(q) || p.series.toLowerCase().includes(q)) : true)
  )
  const canDrag = prodFilter === 'all' && !listFilterActive
  const inputStyle = { padding: '7px 10px', borderRadius: '9px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', color: 'var(--text-primary)', fontSize: '12px', fontWeight: 500, outline: 'none', boxSizing: 'border-box' as const }
  return (<>
      {(
          <div>
            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '10px' }}>
              <button className="btn-primary" style={{ width: '80%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }} onClick={() => { setAddProd(true); setEditProd(null); setNewProd(EMPTY_PROD()) }}>
                <Icon name="plus" size={14} color="#fff" /> Добавить товар
              </button>
            </div>

            {/* Резервная копия каталога в файл — только для владельца. Экспорт/импорт
                работают локально, без сервера, поэтому доступны и при исчерпанной квоте. */}
            {isOwner && (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px', marginBottom: '12px' }}>
                <input ref={backupRef} type="file" accept="application/json,.json" style={{ display: 'none' }}
                  onChange={e => { importProducts(e.target.files); e.target.value = '' }} />
                <div style={{ display: 'flex', gap: '6px', width: '80%' }}>
                  <button onClick={exportProducts}
                    style={{ flex: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '7px 10px', borderRadius: '9px', background: 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', color: 'var(--accent-2-hi)', fontSize: '11px', fontWeight: 600, cursor: 'pointer' }}>
                    <Icon name="save" size={13} color="var(--accent-2-hi)" /> Экспорт в файл
                  </button>
                  <button onClick={() => backupRef.current?.click()}
                    style={{ flex: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '7px 10px', borderRadius: '9px', background: 'var(--accent-2-wash)', border: '1px dashed var(--accent-2)', color: 'var(--accent-2-hi)', fontSize: '11px', fontWeight: 600, cursor: 'pointer' }}>
                    <Icon name="package" size={13} color="var(--accent-2-hi)" /> Импорт из файла
                  </button>
                </div>
                <button onClick={downloadAllPhotos} disabled={!!photoDownloading}
                  style={{ width: '80%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '7px 10px', borderRadius: '9px', background: 'var(--accent-2-wash)', border: '1px dashed var(--accent-2)', color: 'var(--accent-2-hi)', fontSize: '11px', fontWeight: 600, cursor: photoDownloading ? 'default' : 'pointer', opacity: photoDownloading ? 0.6 : 1 }}>
                  <Icon name="image" size={13} color="var(--accent-2-hi)" />
                  {photoDownloading ? `Скачивание ${photoDownloading.done}/${photoDownloading.total}…` : 'Скачать все фото архивом'}
                </button>
                <p style={{ color: 'var(--text-muted)', fontSize: '9.5px', textAlign: 'center', margin: 0, maxWidth: '80%' }}>
                  JSON — резервная копия каталога (ссылки на фото). Архив — сами файлы фото. Оба работают локально; архив требует доступа к облаку.
                </p>
              </div>
            )}

            {/* Поиск + фильтр по разделу */}
            <div style={{ display: 'flex', gap: '6px', marginBottom: '10px' }}>
              <div style={{ position: 'relative', flex: 1 }}>
                <span style={{ position: 'absolute', left: '9px', top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }}><Icon name="search" size={13} color="var(--text-muted)" /></span>
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Поиск по названию или разделу"
                  style={{ ...inputStyle, width: '100%', paddingLeft: '28px' }} />
                {search && <button onClick={() => setSearch('')} style={{ position: 'absolute', right: '6px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', padding: '3px' }}><Icon name="close" size={12} color="var(--text-muted)" /></button>}
              </div>
              <select value={secFilter} onChange={e => setSecFilter(e.target.value)}
                style={{ ...inputStyle, maxWidth: '42%', cursor: 'pointer' }}>
                <option value="" style={{ background: 'var(--bg-elevated)', color: 'var(--text-primary)' }}>Все разделы</option>
                {sections.map(s => <option key={s.id} value={s.name} style={{ background: 'var(--bg-elevated)', color: 'var(--text-primary)' }}>{s.emoji ? `${s.emoji} ` : ''}{s.name}</option>)}
              </select>
            </div>

            {/* Фильтр по видимости: все / показанные клиентам / скрытые */}
            <div style={{ display: 'flex', gap: '6px', marginBottom: '10px' }}>
              {([
                { key: 'all' as const, label: `Все · ${products.length}` },
                { key: 'active' as const, label: `Активны · ${activeCount}` },
                { key: 'hidden' as const, label: `Скрыты · ${hiddenCount}` },
              ]).map(t => (
                <button key={t.key} onClick={() => setProdFilter(t.key)}
                  style={{ flex: 1, padding: '7px 6px', borderRadius: '9px', fontSize: '11px', fontWeight: 600, cursor: 'pointer', background: prodFilter === t.key ? 'var(--accent-2)' : 'var(--bg-elevated)', border: `1px solid ${prodFilter === t.key ? 'var(--accent-2)' : 'var(--border)'}`, color: prodFilter === t.key ? '#fff' : 'var(--text-secondary)' }}>
                  {t.label}
                </button>
              ))}
            </div>

            {/* Показать все скрытые разом — удобно после массового импорта */}
            {hiddenCount > 0 && (
              <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '8px' }}>
                <button onClick={unhideAll}
                  style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '7px 12px', borderRadius: '9px', background: 'rgba(52,201,125,0.1)', border: '1px solid var(--status-ready-color)', color: 'var(--status-ready-color)', fontSize: '11px', fontWeight: 600, cursor: 'pointer' }}>
                  <Icon name="eye" size={13} color="var(--status-ready-color)" /> Показать все скрытые ({hiddenCount})
                </button>
              </div>
            )}

            {/* Скрыть все показанные разом — обратная операция к «Показать все скрытые» */}
            {activeCount > 0 && (
              <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '12px' }}>
                <button onClick={() => {
                  if (!window.confirm(`Скрыть все активные товары (${activeCount}) от клиентов?`)) return
                  setProductsCloud(prev => prev.map(x => x.hidden ? x : { ...x, hidden: true }))
                }}
                  style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '7px 12px', borderRadius: '9px', background: 'rgba(239,68,68,0.07)', border: '1px solid var(--danger)', color: 'var(--danger)', fontSize: '11px', fontWeight: 600, cursor: 'pointer' }}>
                  <Icon name="close" size={13} color="var(--danger)" /> Скрыть все активные ({activeCount})
                </button>
              </div>
            )}

            {/* Управление видимостью по разделу */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px', marginBottom: '12px' }}>
              <select value={bulkSection} onChange={e => setBulkSection(e.target.value)}
                style={{ padding: '6px 10px', borderRadius: '9px', background: 'var(--bg-elevated)', border: '1px solid var(--accent-2)', color: 'var(--text-primary)', fontSize: '11px', fontWeight: 600, cursor: 'pointer', maxWidth: '80%' }}>
                <option value="" style={{ background: 'var(--bg-elevated)', color: 'var(--text-primary)' }}>Раздел для скрытия/показа…</option>
                {sections.map(s => <option key={s.id} value={s.name} style={{ background: 'var(--bg-elevated)', color: 'var(--text-primary)' }}>{s.emoji ? `${s.emoji} ` : ''}{s.name}</option>)}
              </select>
              {bulkSection && (
                <>
                  <div style={{ display: 'flex', gap: '6px', width: '80%' }}>
                    <button disabled={bulkHidden === 0} onClick={() => setProductsCloud(prev => prev.map(x => bulkMatch(x) && x.hidden ? { ...x, hidden: false } : x))}
                      style={{ flex: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '7px 10px', borderRadius: '9px', background: 'rgba(52,201,125,0.1)', border: '1px solid var(--status-ready-color)', color: 'var(--status-ready-color)', fontSize: '11px', fontWeight: 600, cursor: bulkHidden === 0 ? 'default' : 'pointer', opacity: bulkHidden === 0 ? 0.5 : 1 }}>
                      <Icon name="eye" size={13} color="var(--status-ready-color)" /> Показать всё ({bulkHidden})
                    </button>
                    <button disabled={bulkTotal - bulkHidden === 0} onClick={() => {
                      if (!window.confirm(`Скрыть все товары раздела «${bulkSection}» (${bulkTotal - bulkHidden}) от клиентов?`)) return
                      setProductsCloud(prev => prev.map(x => bulkMatch(x) && !x.hidden ? { ...x, hidden: true } : x))
                    }}
                      style={{ flex: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '7px 10px', borderRadius: '9px', background: 'rgba(239,68,68,0.07)', border: '1px solid var(--danger)', color: 'var(--danger)', fontSize: '11px', fontWeight: 600, cursor: bulkTotal - bulkHidden === 0 ? 'default' : 'pointer', opacity: bulkTotal - bulkHidden === 0 ? 0.5 : 1 }}>
                      <Icon name="close" size={13} color="var(--danger)" /> Скрыть всё ({bulkTotal - bulkHidden})
                    </button>
                  </div>
                  <div style={{ display: 'flex', gap: '6px', width: '80%' }}>
                    <button disabled={bulkTotal === 0} onClick={() => priceChange(new Set(products.filter(bulkMatch).map(p => p.id)))}
                      style={{ flex: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '7px 10px', borderRadius: '9px', background: 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', color: 'var(--accent-2-hi)', fontSize: '11px', fontWeight: 600, cursor: bulkTotal === 0 ? 'default' : 'pointer', opacity: bulkTotal === 0 ? 0.5 : 1 }}>
                      <Icon name="card" size={13} color="var(--accent-2-hi)" /> Изменить цену
                    </button>
                    <button disabled={bulkTotal === 0} onClick={() => {
                      if (!window.confirm(`Удалить ВСЕ товары раздела «${bulkSection}» (${bulkTotal})? Отменить нельзя.`)) return
                      if (!window.confirm(`Точно удалить ${bulkTotal} товаров? Это навсегда.`)) return
                      setProductsCloud(prev => prev.filter(x => !bulkMatch(x)))
                    }}
                      style={{ flex: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '7px 10px', borderRadius: '9px', background: 'rgba(239,68,68,0.07)', border: '1px solid var(--danger)', color: 'var(--danger)', fontSize: '11px', fontWeight: 600, cursor: bulkTotal === 0 ? 'default' : 'pointer', opacity: bulkTotal === 0 ? 0.5 : 1 }}>
                      <Icon name="trash" size={13} color="var(--danger)" /> Удалить всё
                    </button>
                  </div>
                  <p style={{ color: 'var(--text-muted)', fontSize: '9.5px', textAlign: 'center', margin: 0, maxWidth: '80%' }}>
                    В разделе «{bulkSection}»: {bulkTotal} товаров · {bulkTotal - bulkHidden} показано · {bulkHidden} скрыто.
                  </p>
                </>
              )}
            </div>

            {/* Массовый импорт обложек — только для владельца. Выбираешь сразу пачку
                фото, каждое становится отдельным (скрытым) товаром с номером-названием. */}
            {isOwner && (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px', marginBottom: '12px' }}>
                <input ref={photoImportRef} type="file" accept="image/*" multiple style={{ display: 'none' }}
                  onChange={e => { runPhotoImport(e.target.files); e.target.value = '' }} />
                <select value={photoImportSection} onChange={e => setPhotoImportSection(e.target.value)} disabled={photoImporting}
                  style={{ padding: '6px 10px', borderRadius: '9px', background: 'var(--bg-elevated)', border: '1px solid var(--accent-2)', color: 'var(--text-primary)', fontSize: '11px', fontWeight: 600, cursor: photoImporting ? 'default' : 'pointer', maxWidth: '80%' }}>
                  <option value="" style={{ background: 'var(--bg-elevated)', color: 'var(--text-primary)' }}>Без раздела</option>
                  {sections.map(s => <option key={s.id} value={s.name} style={{ background: 'var(--bg-elevated)', color: 'var(--text-primary)' }}>{s.emoji ? `${s.emoji} ` : ''}{s.name}</option>)}
                </select>
                <button onClick={() => photoImportRef.current?.click()} disabled={photoImporting}
                  style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '7px 12px', borderRadius: '9px', background: 'var(--accent-2-wash)', border: '1px dashed var(--accent-2)', color: 'var(--accent-2-hi)', fontSize: '11px', fontWeight: 600, cursor: photoImporting ? 'default' : 'pointer', opacity: photoImporting ? 0.6 : 1 }}>
                  <Icon name="image" size={13} color="var(--accent-2-hi)" />
                  {photoImporting && photoImportProgress
                    ? `Загрузка ${photoImportProgress.done}/${photoImportProgress.total}…`
                    : 'Массовый импорт обложек'}
                </button>
                <p style={{ color: 'var(--text-muted)', fontSize: '9.5px', textAlign: 'center', margin: 0, maxWidth: '80%' }}>
                  Каждое фото → отдельный товар с номером. Цена: 4000 (с покраской) / 1500 (без покраски). Товары создаются скрытыми — отредактируйте и включите показ.
                </p>
                {importMsg && <p style={{ color: 'var(--accent-2-hi)', fontSize: '10px', textAlign: 'center', margin: 0 }}>{importMsg}</p>}
              </div>
            )}

            {/* Строка: счётчик + переключатель массового выделения */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
              <span style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 600 }}>
                Показано {filtered.length} из {products.length}
              </span>
              <button onClick={() => { setSelectMode(m => !m); clearSel() }}
                style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', padding: '5px 10px', borderRadius: '8px', background: selectMode ? 'var(--accent-2)' : 'var(--bg-elevated)', border: `1px solid ${selectMode ? 'var(--accent-2)' : 'var(--border)'}`, color: selectMode ? '#fff' : 'var(--text-secondary)', fontSize: '11px', fontWeight: 600, cursor: 'pointer' }}>
                <Icon name="check" size={12} color={selectMode ? '#fff' : 'var(--text-secondary)'} /> {selectMode ? 'Готово' : 'Выделить'}
              </button>
            </div>

            {/* Панель действий над выделенными */}
            {selectMode && (
              <div style={{ background: 'var(--bg-elevated)', border: '1px solid var(--accent-2)', borderRadius: '12px', padding: '10px', marginBottom: '10px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-primary)', fontSize: '12px', fontWeight: 700 }}>Выбрано: {selected.size}</span>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <button onClick={() => setSelected(new Set(filtered.map(p => p.id)))} style={{ padding: '4px 8px', borderRadius: '7px', background: 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', color: 'var(--accent-2-hi)', fontSize: '10px', fontWeight: 600, cursor: 'pointer' }}>Выбрать показанные</button>
                    <button onClick={clearSel} style={{ padding: '4px 8px', borderRadius: '7px', background: 'var(--bg-card)', border: '1px solid var(--border)', color: 'var(--text-secondary)', fontSize: '10px', fontWeight: 600, cursor: 'pointer' }}>Снять</button>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: '6px' }}>
                  <button disabled={!selected.size} onClick={() => setProductsCloud(prev => prev.map(x => selected.has(x.id) ? { ...x, hidden: false } : x))}
                    style={{ flex: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '5px', padding: '7px 6px', borderRadius: '8px', background: 'rgba(52,201,125,0.1)', border: '1px solid var(--status-ready-color)', color: 'var(--status-ready-color)', fontSize: '10.5px', fontWeight: 600, cursor: selected.size ? 'pointer' : 'default', opacity: selected.size ? 1 : 0.5 }}>
                    <Icon name="eye" size={12} color="var(--status-ready-color)" /> Показать
                  </button>
                  <button disabled={!selected.size} onClick={() => setProductsCloud(prev => prev.map(x => selected.has(x.id) ? { ...x, hidden: true } : x))}
                    style={{ flex: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '5px', padding: '7px 6px', borderRadius: '8px', background: 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', color: 'var(--accent-2-hi)', fontSize: '10.5px', fontWeight: 600, cursor: selected.size ? 'pointer' : 'default', opacity: selected.size ? 1 : 0.5 }}>
                    <Icon name="close" size={12} color="var(--accent-2-hi)" /> Скрыть
                  </button>
                  <button disabled={!selected.size} onClick={() => priceChange(selected)}
                    style={{ flex: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '5px', padding: '7px 6px', borderRadius: '8px', background: 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', color: 'var(--accent-2-hi)', fontSize: '10.5px', fontWeight: 600, cursor: selected.size ? 'pointer' : 'default', opacity: selected.size ? 1 : 0.5 }}>
                    <Icon name="card" size={12} color="var(--accent-2-hi)" /> Цена
                  </button>
                </div>
                <div style={{ display: 'flex', gap: '6px' }}>
                  <select value={moveTo} disabled={!selected.size} onChange={e => {
                    const sec = e.target.value; setMoveTo('')
                    if (!sec || !selected.size) return
                    setProductsCloud(prev => prev.map(x => selected.has(x.id) ? { ...x, series: sec } : x))
                  }}
                    style={{ flex: 1, padding: '7px 8px', borderRadius: '8px', background: 'var(--bg-card)', border: '1px solid var(--border)', color: 'var(--text-primary)', fontSize: '10.5px', fontWeight: 600, cursor: selected.size ? 'pointer' : 'default', opacity: selected.size ? 1 : 0.5 }}>
                    <option value="" style={{ background: 'var(--bg-elevated)', color: 'var(--text-primary)' }}>Перенести в раздел…</option>
                    {sections.map(s => <option key={s.id} value={s.name} style={{ background: 'var(--bg-elevated)', color: 'var(--text-primary)' }}>{s.emoji ? `${s.emoji} ` : ''}{s.name}</option>)}
                  </select>
                  <button disabled={!selected.size} onClick={() => {
                    if (!window.confirm(`Удалить выбранные товары (${selected.size})? Отменить нельзя.`)) return
                    setProductsCloud(prev => prev.filter(x => !selected.has(x.id))); clearSel()
                  }}
                    style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '5px', padding: '7px 12px', borderRadius: '8px', background: 'rgba(239,68,68,0.07)', border: '1px solid var(--danger)', color: 'var(--danger)', fontSize: '10.5px', fontWeight: 600, cursor: selected.size ? 'pointer' : 'default', opacity: selected.size ? 1 : 0.5 }}>
                    <Icon name="trash" size={12} color="var(--danger)" /> Удалить
                  </button>
                </div>
              </div>
            )}

            {addProd && !editProd && prodForm}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '7px' }}>
              {filtered.length === 0 && (
                <p style={{ color: 'var(--text-muted)', fontSize: '12px', textAlign: 'center', padding: '20px 0' }}>Ничего не найдено</p>
              )}
              {(prodSort === 'manual' ? filtered : [...filtered].sort((a, b) => prodSort === 'desc' ? b.id - a.id : a.id - b.id)).map((p, idx, shown) => {
                const isSel = selected.has(p.id)
                return (
                <Fragment key={p.id}>
                <div
                  draggable={canDrag}
                  onDragStart={() => { if (canDrag) dragIdx.current = idx }}
                  onDragOver={e => { if (!canDrag) return; e.preventDefault(); setDragOverIdx(idx) }}
                  onDrop={e => {
                    e.preventDefault()
                    // Перетаскивание работает только в режиме «Все» без поиска/фильтра — иначе порядок неполный
                    if (!canDrag) { setDragOverIdx(null); return }
                    const from = dragIdx.current
                    if (from == null || from === idx) { setDragOverIdx(null); return }
                    // Перетаскивание фиксирует текущий видимый порядок как ручной
                    const arr = [...shown]
                    const [moved] = arr.splice(from, 1)
                    arr.splice(idx, 0, moved)
                    setProductsCloud(arr)
                    setProdSort('manual')
                    dragIdx.current = null; setDragOverIdx(null)
                  }}
                  onDragEnd={() => { dragIdx.current = null; setDragOverIdx(null) }}
                  onClick={() => { if (selectMode) toggleSel(p.id) }}
                  className="glass-card"
                  style={{ padding: '10px', display: 'flex', gap: '10px', alignItems: 'center', transition: 'opacity 0.15s, transform 0.15s', opacity: dragOverIdx === idx ? 0.5 : 1, transform: dragOverIdx === idx ? 'scale(0.98)' : 'scale(1)', cursor: selectMode ? 'pointer' : (canDrag ? 'grab' : 'default'), border: isSel ? '1px solid var(--accent-2)' : undefined, boxShadow: isSel ? '0 0 0 1px var(--accent-2)' : undefined }}>
                  {/* Чекбокс выделения или ручка перетаскивания */}
                  {selectMode ? (
                    <div style={{ width: '20px', height: '20px', borderRadius: '6px', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: isSel ? 'var(--accent-2)' : 'transparent', border: `1.5px solid ${isSel ? 'var(--accent-2)' : 'var(--border)'}` }}>
                      {isSel && <Icon name="check" size={13} color="#fff" />}
                    </div>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '3px', flexShrink: 0, opacity: canDrag ? 0.4 : 0.15, paddingLeft: '1px' }}>
                      {[0,1,2].map(i => <div key={i} style={{ width: '14px', height: '2px', background: 'var(--text-secondary)', borderRadius: '2px' }} />)}
                    </div>
                  )}
                  <img src={p.img} alt={p.name} style={{ width: '44px', height: '44px', borderRadius: '9px', objectFit: 'cover', flexShrink: 0 }} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ color: 'var(--text-primary)', fontSize: '12px', fontWeight: 600, margin: '0 0 2px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</p>
                    {(() => { const { min, max } = priceRange(p); const vc = getVariants(p).length; return (
                    <p style={{ color: 'var(--text-secondary)', fontSize: '10px', margin: '0 0 1px', fontWeight: 500 }}>{p.series} · {min === max ? `${min.toLocaleString()} ₽` : `${min.toLocaleString()}–${max.toLocaleString()} ₽`} · {vc} вар. · {p.baseSize} см</p>
                    ) })()}
                    <p style={{ color: 'var(--text-secondary)', fontSize: '9px', margin: '0 0 6px' }}>{p.images.length} фото</p>
                    {!selectMode && (
                    <div style={{ display: 'flex', gap: '5px', flexWrap: 'wrap' }}>
                      <button onClick={e => { e.stopPropagation(); const open = editProd?.id === p.id; setEditProd(open ? null : { ...p, variants: getVariants(p).map(v => ({ ...v })) }); setAddProd(false) }} style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '3px 8px', borderRadius: '7px', background: editProd?.id === p.id ? 'var(--accent-2)' : 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', color: editProd?.id === p.id ? '#fff' : 'var(--accent-2-hi)', fontSize: '10px', fontWeight: 600, cursor: 'pointer' }}><Icon name={editProd?.id === p.id ? 'close' : 'pencil'} size={10} color={editProd?.id === p.id ? '#fff' : 'var(--accent-2-hi)'} /> {editProd?.id === p.id ? 'Свернуть' : 'Изменить'}</button>
                      <button onClick={e => { e.stopPropagation(); setProductsCloud(prev => prev.map(x => x.id===p.id ? {...x,inStock:!x.inStock} : x)) }} style={{ padding: '3px 8px', borderRadius: '7px', background: p.inStock ? 'rgba(52,201,125,0.09)' : 'rgba(239,68,68,0.07)', border: `1px solid ${p.inStock ? 'var(--status-ready-color)' : 'var(--danger)'}`, color: p.inStock ? 'var(--status-ready-color)' : 'var(--danger)', fontSize: '10px', fontWeight: 600, cursor: 'pointer' }}>{p.inStock ? 'В наличии' : 'Нет'}</button>
                      {/* Скрыть/показать клиентам — доступно всем, кто видит эту вкладку
                          (владелец, администратор, редактор); у модератора её нет вовсе. */}
                      <button onClick={e => { e.stopPropagation(); setProductsCloud(prev => prev.map(x => x.id===p.id ? {...x,hidden:!x.hidden} : x)) }} title={p.hidden ? 'Скрыт от клиентов' : 'Виден клиентам'} style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '3px 8px', borderRadius: '7px', background: p.hidden ? 'rgba(239,68,68,0.07)' : 'var(--accent-2-wash)', border: `1px solid ${p.hidden ? 'var(--danger)' : 'var(--accent-2)'}`, color: p.hidden ? 'var(--danger)' : 'var(--accent-2-hi)', fontSize: '10px', fontWeight: 600, cursor: 'pointer' }}>{p.hidden ? 'Скрыт' : 'Показан'}</button>
                      <button onClick={e => { e.stopPropagation(); duplicateProduct(p) }} title="Создать копию товара" style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '3px 8px', borderRadius: '7px', background: 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', color: 'var(--accent-2-hi)', fontSize: '10px', fontWeight: 600, cursor: 'pointer' }}><Icon name="layers" size={10} color="var(--accent-2-hi)" /> Копия</button>
                      <button onClick={e => { e.stopPropagation(); if (window.confirm(`Удалить товар «${p.name}»?`)) setProductsCloud(prev => prev.filter(x => x.id!==p.id)) }} style={{ display: 'flex', alignItems: 'center', padding: '3px 7px', borderRadius: '7px', background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.18)', cursor: 'pointer' }}><Icon name="trash" size={10} color="var(--danger)" /></button>
                    </div>
                    )}
                  </div>
                </div>
                {!selectMode && editProd?.id === p.id && prodForm}
                </Fragment>
                )
              })}
            </div>
          </div>
        )
      }
  </>)
}
