import { Icon, genPromoCode } from '../../shared'
import type { CrmCtx } from '../state'

export default function PromosSection(ctx: CrmCtx) {
  const { deletePromo, promoForm, promocodes, registeredUsers, savePromo, setPromoForm } = ctx
  return (<>
      {(
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div>
              <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: '0 0 4px' }}>Промокоды и розыгрыши</p>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Создавайте скидки на любой товар: одноразовые для победителей или многоразовые для всех.</p>
            </div>

            {/* Форма создания */}
            <div className="glass-card" style={{ padding: '14px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {/* Код + генератор */}
              <div>
                <label style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px' }}>Код</label>
                <div style={{ display: 'flex', gap: '6px', marginTop: '5px' }}>
                  <div className="search-glow" style={{ position: 'relative', flex: 1, borderRadius: '9px' }}>
                    <input value={promoForm.code} onChange={e => setPromoForm(f => ({ ...f, code: e.target.value.toUpperCase() }))} placeholder="SIGMA10"
                      style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '9px', padding: '9px 11px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', letterSpacing: '1.5px', fontFamily: 'monospace', boxSizing: 'border-box' }} />
                  </div>
                  <button onClick={() => setPromoForm(f => ({ ...f, code: genPromoCode() }))}
                    style={{ padding: '0 12px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '9px', color: 'var(--accent-2-hi)', fontSize: '12px', fontWeight: 600, cursor: 'pointer', flexShrink: 0, whiteSpace: 'nowrap' }}>↻ Сгенерировать</button>
                </div>
              </div>

              {/* Публичный анонс: баннер-борд с таймером для всех клиентов */}
              <button onClick={() => setPromoForm(f => ({ ...f, featured: !f.featured }))}
                style={{ display: 'flex', alignItems: 'center', gap: '11px', padding: '11px 12px', borderRadius: '11px', cursor: 'pointer', textAlign: 'left',
                  background: promoForm.featured ? 'var(--accent-2-wash)' : 'var(--bg-input)',
                  border: `1px solid ${promoForm.featured ? 'var(--accent-2)' : 'var(--border)'}` }}>
                <span style={{ fontSize: '18px', lineHeight: 1, flexShrink: 0 }}>🎁</span>
                <span style={{ flex: 1, minWidth: 0 }}>
                  <span style={{ display: 'block', color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 650 }}>Показать всем — баннер с таймером</span>
                  <span style={{ display: 'block', color: 'var(--text-muted)', fontSize: '10.5px', marginTop: '1px' }}>Появится в каталоге и на главной у всех клиентов. Нужен срок (таймер).</span>
                </span>
                <span style={{ flexShrink: 0, width: '38px', height: '22px', borderRadius: '999px', position: 'relative', transition: 'background 0.2s', background: promoForm.featured ? 'var(--accent-2)' : 'var(--border)' }}>
                  <span style={{ position: 'absolute', top: '2px', left: promoForm.featured ? '18px' : '2px', width: '18px', height: '18px', borderRadius: '50%', background: '#fff', transition: 'left 0.2s' }} />
                </span>
              </button>
              {promoForm.featured && promoForm.expiryDays <= 0 && (
                <p style={{ color: 'var(--danger)', fontSize: '10.5px', margin: '-4px 0 0' }}>Укажите «Хранить, дней» — иначе таймер не появится.</p>
              )}

              {/* Скидка + одноразовость */}
              <div style={{ display: 'flex', gap: '10px' }}>
                <div style={{ flex: 1 }}>
                  <label style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px' }}>Скидка, %</label>
                  <input type="number" inputMode="numeric" min={1} max={100} value={promoForm.discount || ''} placeholder="10" onChange={e => setPromoForm(f => ({ ...f, discount: Number(e.target.value) }))}
                    style={{ width: '100%', marginTop: '5px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '9px', padding: '9px 11px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
                </div>
                <div style={{ flex: 1 }}>
                  <label style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px' }}>Хранить, дней</label>
                  <input type="number" inputMode="numeric" min={0} value={promoForm.expiryDays || ''} onChange={e => setPromoForm(f => ({ ...f, expiryDays: Number(e.target.value) }))} placeholder="0 = бессрочно"
                    style={{ width: '100%', marginTop: '5px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '9px', padding: '9px 11px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
                </div>
              </div>

              {/* Тип: одноразовый / многоразовый (для публичного анонса не нужно) */}
              {!promoForm.featured && <div>
                <label style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px' }}>Тип использования</label>
                <div style={{ display: 'flex', gap: '6px', marginTop: '5px' }}>
                  <button onClick={() => setPromoForm(f => ({ ...f, multi: false }))}
                    style={{ flex: 1, padding: '9px', borderRadius: '9px', fontSize: '12px', fontWeight: 600, cursor: 'pointer', background: !promoForm.multi ? 'var(--accent-2-wash)' : 'var(--bg-input)', border: `1px solid ${!promoForm.multi ? 'var(--accent-2)' : 'var(--border)'}`, color: !promoForm.multi ? 'var(--accent-2-hi)' : 'var(--text-secondary)' }}>Одноразовый</button>
                  <button onClick={() => setPromoForm(f => ({ ...f, multi: true }))}
                    style={{ flex: 1, padding: '9px', borderRadius: '9px', fontSize: '12px', fontWeight: 600, cursor: 'pointer', background: promoForm.multi ? 'var(--accent-2-wash)' : 'var(--bg-input)', border: `1px solid ${promoForm.multi ? 'var(--accent-2)' : 'var(--border)'}`, color: promoForm.multi ? 'var(--accent-2-hi)' : 'var(--text-secondary)' }}>Многоразовый</button>
                </div>
                {promoForm.multi && (
                  <div style={{ marginTop: '8px' }}>
                    <label style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px' }}>Количество использований, шт</label>
                    <input type="number" inputMode="numeric" min={1} value={promoForm.maxUses || ''} placeholder="1" onChange={e => setPromoForm(f => ({ ...f, maxUses: Number(e.target.value) }))}
                      style={{ width: '100%', marginTop: '5px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '9px', padding: '9px 11px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
                  </div>
                )}
              </div>}

              {/* Победитель / получатель (для публичного анонса не нужно) */}
              {!promoForm.featured && <div>
                <label style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px' }}>Кому (для розыгрыша)</label>
                <input list="promo-users" value={promoForm.targetUser} onChange={e => setPromoForm(f => ({ ...f, targetUser: e.target.value }))} placeholder="ID победителя или пусто — для всех"
                  style={{ width: '100%', marginTop: '5px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '9px', padding: '9px 11px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
                <datalist id="promo-users">
                  {registeredUsers.map(u => <option key={u.login} value={u.login}>{u.name}</option>)}
                </datalist>
              </div>}

              <button onClick={savePromo} disabled={!promoForm.code.trim()}
                style={{ padding: '11px', background: 'var(--accent-grad)', border: 'none', borderRadius: '10px', color: '#fff', fontSize: '13px', fontWeight: 700, cursor: promoForm.code.trim() ? 'pointer' : 'default', opacity: promoForm.code.trim() ? 1 : 0.5 }}>
                Создать промокод
              </button>
            </div>

            {/* Список промокодов */}
            {promocodes.filter(p => !p.deleted).length === 0 ? (
              <p style={{ color: 'var(--text-muted)', fontSize: '12px', textAlign: 'center', padding: '10px 0', fontStyle: 'italic' }}>Промокодов пока нет</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {promocodes.filter(p => !p.deleted).map(p => {
                  const expired = p.expiresAt > 0 && Date.now() > p.expiresAt
                  const usedUp = p.uses >= p.maxUses
                  const dead = expired || usedUp
                  const target = registeredUsers.find(u => u.login.toLowerCase() === p.targetUser.toLowerCase())
                  return (
                    <div key={p.id} className="glass-card" style={{ padding: '11px 13px', display: 'flex', alignItems: 'center', gap: '10px', opacity: dead ? 0.55 : 1 }}>
                      <div style={{ minWidth: 0, flex: 1 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '3px' }}>
                          <span style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, letterSpacing: '1px', fontFamily: 'monospace' }}>{p.code}</span>
                          <span style={{ color: 'var(--accent-2-hi)', fontSize: '13px', fontWeight: 800 }}>−{p.discount}%</span>
                          {p.featured && !dead && <span style={{ fontSize: '9px', fontWeight: 800, letterSpacing: '0.04em', padding: '2px 6px', borderRadius: '999px', background: 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', color: 'var(--accent-2-hi)' }}>🎁 для всех</span>}
                          {dead && <span style={{ fontSize: '9px', fontWeight: 700, textTransform: 'uppercase', color: 'var(--danger)' }}>{expired ? 'истёк' : 'исчерпан'}</span>}
                        </div>
                        <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', margin: 0 }}>
                          {p.maxUses === 1 ? 'одноразовый' : `${p.uses}/${p.maxUses} исп.`}
                          {' · '}
                          {p.expiresAt ? `до ${new Date(p.expiresAt).toLocaleDateString('ru', { day: 'numeric', month: 'short' })}` : 'бессрочно'}
                          {p.targetUser && ` · 🎁 ${target?.name ?? p.targetUser}`}
                        </p>
                      </div>
                      <button onClick={() => deletePromo(p.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '4px', flexShrink: 0 }}>
                        <Icon name="trash" size={15} color="var(--text-muted)" />
                      </button>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        )
      }
  </>)
}
