import Cropper from 'react-easy-crop'
import { FormField, Icon } from '../../shared'
import type { CrmCtx } from '../state'

export default function NewOrderSection(ctx: CrmCtx) {
  const { applyManualPhoto, createManualOrder, handleManualFile, manualCrop, manualFileRef, manualMsg, manualOrder, manualPhotoSrc, manualPixelsRef, manualUploading, manualZoom, setManualCrop, setManualMsg, setManualOrder, setManualPhotoSrc, setManualZoom } = ctx
  return (<>
      {manualPhotoSrc && (
          <div className="overlay-fade" style={{ position: 'absolute', inset: 0, zIndex: 300, background: 'rgba(0,0,0,0.72)', backdropFilter: 'blur(5px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
            <div className="sheet-enter" style={{ width: '100%', maxWidth: '430px', background: 'var(--bg-card)', borderRadius: '22px 22px 0 0', padding: '14px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: 0 }}>Кадрирование фото</p>
                <button onClick={() => setManualPhotoSrc(null)} disabled={manualUploading} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px' }}><Icon name="close" size={18} color="var(--text-secondary)" /></button>
              </div>
              <div style={{ position: 'relative', width: '100%', height: '260px', background: '#000', borderRadius: '12px', overflow: 'hidden' }}>
                <Cropper image={manualPhotoSrc} crop={manualCrop} zoom={manualZoom} aspect={1} showGrid onCropChange={setManualCrop} onZoomChange={setManualZoom} onCropComplete={(_, px) => { manualPixelsRef.current = px }} />
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Icon name="search" size={15} color="var(--text-muted)" />
                <input type="range" min={1} max={4} step={0.01} value={manualZoom} onChange={e => setManualZoom(Number(e.target.value))} style={{ flex: 1, accentColor: 'var(--accent-2)' }} />
              </div>
              <div style={{ display: 'flex', gap: '8px' }}>
                <button className="btn-secondary" onClick={() => setManualPhotoSrc(null)} disabled={manualUploading} style={{ flex: 1 }}>Отмена</button>
                <button className="btn-primary" onClick={applyManualPhoto} disabled={manualUploading} style={{ flex: 2 }}>{manualUploading ? 'Загрузка…' : 'Готово'}</button>
              </div>
            </div>
          </div>
        )
      }
      {(
          <div className="glass-card" style={{ padding: '14px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
              <Icon name="plus" size={16} color="var(--accent)" />
              <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: 0 }}>Создать заказ вручную</p>
            </div>
            <p style={{ color: 'var(--text-muted)', fontSize: '11px', lineHeight: 1.5, margin: '0 0 14px' }}>Для индивидуальных заказов. Заказ появится у клиента с указанным Telegram ID и будет синхронизирован.</p>

            <div style={{ marginBottom: '10px' }}>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 4px', fontWeight: 500 }}>Telegram ID клиента</p>
              <div style={{ position: 'relative' }}>
                <span style={{ position: 'absolute', left: '11px', top: '50%', transform: 'translateY(-50%)', color: 'var(--accent)', fontSize: '14px', pointerEvents: 'none' }}>@</span>
                <input value={manualOrder.userId.replace(/^@/, '')} onChange={e => { setManualOrder(m => ({ ...m, userId: e.target.value })); setManualMsg('') }} placeholder="username"
                  style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '9px 12px 9px 26px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
              </div>
            </div>

            <FormField label="Название заказа" value={manualOrder.name} onChange={v => { setManualOrder(m => ({ ...m, name: v })); setManualMsg('') }} />
            <FormField label="Серия / категория (необязательно)" value={manualOrder.figure} onChange={v => setManualOrder(m => ({ ...m, figure: v }))} />

            <div style={{ marginBottom: '10px' }}>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 4px', fontWeight: 500 }}>Фото заказа (необязательно)</p>
              <input ref={manualFileRef} type="file" accept="image/*" onChange={handleManualFile} style={{ display: 'none' }} />
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div onClick={() => manualFileRef.current?.click()} style={{ width: '56px', height: '56px', borderRadius: '12px', background: 'var(--bg-elevated)', border: '1px dashed var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', overflow: 'hidden', flexShrink: 0, position: 'relative' }}>
                  {manualOrder.thumb ? <img src={manualOrder.thumb} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <Icon name="camera" size={18} color="var(--text-muted)" />}
                </div>
                <button className="btn-secondary" style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }} onClick={() => manualFileRef.current?.click()}>
                  <Icon name="image" size={13} color="var(--text-secondary)" /> {manualOrder.thumb ? 'Заменить фото' : 'Добавить фото'}
                </button>
                {manualOrder.thumb && (
                  <button onClick={() => setManualOrder(m => ({ ...m, thumb: '' }))} title="Убрать фото" style={{ width: '32px', height: '32px', borderRadius: '9px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Icon name="trash" size={13} color="var(--danger)" />
                  </button>
                )}
              </div>
            </div>

            <div style={{ marginBottom: '10px' }}>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 4px', fontWeight: 500 }}>Стоимость, ₽</p>
              <input value={manualOrder.price} onChange={e => { setManualOrder(m => ({ ...m, price: e.target.value.replace(/[^0-9]/g, '') })); setManualMsg('') }} inputMode="numeric" placeholder="3000"
                style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '9px 12px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
            </div>

            <div style={{ display: 'flex', gap: '8px', marginBottom: '14px' }}>
              <button onClick={() => setManualOrder(m => ({ ...m, painted: !m.painted }))} style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '9px', borderRadius: '10px', background: manualOrder.painted ? 'var(--accent-2-wash)' : 'var(--bg-elevated)', border: `1px solid ${manualOrder.painted ? 'var(--accent-2)' : 'var(--border)'}`, color: manualOrder.painted ? 'var(--accent-2-hi)' : 'var(--text-secondary)', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}>
                <Icon name={manualOrder.painted ? 'check' : 'close'} size={13} color={manualOrder.painted ? 'var(--accent-2-hi)' : 'var(--text-muted)'} /> С покраской
              </button>
              <button onClick={() => setManualOrder(m => ({ ...m, paid: !m.paid }))} style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '9px', borderRadius: '10px', background: manualOrder.paid ? 'var(--accent-2-wash)' : 'var(--bg-elevated)', border: `1px solid ${manualOrder.paid ? 'var(--accent-2)' : 'var(--border)'}`, color: manualOrder.paid ? 'var(--accent-2-hi)' : 'var(--text-secondary)', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}>
                <Icon name={manualOrder.paid ? 'check' : 'card'} size={13} color={manualOrder.paid ? 'var(--accent-2-hi)' : 'var(--text-muted)'} /> Оплачен
              </button>
            </div>

            {manualMsg && <p style={{ color: manualMsg.startsWith('Заказ') ? 'var(--accent)' : 'var(--danger)', fontSize: '12px', fontWeight: 600, margin: '0 0 10px' }}>{manualMsg}</p>}
            <button className="btn-primary" style={{ width: '100%' }} onClick={createManualOrder}>Создать заказ</button>
          </div>
        )
      }
  </>)
}
