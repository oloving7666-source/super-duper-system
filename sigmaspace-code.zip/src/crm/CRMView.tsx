import { useState, useEffect } from 'react'
import Cropper from 'react-easy-crop'
import { Icon } from '../shared'
import { cloudQuotaActive } from '../api'
import { Sidebar, SigmaMark } from '../ui'
import { useCrmState, type CrmProps } from './state'
import OrdersSection from './sections/Orders'
import NewOrderSection from './sections/NewOrder'
import PayVerifySection from './sections/PayVerify'
import RolesSection from './sections/Roles'
import ProductsSection from './sections/Products'
import SectionsSection from './sections/Sections'
import UsersSection from './sections/Users'
import FaqSection from './sections/Faq'
import MaterialsSection from './sections/Materials'
import ReviewsSection from './sections/Reviews'
import NoticeSection from './sections/Notice'
import HomeSection from './sections/Home'
import CustomOrderSection from './sections/CustomOrder'
import PromosSection from './sections/Promos'
import PaymentsSection from './sections/Payments'
import PubHubSection from './sections/PubHub'
import DashboardSection from './sections/Dashboard'
import LoyaltySection from './sections/Loyalty'
import LogsSection from './sections/Logs'

/** Каждый раздел живёт в отдельном файле — здесь только маршрутизация. Раздел «Баннер» удалён. */
const SECTIONS: Record<string, (ctx: ReturnType<typeof useCrmState>) => React.ReactElement> = {
  orders: OrdersSection, neworder: NewOrderSection, payverify: PayVerifySection,
  roles: RolesSection, products: ProductsSection, sections: SectionsSection,
  users: UsersSection, faq: FaqSection, materials: MaterialsSection,
  reviews: ReviewsSection, notice: NoticeSection,
  home: HomeSection,
  custom: CustomOrderSection, promos: PromosSection,
  payments: PaymentsSection, pubhub: PubHubSection,
  dashboard: DashboardSection, loyalty: LoyaltySection, logs: LogsSection,
}

export default function CRMView(props: CrmProps) {
  const ctx = useCrmState(props)
  const {
    crmTab, setCrmTab, visibleTabs, totalRevenue, registeredUsers, products,
    cropJob, cropQueue, skipCrop, imgUploading, crop, zoom, setCrop, setZoom, cropPixelsRef, applyCrop,
    pubJob, closePubEditor, postUploading, PUB_ASPECTS, pubAspect, setPubAspect,
    pubPos, pubZoom, setPubPos, setPubZoom, pubPixelsRef, pubProgress, skipPubCrop, applyPubCrop,
    isOwner, moveCrmTab,
  } = ctx
  const [navOpen, setNavOpen] = useState(false)
  const [navEditing, setNavEditing] = useState(false)
  // Индикатор состояния облака: cloudQuotaActive() — не реактивная функция, поэтому
  // опрашиваем её раз в несколько секунд, чтобы показывать «пауза/синхр.» в шапке.
  const [cloudPaused, setCloudPaused] = useState(cloudQuotaActive())
  useEffect(() => {
    const t = setInterval(() => setCloudPaused(cloudQuotaActive()), 5000)
    return () => clearInterval(t)
  }, [])
  const navItems = visibleTabs.map(t => ({ key: t.key, label: t.label, icon: <Icon name={t.icon} size={16} />, badge: t.badge || undefined }))
  const stats = [
    { l: 'Выручка', v: `${(totalRevenue / 1000).toFixed(1)}к` },
    { l: 'Клиентов', v: registeredUsers.length },
    { l: 'Товаров', v: products.length },
  ]
  const Section = SECTIONS[crmTab]
  const current = visibleTabs.find(t => t.key === crmTab)

  return (
    <div data-surface="crm" className="ss-aurora" style={{ display: 'flex', height: '100%', minHeight: 0 }}>
      {cropJob && (
        <div className="overlay-fade" style={{ position: 'absolute', inset: 0, zIndex: 200, background: 'rgba(0,0,0,0.72)', backdropFilter: 'blur(5px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
          <div className="sheet-enter" style={{ width: '100%', maxWidth: '430px', background: 'var(--bg-card)', borderRadius: '22px 22px 0 0', padding: '14px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: 0 }}>Кадрирование фото {cropQueue.length > 1 ? `(${cropQueue.length} в очереди)` : ''}</p>
              <button onClick={skipCrop} disabled={imgUploading} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px' }}><Icon name="close" size={18} color="var(--text-secondary)" /></button>
            </div>
            <div style={{ position: 'relative', width: '100%', height: '260px', background: '#000', borderRadius: '12px', overflow: 'hidden' }}>
              <Cropper image={cropJob.src} crop={crop} zoom={zoom} aspect={1} showGrid onCropChange={setCrop} onZoomChange={setZoom} onCropComplete={(_, px) => { cropPixelsRef.current = px }} />
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Icon name="search" size={15} color="var(--text-muted)" />
              <input type="range" min={1} max={4} step={0.01} value={zoom} onChange={e => setZoom(Number(e.target.value))} style={{ flex: 1, accentColor: 'var(--accent-2)' }} />
            </div>
            <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0, textAlign: 'center' }}>Двигайте фото пальцем и приближайте ползунком — в товар попадёт выбранный квадрат.</p>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button className="btn-secondary" onClick={skipCrop} disabled={imgUploading} style={{ flex: 1 }}>Пропустить</button>
              <button className="btn-primary" onClick={applyCrop} disabled={imgUploading} style={{ flex: 2 }}>{imgUploading ? 'Загрузка…' : 'Готово'}</button>
            </div>
          </div>
        </div>
      )}
      {pubJob && (
        <div className="overlay-fade" style={{ position: 'absolute', inset: 0, zIndex: 200, background: 'rgba(0,0,0,0.72)', backdropFilter: 'blur(5px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
          <div className="sheet-enter" style={{ width: '100%', maxWidth: '430px', background: 'var(--bg-card)', borderRadius: '22px 22px 0 0', padding: '14px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: 0 }}>Кадр {pubJob.kind === 'photo' ? 'фото' : 'видео'} для поста</p>
              <button onClick={closePubEditor} disabled={postUploading} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px' }}><Icon name="close" size={18} color="var(--text-secondary)" /></button>
            </div>

            {/* Пропорции кадра */}
            <div style={{ display: 'flex', gap: '6px' }}>
              {PUB_ASPECTS.map(a => (
                <button key={a.label} onClick={() => setPubAspect(a.value)}
                  style={{ flex: 1, padding: '8px 0', borderRadius: '10px', border: `1px solid ${pubAspect === a.value ? 'var(--accent-2)' : 'var(--border)'}`, background: pubAspect === a.value ? 'var(--accent-2-wash)' : 'var(--bg-elevated)', color: pubAspect === a.value ? 'var(--accent-2-hi)' : 'var(--text-secondary)', fontSize: '12px', fontWeight: 600, cursor: 'pointer', transition: 'all 0.15s' }}>
                  {a.label}
                </button>
              ))}
            </div>

            <div style={{ position: 'relative', width: '100%', height: '280px', background: '#000', borderRadius: '12px', overflow: 'hidden' }}>
              <Cropper
                {...(pubJob.kind === 'photo' ? { image: pubJob.src } : { video: pubJob.src })}
                crop={pubPos} zoom={pubZoom} aspect={pubAspect} showGrid
                objectFit="contain"
                onCropChange={setPubPos} onZoomChange={setPubZoom}
                onCropComplete={(_, px) => { pubPixelsRef.current = px }}
              />
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Icon name="search" size={15} color="var(--text-muted)" />
              <input type="range" min={1} max={4} step={0.01} value={pubZoom} onChange={e => setPubZoom(Number(e.target.value))} style={{ flex: 1, accentColor: 'var(--accent-2)' }} />
            </div>

            {pubProgress !== null ? (
              <div>
                <div style={{ height: '6px', borderRadius: '3px', background: 'var(--bg-elevated)', overflow: 'hidden' }}>
                  <div style={{ width: `${pubProgress}%`, height: '100%', background: 'var(--accent-2)', transition: 'width 0.2s' }} />
                </div>
                <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '6px 0 0', textAlign: 'center' }}>
                  Пересобираем видео — {pubProgress}%. Ролик проигрывается целиком, не закрывайте окно.
                </p>
              </div>
            ) : (
              <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0, textAlign: 'center', lineHeight: 1.5 }}>
                {pubJob.kind === 'photo'
                  ? 'Двигайте фото пальцем и приближайте ползунком — в пост уйдёт выбранная область.'
                  : 'Выберите область — видео будет пересобрано под неё, чтобы в канале не было кривых полей.'}
              </p>
            )}

            <div style={{ display: 'flex', gap: '8px' }}>
              <button className="btn-secondary" onClick={skipPubCrop} disabled={postUploading} style={{ flex: 1 }}>Без обрезки</button>
              <button className="btn-primary" onClick={applyPubCrop} disabled={postUploading} style={{ flex: 2 }}>{postUploading ? 'Обработка…' : 'Готово'}</button>
            </div>
          </div>
        </div>
      )}
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <div style={{ flexShrink: 0, display: 'flex', alignItems: 'center', gap: 9, padding: '13px 16px', borderBottom: '1px solid var(--ss-hairline-lo)', background: 'var(--top-bar-bg)', backdropFilter: 'blur(14px)' }}>
          <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
            {stats.map(s => (
              <div key={s.l} style={{ padding: '3px 8px', borderRadius: 'var(--ss-r-pill)', background: 'var(--accent-2-wash)', border: '1px solid var(--ss-hairline-lo)', textAlign: 'center', lineHeight: 1.2 }}>
                <span style={{ display: 'block', color: 'var(--accent-2-hi)', fontSize: 11.5, fontWeight: 700 }}>{s.v}</span>
                <span style={{ display: 'block', color: 'var(--ss-ink-3)', fontSize: 8 }}>{s.l}</span>
              </div>
            ))}
          </div>
          <span title={cloudPaused ? 'Облако на паузе: превышена квота проекта. Данные сохраняются локально.' : 'Облако синхронизировано'}
            style={{ display: 'inline-flex', alignItems: 'center', gap: 4, flexShrink: 0, padding: '3px 8px', borderRadius: 'var(--ss-r-pill)', fontSize: 9.5, fontWeight: 700,
              background: cloudPaused ? 'rgba(239,68,68,0.1)' : 'rgba(52,201,125,0.1)',
              border: `1px solid ${cloudPaused ? 'var(--danger)' : 'var(--status-ready-color)'}`,
              color: cloudPaused ? 'var(--danger)' : 'var(--status-ready-color)' }}>
            ☁ {cloudPaused ? 'пауза' : 'синхр.'}
          </span>
          {current && <Icon name={current.icon} size={17} color="var(--ss-brand-hi)" />}
          <p style={{ margin: 0, color: 'var(--ss-ink)', fontSize: 15, fontWeight: 680, flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', textAlign: 'right' }}>{current?.label ?? 'Панель мастера'}</p>
        </div>
        <div style={{ flex: 1, minHeight: 0, overflowY: 'auto', padding: '12px' }}>
          {Section ? <Section {...ctx} /> : null}
        </div>
      </div>
      {navOpen && <div onClick={() => setNavOpen(false)} style={{ position: 'absolute', inset: 0, zIndex: 30, background: 'rgba(3,3,8,0.6)' }} />}

      <Sidebar
        collapsed={!navOpen}
        items={navItems}
        active={crmTab}
        onSelect={k => { setCrmTab(k as typeof crmTab); setNavOpen(false) }}
        width={navOpen ? 196 : 54}
        side="right"
        editing={navEditing}
        onMove={(k, dir) => moveCrmTab(k, dir)}
        style={navOpen ? { position: 'absolute', top: 0, bottom: 0, right: 0, zIndex: 40, boxShadow: '-18px 0 46px rgba(0,0,0,0.62)' } : undefined}
        header={
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: '0 0 11px', borderBottom: '1px solid var(--ss-hairline-lo)' }}>
            <button onClick={() => setNavOpen(o => { const nx = !o; if (!nx) setNavEditing(false); return nx })} className="ss-press" aria-label="Разделы панели"
              style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5, width: '100%', background: 'none', border: 'none', cursor: 'pointer' }}>
              <SigmaMark size={navOpen ? 28 : 22} />
              {navOpen && (
                <div style={{ textAlign: 'center', lineHeight: 1.1 }}>
                  <p style={{ margin: 0, color: 'var(--ss-ink)', fontSize: 13, fontWeight: 700, letterSpacing: '0.22em' }}>SIGMA</p>
                  <p style={{ margin: 0, color: 'var(--ss-brand-ink)', fontSize: 8.5, fontWeight: 600, letterSpacing: '0.34em' }}>MASTER</p>
                </div>
              )}
            </button>
            {/* Кнопка редактирования порядка разделов — только владелец и только в раскрытом рельсе */}
            {navOpen && isOwner && (
              <button onClick={() => setNavEditing(e => !e)} className="ss-press"
                style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, width: '100%', padding: '7px 0', borderRadius: 'var(--ss-r-sm)', cursor: 'pointer',
                  background: navEditing ? 'linear-gradient(180deg, var(--ss-blue-hi), var(--ss-blue-lo))' : 'var(--ss-blue-wash)',
                  border: `1px solid ${navEditing ? 'var(--ss-blue-edge)' : 'var(--ss-hairline-lo)'}`,
                  color: navEditing ? '#fff' : 'var(--ss-blue-ink)', fontSize: 11.5, fontWeight: 650, fontFamily: 'inherit' }}>
                <Icon name={navEditing ? 'check' : 'pencil'} size={13} color={navEditing ? '#fff' : 'var(--ss-blue-ink)'} />
                {navEditing ? 'Сохранить порядок' : 'Изменить порядок'}
              </button>
            )}
          </div>
        }
        footer={navOpen ? (
          <div style={{ display: 'grid', gap: 6 }}>
            {stats.map(s => (
              <div key={s.l} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '6px 9px', borderRadius: 'var(--ss-r-sm)', background: 'var(--accent-2-wash)', border: '1px solid var(--ss-hairline-lo)' }}>
                <span style={{ color: 'var(--ss-ink-3)', fontSize: 10 }}>{s.l}</span>
                <span style={{ color: 'var(--accent-2-hi)', fontSize: 12.5, fontWeight: 700 }}>{s.v}</span>
              </div>
            ))}
          </div>
        ) : undefined}
      />
    </div>
  )
}
