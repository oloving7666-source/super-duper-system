import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import 'react-easy-crop/react-easy-crop.css'
import './index.css'
import { protectMedia } from './protectMedia'
import { projectId } from '../utils/supabase/info'

protectMedia()

// Фото товаров, аватарки и обложки лежат в Supabase Storage. Открываем соединение
// с ним заранее: иначе первая же картинка платит DNS + TLS-рукопожатие (на мобильной
// сети это легко полсекунды-секунда до того, как начнётся сама загрузка).
for (const rel of ['preconnect', 'dns-prefetch']) {
  const l = document.createElement('link')
  l.rel = rel
  l.href = `https://${projectId}.supabase.co`
  if (rel === 'preconnect') l.crossOrigin = 'anonymous'
  document.head.appendChild(l)
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
