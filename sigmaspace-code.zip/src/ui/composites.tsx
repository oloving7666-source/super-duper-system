import React from 'react'
import { Surface, Badge, Spinner, ProgressBar, Sparkline, type Tone } from './primitives'

/**
 * SigmaSpace UI — составные компоненты: карточки, таймлайн, состояния.
 * Как и примитивы, зависят только от токенов `--ss-*`.
 */

/* ─────────────────────────────  Section / Stat  ─────────────────────────── */

/** Заголовок секции с необязательным действием справа. */
export function SectionHead({
  title, action, onAction, icon,
}: { title: React.ReactNode; action?: React.ReactNode; onAction?: () => void; icon?: React.ReactNode }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, marginBottom: 'var(--ss-s3)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 9, minWidth: 0 }}>
        {icon}
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 680, letterSpacing: '-0.01em', color: 'var(--ss-ink)' }}>
          {title}
        </h2>
      </div>
      {action && (
        <button
          onClick={onAction}
          className="ss-press"
          style={{
            background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'inherit',
            fontSize: 13.5, fontWeight: 600, color: 'var(--ss-brand-ink)',
            display: 'inline-flex', alignItems: 'center', gap: 4, padding: 0,
          }}
        >
          {action}
        </button>
      )}
    </div>
  )
}

/** KPI-плитка: иконка, число, дельта и спарклайн. */
export function StatTile({
  label, value, delta, deltaTone = 'ok', icon, spark, tone = 'brand',
}: {
  label: React.ReactNode
  value: React.ReactNode
  delta?: React.ReactNode
  deltaTone?: Tone
  icon?: React.ReactNode
  spark?: number[]
  tone?: Tone
}) {
  const deltaFg =
    deltaTone === 'ok' ? 'var(--ss-ok)' : deltaTone === 'bad' ? 'var(--ss-bad)'
    : deltaTone === 'warn' ? 'var(--ss-warn)' : 'var(--ss-ink-3)'
  return (
    <Surface tone="glass" radius="md" pad={16} interactive style={{ minWidth: 0 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10 }}>
        <span style={{ fontSize: 12.5, color: 'var(--ss-ink-3)', fontWeight: 550 }}>{label}</span>
        {icon && (
          <span style={{
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            width: 32, height: 32, borderRadius: 'var(--ss-r-xs)', flexShrink: 0,
            background: 'var(--ss-blue-wash)', border: '1px solid var(--ss-blue-edge)',
            color: 'var(--ss-blue-ink)',
          }}>{icon}</span>
        )}
      </div>
      <div style={{ marginTop: 8, fontSize: 26, fontWeight: 700, letterSpacing: '-0.02em', color: 'var(--ss-ink)' }}>
        {value}
      </div>
      {delta && <div style={{ marginTop: 4, fontSize: 12, fontWeight: 600, color: deltaFg }}>{delta}</div>}
      {spark && <div style={{ marginTop: 10 }}><Sparkline data={spark} width={140} height={30} tone={tone} /></div>}
    </Surface>
  )
}

/* ──────────────────────────────  Карточки  ─────────────────────────────── */

/**
 * Карточка товара. Фигурка может выходить за границы контейнера
 * (`bleed`) — рога и волосы создают ощущение объёма.
 */
export function ProductCard({
  image, title, price, meta, badge, badgeTone = 'brand', favorite, onFavorite, action, bleed = false, onClick,
}: {
  image: string
  title: React.ReactNode
  price?: React.ReactNode
  meta?: React.ReactNode
  badge?: React.ReactNode
  badgeTone?: Tone
  favorite?: boolean
  onFavorite?: () => void
  action?: React.ReactNode
  bleed?: boolean
  onClick?: () => void
}) {
  return (
    <Surface
      tone="glass" radius="lg" interactive onClick={onClick}
      className={bleed ? 'ss-overflow-figure' : undefined}
      style={{ display: 'flex', flexDirection: 'column', overflow: bleed ? 'visible' : 'hidden' }}
    >
      <div style={{
        position: 'relative', aspectRatio: '1 / 1', overflow: bleed ? 'visible' : 'hidden',
        borderRadius: 'var(--ss-r-lg) var(--ss-r-lg) 0 0',
        background: 'radial-gradient(circle at 50% 92%, var(--ss-brand-wash), transparent 62%)',
      }}>
        <img
          src={image} alt="" loading="lazy"
          style={{
            width: '100%', height: '100%', objectFit: 'contain', display: 'block',
            transform: bleed ? 'scale(1.14) translateY(-6%)' : undefined,
            filter: 'drop-shadow(0 18px 26px rgba(0,0,0,0.7))',
          }}
        />
        {badge && <div style={{ position: 'absolute', top: 10, left: 10 }}><Badge tone={badgeTone}>{badge}</Badge></div>}
        {onFavorite && (
          <button
            onClick={e => { e.stopPropagation(); onFavorite() }}
            className="ss-press"
            aria-label="В избранное"
            style={{
              position: 'absolute', top: 8, right: 8, width: 34, height: 34, borderRadius: '50%',
              display: 'grid', placeItems: 'center', cursor: 'pointer',
              background: 'var(--ss-glass-2)', border: '1px solid var(--ss-hairline)',
              backdropFilter: 'blur(10px)',
              color: favorite ? 'var(--ss-brand-hi)' : 'var(--ss-ink-3)',
            }}
          >
            <svg viewBox="0 0 24 24" width="17" height="17" fill={favorite ? 'currentColor' : 'none'}
                 stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round">
              <path d="M20.8 6.6a5 5 0 0 0-8.8-1.6A5 5 0 0 0 3.2 6.6c-1 3 1.3 6 8.8 12 7.5-6 9.8-9 8.8-12Z" />
            </svg>
          </button>
        )}
      </div>

      <div style={{ padding: '12px 14px 14px', display: 'flex', flexDirection: 'column', gap: 3 }}>
        <div style={{ fontSize: 14.5, fontWeight: 640, color: 'var(--ss-ink)', lineHeight: 1.25 }}>{title}</div>
        {meta && <div style={{ fontSize: 11.5, color: 'var(--ss-ink-3)' }}>{meta}</div>}
        {(price != null || action) && (
          <div style={{ marginTop: 7, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
            {price != null && (
              <span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.01em', color: 'var(--ss-ink)' }}>{price}</span>
            )}
            {action}
          </div>
        )}
      </div>
    </Surface>
  )
}

/** Карточка заказа: превью, статус, прогресс этапа. */
export function OrderCard({
  image, id, title, subtitle, price, status, statusTone = 'brand', progress, footer, onClick,
}: {
  image?: string
  id: React.ReactNode
  title: React.ReactNode
  subtitle?: React.ReactNode
  price?: React.ReactNode
  status?: React.ReactNode
  statusTone?: Tone
  progress?: number
  footer?: React.ReactNode
  onClick?: () => void
}) {
  return (
    <Surface tone="glass" radius="md" pad={14} interactive onClick={onClick}>
      <div style={{ display: 'flex', gap: 13 }}>
        {image && (
          <img
            src={image} alt="" loading="lazy"
            style={{
              width: 74, height: 90, objectFit: 'cover', borderRadius: 'var(--ss-r-sm)', flexShrink: 0,
              background: 'var(--ss-glass-1)', border: '1px solid var(--ss-hairline-lo)',
            }}
          />
        )}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            <span style={{ fontSize: 14, fontWeight: 680, color: 'var(--ss-ink)' }}>{id}</span>
            {status && <Badge tone={statusTone}>{status}</Badge>}
            {price != null && (
              <span style={{ marginLeft: 'auto', fontSize: 15, fontWeight: 700, color: 'var(--ss-ink)' }}>{price}</span>
            )}
          </div>
          <div style={{ marginTop: 5, fontSize: 13.5, color: 'var(--ss-ink-2)', lineHeight: 1.3 }}>{title}</div>
          {subtitle && <div style={{ marginTop: 2, fontSize: 11.5, color: 'var(--ss-ink-3)' }}>{subtitle}</div>}
          {progress != null && (
            <div style={{ marginTop: 10 }}><ProgressBar value={progress} tone={statusTone} /></div>
          )}
        </div>
      </div>
      {footer && (
        <div style={{ marginTop: 12, paddingTop: 11, borderTop: '1px solid var(--ss-hairline-lo)' }}>{footer}</div>
      )}
    </Surface>
  )
}

/* ────────────────────────  Производственный прогресс  ───────────────────── */

export type StageState = 'done' | 'active' | 'todo'

/** Горизонтальный степпер этапов производства. */
export function Stepper({
  stages, tone = 'brand',
}: { stages: { label: React.ReactNode; state: StageState }[]; tone?: Tone }) {
  const fg = tone === 'ok' ? 'var(--ss-ok)' : tone === 'warn' ? 'var(--ss-warn)' : 'var(--ss-blue)'
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start' }}>
      {stages.map((s, i) => {
        const on = s.state !== 'todo'
        return (
          <div key={i} style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', position: 'relative' }}>
            {i > 0 && (
              <span style={{
                position: 'absolute', top: 10, right: '50%', width: '100%', height: 2, borderRadius: 2,
                background: on ? fg : 'var(--ss-hairline)',
                transition: 'background var(--ss-t-base) var(--ss-ease)',
              }} />
            )}
            <span style={{
              position: 'relative', width: 21, height: 21, borderRadius: '50%', display: 'grid', placeItems: 'center',
              background: s.state === 'done' ? fg : s.state === 'active' ? 'var(--ss-abyss)' : 'var(--ss-glass-2)',
              border: `2px solid ${on ? fg : 'var(--ss-hairline)'}`,
              boxShadow: s.state === 'active' ? `0 0 0 4px color-mix(in srgb, ${fg} 18%, transparent)` : undefined,
            }}>
              {s.state === 'done' && (
                <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="#fff" strokeWidth="3.4"
                     strokeLinecap="round" strokeLinejoin="round"><path d="m5 13 4.5 4.5L19 7" /></svg>
              )}
              {s.state === 'active' && (
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: fg,
                               animation: 'ss-pulse-glow 1.8s var(--ss-ease-soft) infinite' }} />
              )}
            </span>
            <span style={{
              marginTop: 7, fontSize: 10.5, lineHeight: 1.25, textAlign: 'center', padding: '0 3px',
              color: on ? 'var(--ss-ink-2)' : 'var(--ss-ink-4)', fontWeight: s.state === 'active' ? 650 : 500,
            }}>{s.label}</span>
          </div>
        )
      })}
    </div>
  )
}

/** Вертикальный таймлайн событий. */
export function Timeline({
  items,
}: { items: { icon?: React.ReactNode; title: React.ReactNode; note?: React.ReactNode; time?: React.ReactNode; tone?: Tone }[] }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column' }}>
      {items.map((it, i) => {
        const fg = it.tone === 'ok' ? 'var(--ss-ok)' : it.tone === 'warn' ? 'var(--ss-warn)'
          : it.tone === 'bad' ? 'var(--ss-bad)' : 'var(--ss-brand)'
        return (
          <div key={i} style={{ display: 'flex', gap: 12, position: 'relative', paddingBottom: i === items.length - 1 ? 0 : 18 }}>
            {i < items.length - 1 && (
              <span style={{ position: 'absolute', left: 13, top: 28, bottom: 0, width: 1.5, background: 'var(--ss-hairline)' }} />
            )}
            <span style={{
              width: 27, height: 27, borderRadius: 'var(--ss-r-xs)', flexShrink: 0, display: 'grid', placeItems: 'center',
              background: 'var(--ss-glass-2)', border: `1px solid ${fg}`, color: fg, zIndex: 1,
            }}>
              {it.icon ?? <span style={{ width: 6, height: 6, borderRadius: '50%', background: fg }} />}
            </span>
            <div style={{ flex: 1, minWidth: 0, paddingTop: 3 }}>
              <div style={{ display: 'flex', gap: 10, alignItems: 'baseline' }}>
                <span style={{ fontSize: 13.5, fontWeight: 620, color: 'var(--ss-ink)' }}>{it.title}</span>
                {it.time && <span style={{ marginLeft: 'auto', fontSize: 11.5, color: 'var(--ss-ink-4)', flexShrink: 0 }}>{it.time}</span>}
              </div>
              {it.note && <div style={{ marginTop: 2, fontSize: 12, color: 'var(--ss-ink-3)' }}>{it.note}</div>}
            </div>
          </div>
        )
      })}
    </div>
  )
}

/* ────────────────────────────  Состояния  ──────────────────────────────── */

/** Скелет-плейсхолдер под загрузку. */
export function Skeleton({ h = 16, w = '100%', radius = 'sm' }: { h?: number | string; w?: number | string; radius?: string }) {
  return (
    <div style={{
      height: h, width: w, borderRadius: `var(--ss-r-${radius})`,
      background: 'linear-gradient(90deg, var(--ss-glass-1), var(--ss-glass-3), var(--ss-glass-1))',
      backgroundSize: '220% 100%', animation: 'ss-sheen 1.6s linear infinite',
    }} />
  )
}

/** Пустое / ошибочное / успешное состояние экрана. */
export function StateBlock({
  kind = 'empty', icon, title, note, action,
}: {
  kind?: 'empty' | 'error' | 'success' | 'loading'
  icon?: React.ReactNode
  title: React.ReactNode
  note?: React.ReactNode
  action?: React.ReactNode
}) {
  const fg = kind === 'error' ? 'var(--ss-bad)' : kind === 'success' ? 'var(--ss-ok)' : 'var(--ss-brand)'
  return (
    <div className="ss-rise" style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center',
      padding: '44px 24px', gap: 12,
    }}>
      <div style={{
        width: 72, height: 72, borderRadius: '50%', display: 'grid', placeItems: 'center',
        background: `radial-gradient(circle at 50% 38%, color-mix(in srgb, ${fg} 20%, transparent), transparent 70%)`,
        border: `1px solid color-mix(in srgb, ${fg} 34%, transparent)`,
        color: fg, boxShadow: `0 0 40px -14px ${fg}`,
      }}>
        {kind === 'loading' ? <Spinner size={26} /> : icon}
      </div>
      <div style={{ fontSize: 16.5, fontWeight: 660, color: 'var(--ss-ink)' }}>{title}</div>
      {note && <div style={{ fontSize: 13, color: 'var(--ss-ink-3)', maxWidth: 300, lineHeight: 1.45 }}>{note}</div>}
      {action && <div style={{ marginTop: 6 }}>{action}</div>}
    </div>
  )
}

/** Зона загрузки файлов и референсов. */
export function Dropzone({
  hint = 'Перетащите файлы или нажмите для загрузки', sub, icon, onPick,
}: { hint?: React.ReactNode; sub?: React.ReactNode; icon?: React.ReactNode; onPick?: () => void }) {
  return (
    <button
      onClick={onPick}
      className="ss-press"
      style={{
        width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        gap: 8, padding: '26px 18px', cursor: 'pointer', fontFamily: 'inherit',
        borderRadius: 'var(--ss-r-md)', background: 'var(--ss-glass-1)',
        border: '1.5px dashed var(--ss-hairline-hi)', color: 'var(--ss-ink-3)',
      }}
    >
      <span style={{ color: 'var(--ss-blue-ink)' }}>
        {icon ?? (
          <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="1.6"
               strokeLinecap="round" strokeLinejoin="round">
            <path d="M18 16.5a4 4 0 0 0-1.2-7.8A6 6 0 0 0 5.3 10 3.75 3.75 0 0 0 6 17.5" />
            <path d="M12 12v8M8.5 15.5 12 12l3.5 3.5" />
          </svg>
        )}
      </span>
      <span style={{ fontSize: 13, lineHeight: 1.4, textAlign: 'center' }}>{hint}</span>
      {sub && <span style={{ fontSize: 11.5, color: 'var(--ss-ink-4)' }}>{sub}</span>}
    </button>
  )
}

