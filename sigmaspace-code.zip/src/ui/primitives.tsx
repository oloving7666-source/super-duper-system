import React from 'react'

/**
 * SigmaSpace UI — базовые примитивы слоя редизайна.
 *
 * Компоненты опираются только на токены `--ss-*` из index.css, поэтому их
 * можно вставлять в любой существующий экран, ничего в нём не ломая.
 * Иконки передаются пропсом `icon` — библиотека не знает про App.tsx.
 */

type Div = React.HTMLAttributes<HTMLDivElement>

const cx = (...v: (string | false | undefined | null)[]) => v.filter(Boolean).join(' ')

/* ────────────────────────────────  Surface  ──────────────────────────────── */

export type SurfaceTone = 'glass' | 'solid' | 'bare'

/** Физическая поверхность: стекло, металл или прозрачная подложка. */
export function Surface({
  tone = 'glass', radius = 'md', pad = 0, interactive = false, glow = false,
  className, style, children, ...rest
}: Div & {
  tone?: SurfaceTone
  radius?: 'xs' | 'sm' | 'md' | 'lg' | 'xl'
  pad?: number
  interactive?: boolean
  glow?: boolean
}) {
  return (
    <div
      {...rest}
      className={cx(tone === 'glass' && 'ss-glass', tone === 'solid' && 'ss-solid',
        interactive && 'ss-press ss-lift-hover', className)}
      style={{
        position: 'relative',
        borderRadius: `var(--ss-r-${radius})`,
        padding: pad ? `${pad}px` : undefined,
        cursor: interactive ? 'pointer' : undefined,
        ...(glow ? { boxShadow: `var(--ss-e3), var(--ss-lift), 0 0 34px -10px var(--ss-brand-glow)` } : null),
        ...style,
      }}
    >
      {children}
    </div>
  )
}

/* ────────────────────────────────  Button  ──────────────────────────────── */

export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'action' | 'danger'
export type ButtonSize = 'sm' | 'md' | 'lg'

const SIZES: Record<ButtonSize, { h: number; px: number; fs: number }> = {
  sm: { h: 36, px: 14, fs: 13 },
  md: { h: 46, px: 20, fs: 14.5 },
  lg: { h: 54, px: 26, fs: 16 },
}

/**
 * Кнопка. `glow` добавляет мягкое свечение бренда, `loading` блокирует
 * повторное нажатие и показывает кольцо вместо иконки.
 */
export function Button({
  variant = 'primary', size = 'md', icon, iconRight, glow = false,
  loading = false, block = false, disabled, className, style, children, ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: ButtonVariant
  size?: ButtonSize
  icon?: React.ReactNode
  iconRight?: React.ReactNode
  glow?: boolean
  loading?: boolean
  block?: boolean
}) {
  const s = SIZES[size]
  const off = disabled || loading

  const skin: Record<ButtonVariant, React.CSSProperties> = {
    primary: {
      background: 'linear-gradient(180deg, var(--ss-brand-hi), var(--ss-brand) 46%, var(--ss-brand-lo))',
      color: '#fff',
      border: '1px solid var(--ss-brand-edge)',
      boxShadow: glow
        ? 'var(--ss-e2), inset 0 1px 0 rgba(255,255,255,0.28), 0 0 30px -8px var(--ss-brand-glow)'
        : 'var(--ss-e2), inset 0 1px 0 rgba(255,255,255,0.28)',
    },
    secondary: {
      background: 'var(--ss-blue-wash)',
      color: 'var(--ss-blue-ink)',
      border: '1px solid var(--ss-blue-edge)',
      boxShadow: 'var(--ss-e1), var(--ss-lift)',
      backdropFilter: 'blur(var(--ss-blur))',
    },
    ghost: {
      background: 'transparent',
      color: 'var(--ss-ink-2)',
      border: '1px solid transparent',
    },
    action: {
      background: 'var(--ss-blue-wash)',
      color: 'var(--ss-blue-ink)',
      border: '1px solid var(--ss-blue-edge)',
    },
    danger: {
      background: 'var(--ss-bad-wash)',
      color: 'var(--ss-bad)',
      border: '1px solid rgba(240,82,79,0.34)',
    },
  }

  return (
    <button
      {...rest}
      disabled={off}
      className={cx('ss-press', className)}
      style={{
        position: 'relative', overflow: 'hidden',
        display: block ? 'flex' : 'inline-flex',
        width: block ? '100%' : undefined,
        alignItems: 'center', justifyContent: 'center', gap: 9,
        height: s.h, padding: `0 ${s.px}px`,
        borderRadius: 'var(--ss-r-sm)',
        fontSize: s.fs, fontWeight: 650, letterSpacing: '0.01em',
        fontFamily: 'inherit', lineHeight: 1,
        cursor: off ? 'not-allowed' : 'pointer',
        opacity: off ? 0.45 : 1,
        ...skin[variant],
        ...style,
      }}
    >
      {variant === 'primary' && !off && (
        <span
          aria-hidden
          style={{
            position: 'absolute', inset: 0, pointerEvents: 'none',
            background: 'linear-gradient(105deg, transparent, rgba(255,255,255,0.30), transparent)',
            width: '38%', animation: 'ss-sheen 3.4s var(--ss-ease-soft) 1.2s infinite',
          }}
        />
      )}
      {loading ? <Spinner size={size === 'lg' ? 18 : 15} /> : icon}
      {children != null && <span style={{ position: 'relative' }}>{children}</span>}
      {!loading && iconRight}
    </button>
  )
}

/** Круглая кнопка-иконка. */
export function IconButton({
  icon, size = 40, tone = 'glass', className, style, ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  icon: React.ReactNode
  size?: number
  tone?: 'glass' | 'brand' | 'bare'
}) {
  const skin =
    tone === 'brand'
      ? { background: 'var(--ss-brand-wash)', border: '1px solid var(--ss-brand-edge)', color: 'var(--ss-brand-ink)' }
      : tone === 'bare'
      ? { background: 'transparent', border: '1px solid transparent', color: 'var(--ss-ink-2)' }
      : { background: 'var(--ss-glass-2)', border: '1px solid var(--ss-hairline)', color: 'var(--ss-blue-ink)' }

  return (
    <button
      {...rest}
      className={cx('ss-press', className)}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        width: size, height: size, borderRadius: 'var(--ss-r-pill)',
        cursor: 'pointer', flexShrink: 0, ...skin, ...style,
      }}
    >
      {icon}
    </button>
  )
}

/* ─────────────────────────────  Badge / Chip  ───────────────────────────── */

export type Tone = 'brand' | 'ok' | 'warn' | 'bad' | 'neutral'

const TONE: Record<Tone, { fg: string; bg: string; edge: string }> = {
  brand:   { fg: 'var(--ss-blue-ink)', bg: 'var(--ss-blue-wash)', edge: 'var(--ss-blue-edge)' },
  ok:      { fg: 'var(--ss-ok)',        bg: 'var(--ss-ok-wash)',    edge: 'rgba(52,211,153,0.30)' },
  warn:    { fg: 'var(--ss-warn)',      bg: 'var(--ss-warn-wash)',  edge: 'rgba(245,158,11,0.30)' },
  bad:     { fg: 'var(--ss-bad)',       bg: 'var(--ss-bad-wash)',   edge: 'rgba(240,82,79,0.30)' },
  neutral: { fg: 'var(--ss-ink-2)',     bg: 'var(--ss-glass-2)',    edge: 'var(--ss-hairline)' },
}

/** Компактный статус-бейдж. */
export function Badge({
  tone = 'neutral', dot = false, children, style, ...rest
}: React.HTMLAttributes<HTMLSpanElement> & { tone?: Tone; dot?: boolean }) {
  const t = TONE[tone]
  return (
    <span
      {...rest}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        padding: '4px 10px', borderRadius: 'var(--ss-r-pill)',
        background: t.bg, border: `1px solid ${t.edge}`, color: t.fg,
        fontSize: 11.5, fontWeight: 650, letterSpacing: '0.02em', whiteSpace: 'nowrap',
        ...style,
      }}
    >
      {dot && <span style={{ width: 5, height: 5, borderRadius: '50%', background: t.fg, flexShrink: 0 }} />}
      {children}
    </span>
  )
}

/** Выбираемый чип (фильтр, тег, вариация). */
export function Chip({
  active = false, icon, count, children, style, ...rest
}: React.HTMLAttributes<HTMLButtonElement> & {
  active?: boolean
  icon?: React.ReactNode
  count?: number | string
}) {
  return (
    <button
      {...(rest as React.ButtonHTMLAttributes<HTMLButtonElement>)}
      className="ss-press"
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 7,
        padding: '9px 15px', borderRadius: 'var(--ss-r-pill)',
        fontSize: 13.5, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer',
        whiteSpace: 'nowrap',
        color: active ? 'var(--ss-ink)' : 'var(--ss-ink-3)',
        background: active ? 'var(--ss-blue-wash)' : 'var(--ss-glass-1)',
        border: `1px solid ${active ? 'var(--ss-blue-edge)' : 'var(--ss-hairline-lo)'}`,
        boxShadow: active ? '0 0 22px -10px var(--ss-blue-glow)' : undefined,
        ...style,
      }}
    >
      {icon}
      {children}
      {count != null && (
        <span style={{ fontSize: 11.5, fontWeight: 700, color: active ? 'var(--ss-blue-ink)' : 'var(--ss-ink-4)' }}>
          {count}
        </span>
      )}
    </button>
  )
}

/* ──────────────────────────────  Индикаторы  ────────────────────────────── */

/** Кольцо загрузки. */
export function Spinner({ size = 18, width = 2 }: { size?: number; width?: number }) {
  return (
    <span
      aria-hidden
      style={{
        width: size, height: size, borderRadius: '50%', display: 'inline-block', flexShrink: 0,
        border: `${width}px solid rgba(255,255,255,0.18)`,
        borderTopColor: 'currentColor',
        animation: 'ss-ring-spin 0.75s linear infinite',
      }}
    />
  )
}

/** Кольцевой прогресс с подписью в центре. */
export function ProgressRing({
  value, size = 68, width = 5, tone = 'brand', label,
}: { value: number; size?: number; width?: number; tone?: Tone; label?: React.ReactNode }) {
  const pct = Math.max(0, Math.min(100, value))
  const r = (size - width) / 2
  const c = 2 * Math.PI * r
  const fg = TONE[tone].fg
  return (
    <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--ss-hairline)" strokeWidth={width} />
        <circle
          cx={size / 2} cy={size / 2} r={r} fill="none" stroke={fg} strokeWidth={width}
          strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c - (c * pct) / 100}
          style={{ transition: 'stroke-dashoffset var(--ss-t-slow) var(--ss-ease-out)',
                   filter: `drop-shadow(0 0 6px ${fg})` }}
        />
      </svg>
      <div style={{
        position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: size * 0.24, fontWeight: 700, color: 'var(--ss-ink)',
      }}>
        {label ?? `${Math.round(pct)}%`}
      </div>
    </div>
  )
}

/** Линейный прогресс. */
export function ProgressBar({
  value, tone = 'brand', height = 6,
}: { value: number; tone?: Tone; height?: number }) {
  const pct = Math.max(0, Math.min(100, value))
  return (
    <div style={{ height, borderRadius: 'var(--ss-r-pill)', background: 'var(--ss-glass-2)', overflow: 'hidden' }}>
      <div style={{
        width: `${pct}%`, height: '100%', borderRadius: 'inherit',
        background: TONE[tone].fg, boxShadow: `0 0 10px -2px ${TONE[tone].fg}`,
        transition: 'width var(--ss-t-slow) var(--ss-ease-out)',
      }} />
    </div>
  )
}

/** Спарклайн для KPI-плиток. */
export function Sparkline({
  data, width = 120, height = 34, tone = 'brand',
}: { data: number[]; width?: number; height?: number; tone?: Tone }) {
  if (data.length < 2) return null
  const min = Math.min(...data)
  const max = Math.max(...data)
  const span = max - min || 1
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * width
    const y = height - 2 - ((v - min) / span) * (height - 4)
    return `${x.toFixed(1)},${y.toFixed(1)}`
  })
  const fg = TONE[tone].fg
  const id = `ss-spark-${tone}`
  return (
    <svg width={width} height={height} style={{ display: 'block', overflow: 'visible' }}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={fg} stopOpacity="0.30" />
          <stop offset="100%" stopColor={fg} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={`0,${height} ${pts.join(' ')} ${width},${height}`} fill={`url(#${id})`} />
      <polyline
        points={pts.join(' ')} fill="none" stroke={fg} strokeWidth="1.7"
        strokeLinecap="round" strokeLinejoin="round"
        style={{ filter: `drop-shadow(0 0 4px ${fg})` }}
      />
    </svg>
  )
}
