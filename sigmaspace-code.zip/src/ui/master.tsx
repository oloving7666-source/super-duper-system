import { useEffect, useRef, useState } from 'react'
import { Icon, type IconName } from '../shared'

/**
 * Вход в панель мастера: удержание центральной кнопки Σ.
 * Пока палец на кнопке — экран притухает, вокруг Σ заполняется кольцо,
 * сверху появляется подсказка. По заполнению кольца проигрывается
 * переход «Sigma Master» и открывается CRM.
 */

const HOLD_MS = 750

export function useSigmaHold(enabled: boolean, onHold: () => void) {
  const [progress, setProgress] = useState(0)
  const raf = useRef(0)
  const start = useRef(0)
  const fired = useRef(false)

  const stop = () => {
    cancelAnimationFrame(raf.current)
    setProgress(0)
    fired.current = false
  }

  const begin = () => {
    if (!enabled) return
    start.current = performance.now()
    fired.current = false
    const tick = () => {
      const p = Math.min(1, (performance.now() - start.current) / HOLD_MS)
      setProgress(p)
      if (p >= 1) {
        if (!fired.current) {
          fired.current = true
          try { navigator.vibrate?.(18) } catch { /* нет вибро — не страшно */ }
          onHold()
        }
        setProgress(0)
        return
      }
      raf.current = requestAnimationFrame(tick)
    }
    raf.current = requestAnimationFrame(tick)
  }

  useEffect(() => () => cancelAnimationFrame(raf.current), [])

  return {
    progress,
    /** true, если удержание уже засчитано — тап по кнопке не должен сработать */
    consumed: () => fired.current,
    handlers: {
      onPointerDown: begin,
      onPointerUp: stop,
      onPointerLeave: stop,
      onPointerCancel: stop,
      onContextMenu: (e: React.MouseEvent) => e.preventDefault(),
    },
  }
}

/** Подсказка поверх экрана, пока идёт удержание. */
export function MasterHint({ progress }: { progress: number }) {
  if (progress <= 0) return null
  return (
    <div style={{
      // Затемняем и замыливаем всё, КРОМЕ нижней панели — она остаётся чёткой.
      position: 'absolute', top: 0, left: 0, right: 0,
      bottom: 'calc(52px + max(8px, env(safe-area-inset-bottom)))',
      zIndex: 60, pointerEvents: 'none',
      background: `linear-gradient(180deg, rgba(3,3,8,${0.5 + progress * 0.4}) 0%, rgba(3,3,8,${0.68 + progress * 0.3}) 62%, rgba(3,3,8,${0.82 + progress * 0.16}) 100%)`,
      backdropFilter: `blur(${progress * 2.6}px)`, WebkitBackdropFilter: `blur(${progress * 2.6}px)`,
      transition: 'background 90ms linear',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-end',
      paddingBottom: 'calc(112px + env(safe-area-inset-bottom))',
    }}>
      <p style={{ margin: 0, color: '#fff', fontSize: 16.5, fontWeight: 650, letterSpacing: '0.01em', textShadow: '0 2px 18px rgba(0,0,0,0.9)' }}>
        Удерживайте кнопку
      </p>
      <p style={{ margin: '5px 0 0', color: 'var(--ss-brand-ink)', fontSize: 13.5 }}>
        для доступа к панели мастера
      </p>
      <svg viewBox="0 0 24 26" width="26" height="28" style={{ marginTop: 12, opacity: 0.5 + progress * 0.5 }} aria-hidden>
        <path d="M5 6l7 7 7-7M5 14l7 7 7-7" fill="none" stroke="var(--ss-brand-hi)" strokeWidth="2"
              strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </div>
  )
}

/** Кольцо прогресса удержания вокруг центральной кнопки. */
export function HoldRing({ progress, size = 54 }: { progress: number; size?: number }) {
  if (progress <= 0) return null
  const r = size / 2 - 2
  const c = 2 * Math.PI * r
  return (
    <svg viewBox={`0 0 ${size} ${size}`} aria-hidden
         style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', display: 'block', transform: 'rotate(-90deg)', transformOrigin: '50% 50%' }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--ss-brand-hi)" strokeWidth="2.4"
              strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - progress)}
              style={{ filter: 'drop-shadow(0 0 6px var(--ss-brand-glow))' }} />
    </svg>
  )
}

/**
 * Пошаговый онбординг-тур при первом входе (клиент и админ).
 * Размытый фон затемняет всё над нижней панелью, но у самой кромки плавно
 * растворяется — резкой линии над панелью больше нет. Яркое сине-фиолетовое
 * кольцо и прыгающая стрелка «свисают» вниз и указывают прямо на нужную кнопку
 * навигации. Шаги ведут по Σ, Каталогу, Профилю, Заказам и Настройкам; для
 * админа добавляется шаг про удержание Σ. Один раз на аккаунт, повторно — из
 * Настроек.
 *
 * `x` — доля ширины (центр колонки нижней панели из пяти равных ячеек):
 * Каталог 0.1, Профиль 0.3, Σ 0.5, Заказы 0.7, Настройки 0.9.
 */
type OnboardStep = { kind: 'center' | 'sigma' | 'tab'; x?: number; icon: IconName; eyebrow: string; title: string; text: string }
const ONBOARD_STEPS: OnboardStep[] = [
  { kind: 'center', icon: 'planet', eyebrow: 'Добро пожаловать', title: 'Sigma Space', text: 'Коллекционные фигурки и мерч ограниченного тиража. Покажем, что где находится — 20 секунд.' },
  { kind: 'sigma', x: 0.5, icon: 'planet', eyebrow: 'Кнопка Σ', title: 'Главный экран', text: 'Тап по Σ в любой момент — возврат на главную: баннеры, новинки и коллекции.' },
  { kind: 'tab', x: 0.1, icon: 'grid', eyebrow: 'Каталог', title: 'Находите своё', text: 'Разделы, поиск, фильтры по цене и хештеги. Бейдж NEW — свежие поступления.' },
  { kind: 'tab', x: 0.3, icon: 'person', eyebrow: 'Профиль', title: 'Ваш космопорт', text: 'Избранное ♥, бонусы Sigma Club, промокоды и отзывы с фото.' },
  { kind: 'tab', x: 0.7, icon: 'document', eyebrow: 'Заказы', title: 'Всё под контролем', text: 'Статусы и трек-номера заказов. Оплата картой, СБП, криптой или скинами.' },
  { kind: 'tab', x: 0.9, icon: 'gear', eyebrow: 'Настройки', title: 'Под себя', text: 'Тема, уведомления и повтор этой экскурсии в любой момент.' },
]
// Дополнительный шаг только для админа: удержание Σ открывает панель мастера.
const ADMIN_STEP: OnboardStep = { kind: 'sigma', x: 0.5, icon: 'gear', eyebrow: 'И для админа', title: 'Панель мастера', text: 'Зажмите и удерживайте Σ, чтобы открыть панель управления магазином.' }

export function SigmaOnboarding({ onClose, isAdmin = false }: { onClose: () => void; isAdmin?: boolean }) {
  const steps = isAdmin ? [...ONBOARD_STEPS, ADMIN_STEP] : ONBOARD_STEPS
  const [step, setStep] = useState(0)
  const last = step === steps.length - 1
  const s = steps[step]
  const next = () => { if (last) onClose(); else setStep(v => v + 1) }
  const targeted = s.kind !== 'center'
  const xPct = `${(s.x ?? 0.5) * 100}%`
  // Геометрия кольца-подсветки: центр ≈ 18px ниже кромки оверлея (там иконка).
  const haloSize = s.kind === 'sigma' ? 78 : 48
  const haloBottom = -(18 + haloSize / 2)
  // Оверлей ограничен рамкой приложения и НЕ закрывает нижнюю панель. Тёмный
  // размытый фон вынесен в отдельный слой с маской: у нижней кромки он плавно
  // тает, поэтому резкой линии над панелью нет. Кольцо и стрелка — отдельные
  // дети, они свободно свисают вниз и указывают на нужную кнопку.
  return (
    <div className="overlay-fade" role="dialog" aria-modal="true" onClick={next}
      style={{
        position: 'absolute', top: 0, left: 0, right: 0,
        bottom: 'calc(54px + env(safe-area-inset-bottom, 0px))',
        zIndex: 360, cursor: 'pointer',
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: targeted ? 'flex-end' : 'center',
        padding: targeted ? '0 18px 118px' : '20px',
      }}>
      {/* Тёмный размытый фон 50/50 сине-фиолетовый, тающий у нижней кромки */}
      <div aria-hidden style={{
        position: 'absolute', inset: 0, zIndex: 0, pointerEvents: 'none',
        background: targeted
          ? `radial-gradient(150px 130px at ${xPct} 100%, rgba(124,58,237,0.20), transparent 70%), radial-gradient(180px 150px at ${xPct} 100%, rgba(79,141,255,0.16), transparent 76%), rgba(5,6,14,0.66)`
          : 'radial-gradient(110% 68% at 30% 32%, rgba(124,58,237,0.20), transparent 62%), radial-gradient(110% 68% at 72% 60%, rgba(79,141,255,0.18), transparent 62%), rgba(5,6,14,0.66)',
        backdropFilter: 'blur(6px)', WebkitBackdropFilter: 'blur(6px)',
        WebkitMaskImage: 'linear-gradient(to bottom, #000 calc(100% - 26px), transparent)',
        maskImage: 'linear-gradient(to bottom, #000 calc(100% - 26px), transparent)',
      }} />

      {/* Пропустить */}
      <button onClick={e => { e.stopPropagation(); onClose() }} aria-label="Пропустить обучение"
        style={{ position: 'absolute', top: 'max(12px, env(safe-area-inset-top))', right: 16, zIndex: 4, background: 'none', border: 'none', color: 'var(--ss-ink-3, #7a7095)', fontSize: 12.5, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>Пропустить</button>

      {/* Кольцо-подсветка на самой кнопке навигации (свисает ниже кромки) */}
      {targeted && (
        <div aria-hidden style={{
          position: 'absolute', left: xPct, bottom: haloBottom,
          width: haloSize, height: haloSize, marginLeft: -haloSize / 2, zIndex: 2, pointerEvents: 'none',
        }}>
          {/* пульсирующее кольцо (синее) */}
          <span className="ss-coach-halo" style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: '2px solid var(--ss-blue-hi, #4f8dff)' }} />
          {/* яркое статичное кольцо с сине-фиолетовым градиентом — всегда видно */}
          <svg viewBox="0 0 100 100" width={haloSize} height={haloSize} style={{ position: 'absolute', inset: 0, display: 'block' }}>
            <defs>
              <linearGradient id="ob-ring" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="var(--ss-brand-hi, #a855f7)" />
                <stop offset="100%" stopColor="var(--ss-blue-hi, #4f8dff)" />
              </linearGradient>
            </defs>
            <circle cx="50" cy="50" r="47" fill="none" stroke="url(#ob-ring)" strokeWidth="3.6"
              style={{ filter: 'drop-shadow(0 0 9px rgba(124,58,237,0.75)) drop-shadow(0 0 7px rgba(79,141,255,0.65))' }} />
          </svg>
        </div>
      )}
      {/* Прыгающая стрелка над кнопкой */}
      {targeted && (
        <svg viewBox="0 0 26 46" width="24" height="42" aria-hidden className="ss-coach-arrow"
          style={{ position: 'absolute', left: xPct, marginLeft: -12, bottom: 32, zIndex: 2, pointerEvents: 'none' }}>
          <defs>
            <linearGradient id="ob-arrow" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--ss-blue-hi, #4f8dff)" />
              <stop offset="100%" stopColor="var(--ss-brand-hi, #a855f7)" />
            </linearGradient>
          </defs>
          <path d="M13 2v34M4 28l9 10 9-10" fill="none" stroke="url(#ob-arrow)" strokeWidth="2.6"
            strokeLinecap="round" strokeLinejoin="round" style={{ filter: 'drop-shadow(0 0 8px rgba(79,141,255,0.7))' }} />
        </svg>
      )}

      {/* Карточка-подсказка */}
      <div key={step} className="ss-fade" onClick={e => e.stopPropagation()} style={{
        position: 'relative', zIndex: 3, cursor: 'default', width: '100%', maxWidth: 320, boxSizing: 'border-box',
        display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center',
        padding: targeted ? '18px 20px 16px' : '26px 22px 20px', borderRadius: 20,
        background: 'linear-gradient(180deg, rgba(18,15,34,0.97), rgba(9,10,20,0.98))',
        border: '1px solid var(--ss-brand-edge)',
        boxShadow: '0 24px 60px -18px rgba(0,0,0,0.7), -14px 0 44px -22px var(--ss-brand-glow), 14px 0 44px -22px var(--ss-blue-glow), inset 0 1px 0 rgba(255,255,255,0.06)',
      }}>
        {/* иконка шага */}
        <div style={{ position: 'relative', width: targeted ? 56 : 92, height: targeted ? 56 : 92, display: 'grid', placeItems: 'center', marginBottom: targeted ? 12 : 18 }}>
          {(targeted ? [26] : [44, 34]).map((r, i) => (
            <svg key={r} viewBox="0 0 92 92" width={targeted ? 56 : 92} height={targeted ? 56 : 92} aria-hidden style={{ position: 'absolute', inset: 0, animation: `ss-ring-spin ${10 + i * 5}s linear infinite ${i % 2 ? 'reverse' : 'normal'}`, transformOrigin: '50% 50%', opacity: 0.5 + i * 0.2 }}>
              <circle cx="46" cy="46" r={r} fill="none" stroke={i % 2 ? 'var(--ss-blue-hi)' : 'var(--ss-brand-hi)'} strokeWidth={1.2} strokeDasharray={i % 2 ? '14 9' : '26 13'} strokeLinecap="round" style={{ filter: `drop-shadow(0 0 6px ${i % 2 ? 'var(--ss-blue-glow)' : 'var(--ss-brand-glow)'})` }} />
            </svg>
          ))}
          <div style={{ width: targeted ? 40 : 58, height: targeted ? 40 : 58, borderRadius: '50%', display: 'grid', placeItems: 'center', background: 'radial-gradient(circle at 50% 32%, #17182e, #05060a)', border: '1px solid var(--ss-blue-edge, var(--ss-brand-edge))', boxShadow: '0 0 22px -6px var(--ss-brand-glow), 0 0 22px -6px var(--ss-blue-glow)' }}>
            <Icon name={s.icon} size={targeted ? 20 : 26} color="var(--ss-blue-hi, #4f8dff)" />
          </div>
        </div>

        <p style={{ margin: '0 0 6px', fontSize: 10.5, fontWeight: 800, letterSpacing: '0.16em', textTransform: 'uppercase', color: 'transparent', backgroundImage: 'linear-gradient(90deg, var(--ss-brand-hi, #a855f7), var(--ss-blue-hi, #4f8dff))', WebkitBackgroundClip: 'text', backgroundClip: 'text' }}>{s.eyebrow}</p>
        <h2 style={{ margin: '0 0 8px', fontSize: targeted ? 18 : 21, fontWeight: 700, color: '#fff', lineHeight: 1.15, ...(s.kind === 'center' ? { fontFamily: '"Georgia","Times New Roman",serif' } : {}) }}>{s.title}</h2>
        <p style={{ margin: 0, fontSize: 12.5, lineHeight: 1.5, color: 'var(--ss-ink-2, #c8c2dd)' }}>{s.text}</p>

        {/* низ: точки + кнопка */}
        <div style={{ display: 'flex', gap: 6, margin: '15px 0 13px' }}>
          {steps.map((_, i) => (
            <span key={i} onClick={() => setStep(i)} style={{ width: i === step ? 20 : 6, height: 6, borderRadius: 3, cursor: 'pointer', background: i === step ? 'linear-gradient(90deg, var(--ss-brand-hi), var(--ss-blue-hi))' : 'rgba(255,255,255,0.16)', boxShadow: i === step ? '0 0 10px -2px var(--ss-blue-glow)' : undefined, transition: 'width 0.28s var(--ss-ease, ease)' }} />
          ))}
        </div>
        <button onClick={next} className="ss-press" style={{ width: '100%', height: 44, borderRadius: 13, border: '1px solid var(--ss-brand-edge)', cursor: 'pointer', fontFamily: 'inherit', fontSize: 14, fontWeight: 700, color: '#fff', background: 'linear-gradient(90deg, var(--ss-brand-hi, #a855f7), var(--ss-blue-hi, #4f8dff))', boxShadow: '0 10px 26px -8px var(--ss-blue-glow), inset 0 1px 0 rgba(255,255,255,0.18)' }}>
          {last ? 'Начать' : 'Далее'}
        </button>
      </div>
    </div>
  )
}

/** Полноэкранный переход «Sigma Master» перед открытием CRM. */
export function MasterTransition({ onDone }: { onDone: () => void }) {
  const [pct, setPct] = useState(0)
  const [phase, setPhase] = useState<'load' | 'done'>('load')

  useEffect(() => {
    const t0 = performance.now()
    let raf = 0
    const tick = () => {
      const p = Math.min(100, ((performance.now() - t0) / 1100) * 100)
      setPct(p)
      if (p >= 100) { setPhase('done'); return }
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [])

  useEffect(() => {
    if (phase !== 'done') return
    const t = setTimeout(onDone, 620)
    return () => clearTimeout(t)
  }, [phase, onDone])

  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 400, background: '#05060a',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 0,
      overflow: 'hidden',
    }}>
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage:
          'radial-gradient(58% 34% at 50% 42%, rgba(124,58,237,0.20) 0%, transparent 70%),' +
          'radial-gradient(90% 50% at 50% 100%, rgba(96,132,255,0.08) 0%, transparent 72%)',
      }} />

      <div style={{ position: 'relative', width: 232, height: 232, display: 'grid', placeItems: 'center' }}>
        {[112, 96, 80, 64].map((r, i) => (
          <svg key={r} viewBox="0 0 232 232" width={232} height={232} aria-hidden
               style={{
                 position: 'absolute', inset: 0,
                 animation: `ss-ring-spin ${9 + i * 4}s linear infinite ${i % 2 ? 'reverse' : 'normal'}`,
                 transformOrigin: '50% 50%', opacity: 0.34 + i * 0.16,
               }}>
            <circle cx="116" cy="116" r={r} fill="none"
                    stroke={i % 2 ? 'var(--ss-blue-hi)' : 'var(--ss-brand-hi)'}
                    strokeWidth={i === 3 ? 2 : 1.1}
                    strokeDasharray={i === 3 ? '52 26' : `${6 + i * 9} ${5 + i * 4}`}
                    strokeLinecap="round"
                    style={{ filter: `drop-shadow(0 0 8px ${i % 2 ? 'var(--ss-blue-glow)' : 'var(--ss-brand-glow)'})` }} />
          </svg>
        ))}
        <span style={{
          position: 'relative', color: '#c9a6ff', fontSize: 86, fontWeight: 400, lineHeight: 1,
          fontFamily: '"Georgia","Times New Roman",serif',
          textShadow: '0 0 26px rgba(168,85,247,0.65), 0 0 60px rgba(124,58,237,0.45)',
        }}>Σ</span>
      </div>

      <p style={{ position: 'relative', margin: '22px 0 0', color: '#fff', fontSize: 25, fontWeight: 600 }}>
        Sigma Master
      </p>

      {phase === 'load' ? (
        <>
          <p style={{ position: 'relative', margin: '8px 0 22px', color: 'var(--ss-ink-3, #7a7095)', fontSize: 14 }}>
            Переключение режима…
          </p>
          <div style={{ position: 'relative', width: 232, height: 4, borderRadius: 2, background: 'rgba(124,58,237,0.16)', overflow: 'hidden' }}>
            <div style={{
              width: `${pct}%`, height: '100%', borderRadius: 2,
              background: 'linear-gradient(90deg, var(--ss-brand-hi), var(--ss-blue-hi))',
              boxShadow: '0 0 14px var(--ss-blue-glow)',
            }} />
          </div>
          <p style={{ position: 'relative', margin: '10px 0 0', color: '#5f5a78', fontSize: 12 }}>
            Подготовка панели управления
          </p>
        </>
      ) : (
        <>
          <p style={{ position: 'relative', margin: '8px 0 24px', color: '#c8c2dd', fontSize: 14 }}>
            Переход в панель управления
          </p>
          <div className="ss-fade" style={{
            position: 'relative', width: 52, height: 52, borderRadius: '50%',
            border: '1.5px solid var(--ss-brand-hi)', display: 'grid', placeItems: 'center',
            boxShadow: '0 0 24px -4px var(--ss-brand-glow)',
          }}>
            <svg viewBox="0 0 24 24" width="24" height="24" aria-hidden>
              <path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="var(--ss-brand-hi)" strokeWidth="2"
                    strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        </>
      )}
    </div>
  )
}
