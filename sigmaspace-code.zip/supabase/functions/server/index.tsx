import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

const PREFIX = "/make-server-dee2fafb";

// ─────────────────────────────────────────────────────────────────────────
// Устойчивость к нагрузке и DDoS
// ─────────────────────────────────────────────────────────────────────────

// Любой внешний вызов (платёжки, Telegram) оборачиваем таймаутом. Без него
// зависший апстрим держит воркер занятым и при наплыве быстро исчерпывает
// пул — сервер «висит». AbortController гарантирует освобождение ресурса.
async function fetchWithTimeout(url: string, init: RequestInit = {}, ms = 8000): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

// Простой in-memory лимитер по IP (фиксированное окно). Живёт в памяти воркера —
// не требует БД и мгновенно отсекает флуд/DDoS до того, как запрос дойдёт до
// Postgres или платёжки. Вебхуки платёжек и health не лимитируем.
const RL_WINDOW_MS = 10_000; // окно 10 сек
const RL_MAX = 60;           // не более 60 запросов с одного IP за окно
const rlHits = new Map<string, { count: number; reset: number }>();

function rateLimited(ip: string): boolean {
  const now = Date.now();
  const cur = rlHits.get(ip);
  if (!cur || now > cur.reset) {
    rlHits.set(ip, { count: 1, reset: now + RL_WINDOW_MS });
    return false;
  }
  cur.count++;
  return cur.count > RL_MAX;
}

// Периодически чистим устаревшие записи, чтобы карта не росла бесконечно
// (иначе сама по себе стала бы вектором исчерпания памяти при DDoS).
setInterval(() => {
  const now = Date.now();
  for (const [ip, v] of rlHits) if (now > v.reset) rlHits.delete(ip);
}, 30_000);

const clientIp = (c: any): string =>
  (c.req.header("x-forwarded-for")?.split(",")[0].trim()) ||
  c.req.header("x-real-ip") || "unknown";

app.use(`${PREFIX}/*`, async (c, next) => {
  const path = c.req.path;
  // Вебхуки приходят от платёжных систем (свои IP, подтверждены подписью/данными)
  // и health-check — их не режем, чтобы не терять уведомления об оплате.
  if (path.includes("/payments/webhook/") || path.endsWith("/health")) return next();

  if (rateLimited(clientIp(c))) {
    return c.json({ error: "слишком много запросов, попробуйте чуть позже" }, 429);
  }

  // Отсекаем неадекватно большие тела до парсинга (защита памяти от «толстых» атак).
  const len = Number(c.req.header("content-length") || 0);
  if (len > 1_000_000) return c.json({ error: "тело запроса слишком большое" }, 413);

  return next();
});

// Единый обработчик ошибок: любое необработанное исключение отдаёт 500, а не
// роняет воркер — один «плохой» запрос при наплыве не должен убивать инстанс.
app.onError((err, c) => {
  console.log("unhandled error:", err);
  return c.json({ error: "внутренняя ошибка сервера" }, 500);
});

// Health check endpoint
app.get(`${PREFIX}/health`, (c) => {
  return c.json({ status: "ok" });
});

// ─────────────────────────────────────────────────────────────────────────
// Payments
// Секретные ключи читаются ТОЛЬКО здесь, на сервере (Deno.env), и никогда
// не попадают в браузер. Ключи задаются в Make → Settings → Secrets.
// ─────────────────────────────────────────────────────────────────────────

type Provider = "card" | "yookassa" | "tinkoff" | "skins";
type PayStatus = "pending" | "paid" | "failed";

interface PaymentRecord {
  orderId: string;
  provider: Provider;
  status: PayStatus;
  amount: number; // рубли
  providerPaymentId?: string;
  confirmationUrl?: string;
  createdAt: number;
  updatedAt: number;
}

const payKey = (orderId: string) => `payment:${orderId}`;

async function sha256Hex(input: string): Promise<string> {
  const data = new TextEncoder().encode(input);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function b64(input: string): string {
  return btoa(input);
}

// ── ЮKassa ────────────────────────────────────────────────────────────────
async function createYookassa(rec: PaymentRecord, description: string, returnUrl: string) {
  const shopId = Deno.env.get("YOOKASSA_SHOP_ID");
  const secret = Deno.env.get("YOOKASSA_SECRET_KEY");
  if (!shopId || !secret) throw new Error("ЮKassa не настроена: добавьте YOOKASSA_SHOP_ID и YOOKASSA_SECRET_KEY");
  const res = await fetchWithTimeout("https://api.yookassa.ru/v3/payments", {
    method: "POST",
    headers: {
      Authorization: `Basic ${b64(`${shopId}:${secret}`)}`,
      "Idempotence-Key": `${rec.orderId}-${rec.createdAt}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      amount: { value: rec.amount.toFixed(2), currency: "RUB" },
      capture: true,
      confirmation: { type: "redirect", return_url: returnUrl },
      description,
      metadata: { orderId: rec.orderId },
    }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(`ЮKassa: ${data.description || res.status}`);
  rec.providerPaymentId = data.id;
  rec.confirmationUrl = data.confirmation?.confirmation_url;
}

async function yookassaWebhook(body: any): Promise<{ orderId?: string; status?: PayStatus }> {
  const obj = body?.object;
  const orderId = obj?.metadata?.orderId;
  if (!orderId) return {};
  if (body?.event === "payment.succeeded" || obj?.status === "succeeded") return { orderId, status: "paid" };
  if (body?.event === "payment.canceled" || obj?.status === "canceled") return { orderId, status: "failed" };
  return { orderId };
}

// ── Тинькофф ──────────────────────────────────────────────────────────────
async function tinkoffToken(params: Record<string, string | number>, password: string): Promise<string> {
  // Токен = SHA256 от значений (включая Password), отсортированных по ключу.
  const withPass: Record<string, string | number> = { ...params, Password: password };
  const concat = Object.keys(withPass).sort().map((k) => String(withPass[k])).join("");
  return (await sha256Hex(concat)).toUpperCase();
}

async function createTinkoff(rec: PaymentRecord, description: string, returnUrl: string, notifyUrl: string) {
  const terminalKey = Deno.env.get("TINKOFF_TERMINAL_KEY");
  const password = Deno.env.get("TINKOFF_PASSWORD");
  if (!terminalKey || !password) throw new Error("Тинькофф не настроен: добавьте TINKOFF_TERMINAL_KEY и TINKOFF_PASSWORD");
  const base = {
    TerminalKey: terminalKey,
    Amount: Math.round(rec.amount * 100), // копейки
    OrderId: rec.orderId,
    Description: description.slice(0, 250),
  };
  const Token = await tinkoffToken(base, password);
  const res = await fetchWithTimeout("https://securepay.tinkoff.ru/v2/Init", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...base, Token, SuccessURL: returnUrl, FailURL: returnUrl, NotificationURL: notifyUrl }),
  });
  const data = await res.json();
  if (!data.Success) throw new Error(`Тинькофф: ${data.Message || data.Details || "ошибка Init"}`);
  rec.providerPaymentId = String(data.PaymentId);
  rec.confirmationUrl = data.PaymentURL;
}

function tinkoffWebhook(body: any): { orderId?: string; status?: PayStatus } {
  const orderId = body?.OrderId;
  if (!orderId) return {};
  if (body?.Status === "CONFIRMED" || body?.Status === "AUTHORIZED") return { orderId, status: "paid" };
  if (body?.Status === "REJECTED" || body?.Status === "CANCELED") return { orderId, status: "failed" };
  return { orderId };
}

// ── Скины (skinsback-совместимо) ────────────────────────────────────────────
async function skinsSign(params: Record<string, string | number>, apiKey: string): Promise<string> {
  // Подпись: HMAC-SHA256 по строке "key:value|key:value" (сортировка по ключу).
  const str = Object.keys(params).sort().map((k) => `${k}:${params[k]}`).join("|");
  const key = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(apiKey), { name: "HMAC", hash: "SHA-256" }, false, ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(str));
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function createSkins(rec: PaymentRecord, returnUrl: string) {
  const merchantId = Deno.env.get("SKINS_MERCHANT_ID");
  const apiKey = Deno.env.get("SKINS_API_KEY");
  if (!merchantId || !apiKey) throw new Error("Скины не настроены: добавьте SKINS_MERCHANT_ID и SKINS_API_KEY");
  const params: Record<string, string | number> = {
    method: "create_order",
    shop_id: merchantId,
    order_id: rec.orderId,
    amount: rec.amount.toFixed(2),
    currency: "RUB",
    success_url: returnUrl,
  };
  const sign = await skinsSign(params, apiKey);
  const res = await fetchWithTimeout("https://skinsback.com/api.php", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ ...(params as Record<string, string>), sign }),
  });
  const data = await res.json().catch(() => ({}));
  if (data.status !== "success" && !data.url) throw new Error(`Скины: ${data.message || "ошибка создания оплаты"}`);
  rec.providerPaymentId = String(data.order_id || data.id || rec.orderId);
  rec.confirmationUrl = data.url || data.link;
}

function skinsWebhook(body: any): { orderId?: string; status?: PayStatus } {
  const orderId = body?.order_id;
  if (!orderId) return {};
  const st = String(body?.status || "").toLowerCase();
  if (st === "success" || st === "paid" || st === "complete") return { orderId, status: "paid" };
  if (st === "fail" || st === "failed" || st === "canceled") return { orderId, status: "failed" };
  return { orderId };
}

// ── Роуты ───────────────────────────────────────────────────────────────────
app.post(`${PREFIX}/payments/create`, async (c) => {
  try {
    const { provider, orderId, amount, description, returnUrl } = await c.req.json();
    if (!provider || !orderId || !amount) return c.json({ error: "provider, orderId и amount обязательны" }, 400);

    // «Карта» — единый способ оплаты для клиента: сервер сам выбирает
    // подключённого эквайера по наличию секретов (ЮKassa приоритетнее).
    const resolved: Provider = provider === "card"
      ? (Deno.env.get("YOOKASSA_SHOP_ID") && Deno.env.get("YOOKASSA_SECRET_KEY") ? "yookassa" : "tinkoff")
      : provider;

    const origin = new URL(c.req.url).origin;
    const notifyUrl = `${origin}${PREFIX}/payments/webhook/${resolved}`;
    const now = Date.now();
    const rec: PaymentRecord = { orderId: String(orderId), provider: resolved, status: "pending", amount: Number(amount), createdAt: now, updatedAt: now };

    if (resolved === "yookassa") await createYookassa(rec, description || `Заказ ${orderId}`, returnUrl || origin);
    else if (resolved === "tinkoff") await createTinkoff(rec, description || `Заказ ${orderId}`, returnUrl || origin, notifyUrl);
    else if (resolved === "skins") await createSkins(rec, returnUrl || origin);
    else return c.json({ error: "неизвестный способ оплаты" }, 400);

    await kv.set(payKey(rec.orderId), rec);
    if (!rec.confirmationUrl) return c.json({ error: "платёжка не вернула ссылку на оплату" }, 502);
    return c.json({ orderId: rec.orderId, confirmationUrl: rec.confirmationUrl, status: rec.status });
  } catch (e) {
    console.log("payments/create error:", e);
    return c.json({ error: (e as Error).message || "ошибка создания платежа" }, 500);
  }
});

app.get(`${PREFIX}/payments/status/:orderId`, async (c) => {
  const rec = (await kv.get(payKey(c.req.param("orderId")))) as PaymentRecord | null;
  if (!rec) return c.json({ status: "unknown" });
  return c.json({ status: rec.status, provider: rec.provider });
});

// Универсальный обработчик webhook от платёжек
app.post(`${PREFIX}/payments/webhook/:provider`, async (c) => {
  const provider = c.req.param("provider") as Provider;
  let body: any = {};
  try { body = await c.req.json(); } catch { body = Object.fromEntries((await c.req.parseBody()) as any); }

  let parsed: { orderId?: string; status?: PayStatus } = {};
  if (provider === "yookassa") parsed = await yookassaWebhook(body);
  else if (provider === "tinkoff") parsed = tinkoffWebhook(body);
  else if (provider === "skins") parsed = skinsWebhook(body);

  if (parsed.orderId && parsed.status) {
    const rec = (await kv.get(payKey(parsed.orderId))) as PaymentRecord | null;
    if (rec) {
      rec.status = parsed.status;
      rec.updatedAt = Date.now();
      await kv.set(payKey(parsed.orderId), rec);
    }
  }
  // Тинькофф ожидает в ответ ровно "OK"
  if (provider === "tinkoff") return c.text("OK");
  return c.json({ ok: true });
});

// ─────────────────────────────────────────────────────────────────────────
// Уведомления в Telegram
// ─────────────────────────────────────────────────────────────────────────
// Токен бота живёт только здесь (Deno.env). Chat id получателя берём из kv —
// туда его записывает мини-апп, когда владелец магазина открывает приложение.
app.post(`${PREFIX}/notify`, async (c) => {
  const token = Deno.env.get("TELEGRAM_BOT_TOKEN");
  if (!token) return c.json({ ok: false, error: "нет TELEGRAM_BOT_TOKEN" }, 200);

  let body: { text?: string } = {};
  try { body = await c.req.json(); } catch { /* пустое тело */ }
  const text = (body.text ?? "").slice(0, 3500);
  if (!text) return c.json({ ok: false, error: "пустое сообщение" }, 400);

  const chatId = Deno.env.get("TELEGRAM_ADMIN_CHAT_ID") || (await kv.get("ownerChatId"));
  if (!chatId) return c.json({ ok: false, error: "неизвестен chat id владельца" }, 200);

  try {
    const res = await fetchWithTimeout(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML", disable_web_page_preview: true }),
    });
    const data = await res.json().catch(() => ({}));
    return c.json({ ok: !!data?.ok, error: data?.description });
  } catch (e) {
    return c.json({ ok: false, error: (e as Error).message }, 200);
  }
});

// ─────────────────────────────────────────────────────────────────────────
// Публикация поста в Telegram-канал
// ─────────────────────────────────────────────────────────────────────────
// ID канала берётся из настроек CRM (kv «channelId»), затем из тела запроса и
// в последнюю очередь из секрета TELEGRAM_CHANNEL_ID.
app.post(`${PREFIX}/publish`, async (c) => {
  const token = Deno.env.get("TELEGRAM_BOT_TOKEN");
  if (!token) return c.json({ ok: false, error: "нет TELEGRAM_BOT_TOKEN" }, 200);

  let body: { photoUrl?: string; photos?: string[]; videoUrl?: string; width?: number; height?: number; caption?: string; buttonText?: string; channelId?: string } = {};
  try { body = await c.req.json(); } catch { /* пустое тело */ }

  const channelId = (body.channelId ?? "").trim() ||
    ((await kv.get("channelId")) as string | null) ||
    Deno.env.get("TELEGRAM_CHANNEL_ID");
  if (!channelId) return c.json({ ok: false, error: "не указан ID канала — укажите его в CRM → Публикация" }, 200);

  const caption = (body.caption ?? "").slice(0, 1024);
  const photoUrl = (body.photoUrl ?? "").trim();
  const photos = (Array.isArray(body.photos) ? body.photos : []).map((p) => (p ?? "").trim()).filter(Boolean).slice(0, 3);
  const videoUrl = (body.videoUrl ?? "").trim();
  const buttonText = (body.buttonText ?? "").trim().slice(0, 64) || "🛍 Открыть магазин";
  const SHOP_URL = "https://t.me/Sigma_Space_Bot/sigma";

  const inlineKeyboard = {
    inline_keyboard: [[
      { text: buttonText, url: SHOP_URL },
    ]],
  };

  try {
    // Альбом из 2-3 фото: Telegram media group не поддерживает inline-кнопку,
    // поэтому ссылку на магазин добавляем текстом в конец подписи.
    if (photos.length > 1) {
      const albumCaption = [caption, `<a href="${SHOP_URL}">${buttonText}</a>`].filter(Boolean).join("\n\n").slice(0, 1024);
      const media = photos.map((url, i) => ({
        type: "photo",
        media: url,
        ...(i === 0 ? { caption: albumCaption, parse_mode: "HTML" } : {}),
      }));
      const albumRes = await fetchWithTimeout(`https://api.telegram.org/bot${token}/sendMediaGroup`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chat_id: channelId, media }),
      });
      const albumData = await albumRes.json().catch(() => ({}));
      return c.json({ ok: !!albumData?.ok, error: albumData?.description });
    }

    let res: Response;
    if (videoUrl) {
      res = await fetchWithTimeout(`https://api.telegram.org/bot${token}/sendVideo`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: channelId,
          video: videoUrl,
          caption,
          parse_mode: "HTML",
          // Размеры помогают Telegram показать ролик без чёрных полей.
          ...(body.width ? { width: body.width } : {}),
          ...(body.height ? { height: body.height } : {}),
          supports_streaming: true,
          reply_markup: inlineKeyboard,
        }),
      });
    } else if (photoUrl || photos[0]) {
      res = await fetchWithTimeout(`https://api.telegram.org/bot${token}/sendPhoto`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: channelId,
          photo: photoUrl || photos[0],
          caption,
          parse_mode: "HTML",
          reply_markup: inlineKeyboard,
        }),
      });
    } else {
      if (!caption) return c.json({ ok: false, error: "нужен текст, фото или видео" }, 400);
      res = await fetchWithTimeout(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: channelId,
          text: caption,
          parse_mode: "HTML",
          disable_web_page_preview: false,
          reply_markup: inlineKeyboard,
        }),
      });
    }
    const data = await res.json().catch(() => ({}));
    return c.json({ ok: !!data?.ok, error: data?.description });
  } catch (e) {
    return c.json({ ok: false, error: (e as Error).message }, 200);
  }
});

// ── Публикация в сообщество ВКонтакте ────────────────────────────────────────
// VK API нельзя дёргать из браузера (CORS + токен). Делаем всё здесь: если есть
// фото — стандартный трёхшаговый аплоад (getWallUploadServer → upload →
// saveWallPhoto), затем wall.post от имени сообщества. Токен и ID сообщества
// приходят из CRM, но можно переопределить серверными секретами VK_ACCESS_TOKEN
// и VK_GROUP_ID. Видео VK здесь не поддерживается — только фото/текст.
app.post(`${PREFIX}/publish-vk`, async (c) => {
  const V = "5.199";
  let body: { token?: string; groupId?: string; message?: string; photoUrl?: string; photos?: string[]; linkUrl?: string } = {};
  try { body = await c.req.json(); } catch { /* пустое тело */ }

  const token = (body.token ?? "").trim() || Deno.env.get("VK_ACCESS_TOKEN") || "";
  const groupId = String(body.groupId ?? "").replace(/[^0-9]/g, "") || Deno.env.get("VK_GROUP_ID") || "";
  if (!token) return c.json({ ok: false, error: "не указан API-ключ VK — задайте его в CRM → Публикации → Настройки" }, 200);
  if (!groupId) return c.json({ ok: false, error: "не указан ID сообщества VK — задайте его в CRM → Публикации → Настройки" }, 200);

  // VK не понимает HTML-разметку — убираем теги, оставляем чистый текст.
  const stripHtml = (s: string) =>
    s.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").trim();
  const message = stripHtml(body.message ?? "").slice(0, 4000);
  const linkUrl = (body.linkUrl ?? "").trim();
  const photoList = (Array.isArray(body.photos) ? body.photos : [body.photoUrl])
    .map((p) => (p ?? "").trim()).filter(Boolean).slice(0, 3);

  const vkGet = async (method: string, params: Record<string, string>) => {
    const qs = new URLSearchParams({ ...params, access_token: token, v: V }).toString();
    const r = await fetchWithTimeout(`https://api.vk.com/method/${method}?${qs}`);
    return await r.json().catch(() => ({}));
  };

  try {
    const attachments: string[] = [];

    for (const photoUrl of photoList) {
      // 1) адрес сервера загрузки фото на стену сообщества
      const up = await vkGet("photos.getWallUploadServer", { group_id: groupId });
      if (up.error) return c.json({ ok: false, error: `VK: ${up.error.error_msg}` }, 200);

      // 2) скачиваем картинку из нашего хранилища и заливаем в VK
      const imgRes = await fetchWithTimeout(photoUrl);
      const blob = await imgRes.blob();
      const fd = new FormData();
      fd.append("photo", blob, "photo.jpg");
      const upRes = await fetchWithTimeout(up.response.upload_url, { method: "POST", body: fd });
      const upData = await upRes.json().catch(() => ({}));
      if (!upData.photo || upData.photo === "[]") return c.json({ ok: false, error: "VK: не удалось загрузить фото" }, 200);

      // 3) сохраняем фото и получаем attachment вида photo{owner}_{id}
      const saved = await vkGet("photos.saveWallPhoto", {
        group_id: groupId,
        server: String(upData.server),
        photo: upData.photo,
        hash: upData.hash,
      });
      if (saved.error) return c.json({ ok: false, error: `VK: ${saved.error.error_msg}` }, 200);
      const ph = saved.response?.[0];
      if (ph) attachments.push(`photo${ph.owner_id}_${ph.id}`);
    }

    // Ссылку на магазин добавляем отдельным вложением-сниппетом.
    if (linkUrl) attachments.push(linkUrl);

    if (!message && !attachments.length) return c.json({ ok: false, error: "нужен текст или фото" }, 200);

    // Пост от имени сообщества (owner_id отрицательный, from_group=1).
    const postParams = new URLSearchParams({
      owner_id: `-${groupId}`,
      from_group: "1",
      access_token: token,
      v: V,
    });
    if (message) postParams.set("message", message);
    if (attachments.length) postParams.set("attachments", attachments.join(","));
    const postRes = await fetchWithTimeout("https://api.vk.com/method/wall.post", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: postParams.toString(),
    });
    const postData = await postRes.json().catch(() => ({}));
    if (postData.error) return c.json({ ok: false, error: `VK: ${postData.error.error_msg}` }, 200);
    return c.json({ ok: true });
  } catch (e) {
    return c.json({ ok: false, error: (e as Error).message }, 200);
  }
});

Deno.serve(app.fetch);
